const config = {
  bot: {
    clientID: "1047288679179231322", // Bot ID.
    token:
      "MTA0NzI4ODY3OTE3OTIzMTMyMg.GxljKu.GwkCdML0lH6z9pzvFjFKqIMxXgMonpTn6yT3xI", // Bot Token,
    license: "MNLff0gP1_aPnqiziBVs5K", // Product License found at https://sarksdevelopment.com
    debugMode: true, // Enable/Disable debug mode
    ephemeral: true, // Make most bot responses ephermal (visible to only the repsondant) Recommended to be enabled.
  },
  theme: {
    color: "#152238", // Color theme usng HEX code.
  },
  stats: {
    presence: "over the server", // custom presnce.
    activity: "Watching", // activity type; Competing in, Playing, Watching, Listening to, Streaming.
    status: "dnd", // idle, dnd, online, invisible.
  },
  database: {
    host: "localhost", // Database host
    user: "root", // Database user
    password: "", // Database password
    name: "giveawaybot", // The mysql ban database
  },
  owners: ["828427080500379649"], // An array of owner IDs that own the bot.
};
module.exports = config;
