CREATE TABLE IF NOT EXISTS stickymessages(
    GuildID VARCHAR(255),
    ChannelID VARCHAR(255),
    StickyMessage TEXT
);
CREATE TABLE IF NOT EXISTS giveaways(
    GuildID VARCHAR(255),
    GiveawayID INT AUTO_INCREMENT,
    HostedBy VARCHAR(255),
    MessageID VARCHAR(255),
    ChannelID VARCHAR(255),
    Prize VARCHAR(255),
    Duration VARCHAR(255),
    GDescription VARCHAR(255),
    WinnerCount INT,
    Active VARCHAR(255),
    Entries INT,
    PRIMARY KEY (GiveawayID)
);
CREATE TABLE IF NOT EXISTS giveawayentries(
    GiveawayID INT,
    GuildID VARCHAR(255),
    ChannelID VARCHAR(255),
    MessageID VARCHAR(255),
    UserID VARCHAR(255)
);