CREATE DATABASE IF NOT EXISTS sarktickets;
USE sarktickets;
CREATE TABLE IF NOT EXISTS btnpanels(
    GuildID TEXT,
    PanelID INT,
    LogChannelID TEXT,
    CategoryID TEXT,
    Title TEXT,
    Description TEXT
);

CREATE TABLE IF NOT EXISTS btnroles(
    GuildID TEXT,
    PanelID INT,
    RoleID TEXT
);

CREATE TABLE IF NOT EXISTS drppanels(
    GuildID TEXT,
    PanelID INT,
    LogChannelID TEXT,
    CategoryID TEXT
);


CREATE TABLE IF NOT EXISTS drptickets(
    GuildID TEXT,
    PanelID INT,
    TicketID INT,
    Name TEXT,
    Description TEXT
);

CREATE TABLE IF NOT EXISTS drproles(
    GuildID TEXT,
    PanelID INT,
    RoleID TEXT
);

CREATE TABLE IF NOT EXISTS logs(
    GuildID TEXT,
    PanelID INT,
    PanelType TEXT,
    OpeningMemberID TEXT,
    ClosingMemberID TEXT,
    ClaimingMemberID TEXT,
    ChannelID TEXT,
    Locked TEXT,
    Closed TEXT,
    TicketID INT,
    Archived TEXT
);