const { GatewayIntentBits, Partials } = require("discord.js");
const fs = require("fs");
const mysql = require("mysql");
const chalk = require("chalk");
const { SarkClient } = require("./sarkClient");
const client = new SarkClient({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildVoiceStates,
  ],
  partials: [
    Partials.GuildMember,
    Partials.Message,
    Partials.Channel,
    Partials.User,
  ],
});

// Handlers

const functionFolders = fs.readdirSync(`./src/functions`);
for (const folder of functionFolders) {
  const functionsFiles = fs
    .readdirSync(`./src/functions/${folder}`)
    .filter((file) => file.endsWith(".js"));
  for (const file of functionsFiles)
    require(`../functions/${folder}/${file}`)(client);
}

client.setMaxListeners(0);
client.handleEvents(client);
client.handleCommands();

try {
  const con = mysql.createPool(client.config.mysql);
  setTimeout(() => {
    console.log(`${chalk.yellow("[SQL SERVER]")} Successfully Connected`);
  }, 4000);
  con.on("enqueue", function () {
    if (client.config.client.debugmode) {
      console.log(
        `${chalk.yellow("[SQL SERVER]")} Waiting for available connection slot`
      );
    }
  });
  con.on("release", function (connection) {
    if (client.config.client.debugmode) {
      console.log(
        `${chalk.yellow("[SQL SERVER]")} Connection %d released`,
        connection.threadId
      );
    }
  });
  client.con = con;
} catch (err) {
  if (client.config.client.debugmode) {
    client.utils.error(client, err);
  }
  return process.exit(1);
}
try {
  client.login(client.config.client.token);
} catch (err) {
  if (client.config.client.debugmode) {
    console.log(err);
  }
  return process.exit(1);
}
process.on("unhandledRejection", (err) => {
  if (err !== "DiscordAPIError: Unknown Message") {
    console.log(chalk.red(`\nFatal Error Occured: \n\n`, err.stack));
  }
});

setTimeout(() => {
  const version = Number(process.version.split(".")[0].replace("v", ""));
  if (version < 16)
    return console.log(chalk.red("\n\nPlease upgrade to Node v16 or higher"));
}, 8000);