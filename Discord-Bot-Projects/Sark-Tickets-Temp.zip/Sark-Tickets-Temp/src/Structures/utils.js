const chalk = require("chalk");
const axios = require("axios");
const config = require("../../config.json");

async function error(client, content) {
  if (client.config.client.debugmode) {
    console.log(
      chalk.red("DEBUG MODE ERROR: ", content, `\n ${content.stack}`)
    );
  }
}

function hasRole(roleID, member) {
  if (!member.roles.cache.some((role) => role.id === roleID)) {
    return false;
  } else return true;
}

function sortRoles(rows) {
  let sortedroles = [];
  rows.forEach((row) => {
    sortedroles.push(row.RoleID);
  });
  return sortedroles;
}

function hasRoles(checkroles, userroles) {
  let results = [];
  checkroles.forEach((role) => {
    let index = userroles.indexOf(role);
    if (index === -1) {
      results.push("false");
    } else results.push("true");
  });
  let result;
  if (results.indexOf("true") === -1) {
    result = false;
  } else result = true;
  return result;
}

async function versionChecker() {
  setTimeout(async () => {
    const version = require("../../package.json").version;
    const currver = version;
    const req = await axios({
      method: "get",
      url: "https://raw.githubusercontent.com/Sarkosis/version-pub-api/main/versions.json",
      headers: {
        Accept: "application/json, text/plain, */*",
        "User-Agent": "*",
      },
    });
    const latestver = req.data.ticket;
    if (latestver != currver) {
      console.log(
        `${chalk.yellow("[Version Checker]\n")}${chalk.red(
          `You are not on the latest version.\nCurrent Version: ${currver}\nLatest Version: ${latestver}`
        )}`
      );
    } else {
      console.log(
        `${chalk.green("[Version Checker]")} You are on the latest version.`
      );
    }
  }, 1000);
}

async function license(licenseKey, uniqueId) {
  let request = await axios({
    method: "get",
    url: `https://store.sarksdevelopment.com/api/v1/license/check/${licenseKey}`,
    headers: {
      Accept: "application/json, text/plain, */*",
      "User-Agent": "*",
      productid: uniqueId,
    },
  });

  if (request.data.authorized) {
    setTimeout(() => {
      console.log(`${chalk.green.dim("[License Check]")} License Key Accepted`);
    }, 1001);
  } else {
    console.log(`${chalk.red.dim("[License Check]")} License Key Failed`);
    process.exit(1);
  }
}
// license(config.licensekey, "1675565301837etsgUn0G10Nk1S");
versionChecker();

function ticketider(t) {
  let ticketid;
  if (t < 10) {
    ticketid = "000" + t;
  } else if (t < 100) {
    ticketid = "00" + t;
  } else if (t < 1000) {
    ticketid = "0" + t;
  } else if (t >= 1000) {
    ticketid = t;
  }
  return ticketid;
}

async function ticketPerms(row, channel) {
  let roles = [];
  row.forEach((r) => {
    roles.push(r.RoleID);
  });
  roles.forEach(async (role) => {
    await channel.permissionOverwrites.edit(role, {
      ViewChannel: true,
      ReadMessageHistory: true,
      SendMessages: true,
      AddReactions: true,
      AttachFiles: true,
      EmbedLinks: true,
      SendMessagesInThreads: true,
      UseApplicationCommands: true,
      UseExternalEmojis: true,
      UseExternalStickers: true,
    });
  });
}
exports.hasRoles = hasRoles;
exports.sortRoles = sortRoles;
exports.ticketPerms = ticketPerms;
exports.ider = ticketider;
exports.error = error;
exports.hasRole = hasRole;
