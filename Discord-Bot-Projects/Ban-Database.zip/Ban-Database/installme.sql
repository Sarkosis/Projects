CREATE DATABASE IF NOT EXISTS sarkbans;
USE sarkbans;
CREATE TABLE IF NOT EXISTS guilds(
    GuildID TEXT,
    AutoBans TEXT,
    AutoUnbans TEXT,
    Banlogs TEXT,
    ReportLogs TEXT,
    AppealLogs TEXT
);
CREATE TABLE IF NOT EXISTS blacklistedusers(
    CaseID INT,
    UserID TEXT,
    Reason TEXT,
    Evidence TEXT
);
CREATE TABLE IF NOT EXISTS cases(
    CaseID INT,
    UserID TEXT,
    UserTag TEXT,
    StaffID TEXT,
    Reason TEXT,
    Evidence TEXT,
    BanDate TEXT
);
CREATE TABLE IF NOT EXISTS reports(
    ReportID INT,
    Pending TEXT,
    UserID TEXT,
    UserTag TEXT,
    ReporterID TEXT,
    Reason TEXT,
    Evidence TEXT,
    Notes TEXT
);
CREATE TABLE IF NOT EXISTS appeals(
    AppealID INT,
    Pending TEXT,
    UserID TEXT,
    UserTag TEXT,
    BanReason TEXT,
    UnbanReason TEXT,
    Notes TEXT
);
CREATE TABLE IF NOT EXISTS staff(GuildID TEXT, UserID TEXT);
CREATE TABLE IF NOT EXISTS btnpanels(
    GuildID TEXT,
    PanelID INT,
    LogChannelID TEXT,
    CategoryID TEXT,
    Title TEXT,
    Description TEXT
);
CREATE TABLE IF NOT EXISTS btnroles(
    GuildID TEXT,
    PanelID INT,
    RoleID TEXT
);
CREATE TABLE IF NOT EXISTS drppanels(
    GuildID TEXT,
    PanelID INT,
    LogChannelID TEXT,
    CategoryID TEXT
);
CREATE TABLE IF NOT EXISTS drptickets(
    GuildID TEXT,
    PanelID INT,
    TicketID INT,
    Name TEXT,
    Description TEXT
);
CREATE TABLE IF NOT EXISTS drproles(
    GuildID TEXT,
    PanelID INT,
    RoleID TEXT
);
CREATE TABLE IF NOT EXISTS logs(
    GuildID TEXT,
    PanelID INT,
    PanelType TEXT,
    OpeningMemberID TEXT,
    ClosingMemberID TEXT,
    ClaimingMemberID TEXT,
    ChannelID TEXT,
    Locked TEXT,
    Closed TEXT,
    TicketID INT,
    Archived TEXT
);