const config = require("./config.json");
const express = require("express");
const chalk = require("chalk");
const mysql = require("mysql");
const utils = require("hyperz-utils");
const backend = require("./backend.js");
const DiscordStrategy = require("passport-discord-hyperz").Strategy;
const passport = require("passport");
const fs = require("fs");
const app = express();
let con = mysql.createConnection(config.mysql);
backend.init(app, con);
passport.serializeUser(function (user, done) {
  done(null, user);
});
passport.deserializeUser(function (obj, done) {
  done(null, obj);
});
passport.use(
  new DiscordStrategy(
    {
      clientID: config.discord.oauthID,
      clientSecret: config.discord.oauthToken,
      callbackURL: `${
        config.domain.endsWith("/") ? config.domain.slice(0, -1) : config.domain
      }/auth/discord/callback`,
      scope: ["identify", "guilds", "email"],
      prompt: "consent",
    },
    function (accessToken, refreshToken, profile, done) {
      process.nextTick(function () {
        return done(null, profile);
      });
    }
  )
);

// Routing
app.get("/", async function (req, res) {
  await backend.resetLocals(app, con);
  con.query(`SELECT * FROM docscats`, async (e, row) => {
    if (e) throw e;
    let categories = row;
    if (req.isAuthenticated()) {
      con.query(
        `SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`,
        async (e, row) => {
          if (e) throw e;
          let staff = false;
          if (row[0]) staff = true;
          res.render("index.ejs", {
            cats: categories,
            LoggedIn: true,
            staff: staff,
          });
        }
      );
    } else {
      res.render("index.ejs", {
        cats: categories,
        LoggedIn: false,
        staff: false,
      });
    }
  });
});

app.get("/c/:catergorylink", async (req, res) => {
  await backend.resetLocals(app, con);
  if (!req.params.catergorylink) return res.redirect("/404");
  req.params.catergorylink = await utils.sanitize(req.params.catergorylink);
  con.query(
    `SELECT * FROM docscats WHERE Link = "${req.params.catergorylink}"`,
    async (e, row) => {
      if (e) throw e;
      if (!row[0]) return res.redirect("/404");
      let cat = row[0];
      cat.Description = await utils.mdConvert(cat.Description);
      con.query(
        `SELECT * FROM docsarts WHERE CategoryID = "${cat.ID}"`,
        async (e, row) => {
          if (e) throw e;
          let articles = row || [];
          if (req.isAuthenticated()) {
            con.query(
              `SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`,
              async (e, row) => {
                if (e) throw e;
                let staff = false;
                if (row[0]) staff = true;
                res.render("category.ejs", {
                  cat: cat,
                  articles: articles,
                  LoggedIn: true,
                  staff: staff,
                });
              }
            );
          } else {
            res.render("category.ejs", {
              cat: cat,
              articles: articles,
              LoggedIn: false,
              staff: false,
            });
          }
        }
      );
    }
  );
});

app.get("/c/:catergorylink/:articlelink", async (req, res) => {
  await backend.resetLocals(app, con);
  if (!req.params.catergorylink) return res.redirect("/404");
  if (!req.params.articlelink) return res.redirect("/404");
  req.params.catergorylink = await utils.sanitize(req.params.catergorylink);
  req.params.articlelink = await utils.sanitize(req.params.articlelink);
  con.query(
    `SELECT * FROM docscats WHERE link = "${req.params.catergorylink}"`,
    async (err, row) => {
      if (err) throw err;
      if (!row[0]) return res.redirect("/404");
      let category = row[0];
      con.query(
        `SELECT * FROM docsarts WHERE CategoryID = "${category.ID}"`,
        async function (err, row) {
          if (err) throw err;
          let articles = row || [];
          con.query(
            `SELECT * FROM docsarts WHERE Link = "${req.params.articlelink}"`,
            async function (err, row) {
              if (err) throw err;
              if (!row[0]) return res.redirect("/404");
              let article = row[0];
              if (article.DiscordRoleIDs !== "none") {
                let hasrole = await backend.hasRole(
                  req.session.passport?.user?.id || "12345678910",
                  article,
                  app.locals.settings.GuildID
                );
                console.log(hasrole);
                if (!hasrole) {
                  article.Content = await utils.mdConvert(
                    ":::danger\nYou do not have the required Discord role to view this article.\n:::"
                  );
                } else {
                  article.Content = await utils.mdConvert(article.Content);
                }
              } else {
                article.Content = await utils.mdConvert(article.Content);
              }
              if (req.isAuthenticated()) {
                con.query(
                  `SELECT * FROM staff WHERE userid="${req.session.passport.user.id}"`,
                  async (err, row) => {
                    if (err) throw err;
                    let staff = false;
                    if (row[0]) staff = true;
                    res.render("article.ejs", {
                      cat: category,
                      arts: articles,
                      art: article,
                      LoggedIn: true,
                      staff: staff,
                    });
                  }
                );
              } else {
                res.render("article.ejs", {
                  cat: category,
                  arts: articles,
                  art: article,
                  LoggedIn: false,
                  staff: false,
                });
              }
            }
          );
        }
      );
    }
  );
});

app.get("/admin", async function (req, res) {
  await backend.resetLocals(app, con);
  if (req.isAuthenticated()) {
    con.query(
      `SELECT * FROM staff WHERE UserID = '${req.session.passport.user.id}'`,
      async (e, row) => {
        if (e) throw e;
        let owner = config.ownerIDs.includes(req.session.passport.user.id);
        if (owner) {
          await backend.audit(
            "Admin Page Accessed",
            `${req.session.passport.user.username} (${req.session.passport.user.id}) has accessed the site admin page.`,
            con
          );
          await backend.discordLog(
            "🔒 Admin Page Accessed",
            `${req.session.passport.user.username}#${req.session.passport.user.discriminator} has accessed the admin page!`,
            con
          );
          return res.render("admin.ejs", {
            owner: false,
            LoggedIn: true,
            user: req.session.passport.user,
          });
        }
        if (!row[0]) return res.redirect("/404");
        await backend.audit(
          "Admin Page Accessed",
          `${req.session.passport.user.username} (${req.session.passport.user.id}) has accessed the site admin page.`,
          con
        );
        await backend.discordLog(
          "🔒 Admin Page Accessed",
          `${req.session.passport.user.username}#${req.session.passport.user.discriminator} has accessed the admin page!`,
          con
        );
        res.render("admin.ejs", {
          owner: false,
          LoggedIn: true,
          user: req.session.passport.user,
        });
      }
    );
  } else res.redirect("/auth/discord");
});

app.get("/admin/:cat", async function (req, res) {
  await backend.resetLocals(app, con);
  if (req.isAuthenticated()) {
    let data = {};
    con.query(
      `SELECT * FROM staff WHERE UserID = '${req.session.passport.user.id}'`,
      async (e, row) => {
        if (e) throw e;
        if (!row[0]) return res.redirect("/404");
        con.query(`SELECT * FROM sitesettings`, async (e, row) => {
          if (e) throw e;
          data.settings = row[0];
          con.query(`SELECT * FROM navbar`, async (e, row) => {
            if (e) throw e;
            data.navbar = row;
            con.query(`SELECT * FROM staff`, async (e, row) => {
              if (e) throw e;
              data.staff = row;
              con.query(`SELECT * FROM docscats`, async (e, row) => {
                if (e) throw e;
                data.doccats = row;
                con.query(`SELECT * FROM docsarts`, async (e, row) => {
                  if (e) throw e;
                  data.docarts = row;
                  con.query(`SELECT * FROM auditlogs`, async (e, row) => {
                    if (e) throw e;
                    data.auditlogs = row;
                    if (
                      !fs.existsSync(`./src/views/admin_${req.params.cat}.ejs`)
                    )
                      return res.redirect("/404");
                    res.render(`admin_${req.params.cat}.ejs`, {
                      LoggedIn: true,
                      data: data,
                      user: req.session.passport.user,
                    });
                  });
                });
              });
            });
          });
        });
      }
    );
  } else res.redirect("/auth/discord");
});

app.post("/backend/create/doccat", async function (req, res) {
  await backend.resetLocals(app, con);
  let id = await utils.generateRandom(20);
  req.body.categoryname = await utils.sanitize(req.body.categoryname);
  req.body.categorylink = await utils.sanitize(req.body.categorylink);
  req.body.categoryposition = await utils.sanitize(req.body.categoryposition);
  req.body.categorydesc = await utils.sanitize(req.body.categorydesc);
  if (req.isAuthenticated()) {
    con.query(
      `SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`,
      async (e, row) => {
        if (e) throw e;
        if (!row[0]) return res.redirect("/404");
        if (!req.files[0]) return res.redirect("/404");
        fs.writeFileSync(
          `./public/images/category_${id}.png`,
          req.files[0].buffer
        );
        con.query(
          `INSERT INTO docscats (ID, Name, Description, Link, Position) VALUES ("${id}", "${req.body.categoryname}", "${req.body.categorydesc}", "${req.body.categorylink}", "${req.body.categoryposition}")`,
          async (e) => {
            if (e) throw e;
            await backend.audit(
              `Category Created`,
              `${req.session.passport.user.username} (${req.session.passport.user.id}) created a new category (${req.body.categoryname})`,
              con
            );
            return res.redirect("/admin/pages");
          }
        );
      }
    );
  } else res.redirect("/auth/discord");
});

app.post("/backend/create/docart", async function (req, res) {
  await backend.resetLocals(app, con);
  let id = await utils.generateRandom(20);
  req.body.category = await utils.sanitize(req.body.category);
  req.body.title = await utils.sanitize(req.body.title);
  req.body.link = await utils.sanitize(req.body.link);
  req.body.position = await utils.sanitize(req.body.position);
  req.body.content = await utils.sanitize(req.body.content);
  if (!req.body.roleid) req.body.roleid = "none";
  req.body.roleid = await utils.sanitize(req.body.roleid);
  if (req.isAuthenticated()) {
    con.query(
      `SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`,
      async (e, row) => {
        if (e) throw e;
        if (!row[0]) return res.redirect("/404");
        con.query(
          `INSERT INTO docsarts (ID, CategoryID, Title, Content, Link, DiscordRoleIDs, Position) VALUES ("${id}", "${req.body.category}", "${req.body.title}", "${req.body.content}", "${req.body.link}", "${req.body.roleid}", "${req.body.position}")`,
          async (e) => {
            if (e) throw e;
            await backend.audit(
              `Article Created`,
              `${req.session.passport.user.username} (${req.session.passport.user.id}) created a new article (${req.body.title})`,
              con
            );
            return res.redirect("/admin/pages");
          }
        );
      }
    );
  } else res.redirect("/auth/discord");
});

app.post("/backend/create/navbutton", async function (req, res) {
  await backend.resetLocals(app, con);
  if (req.isAuthenticated) {
    let id = await utils.generateRandom(10);
    req.body.buttonname = await utils.sanitize(req.body.buttonname);
    req.body.buttonlink = await utils.sanitize(req.body.buttonlink);
    con.query(
      `SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`,
      async (e, row) => {
        if (e) throw e;
        if (!row[0]) return res.redirect("/404");
        con.query(
          `INSERT INTO navbar (ID, Name, Link) VALUES ("${id}", "${req.body.buttonname}", "${req.body.buttonlink}")`,
          async (e) => {
            if (e) throw e;
            await backend.audit(
              `Navbar Button Created`,
              `${req.session.passport.user.username} (${req.session.passport.user.id}) created a navbar button.`,
              con
            );
            return res.redirect(`/admin/settings`);
          }
        );
      }
    );
  } else res.redirect("/auth/discord");
});

app.get("/admin/editcat/:id", async function (req, res) {
  await backend.resetLocals(app, con);
  req.params.id = await utils.sanitize(req.params.id);
  if (req.isAuthenticated()) {
    con.query(
      `SELECT * FROM staff WHERE UserID="${req.session.passport.user.id}"`,
      async (e, row) => {
        if (e) throw e;
        if (!row[0]) return res.redirect("/404");
        con.query(
          `SELECT * FROM docscats WHERE ID="${req.params.id}"`,
          async (e, row) => {
            if (e) throw e;
            if (!row[0]) return res.redirect("/404");
            let cat = row[0];
            await backend.audit(
              `Category Edited`,
              `${req.session.passport.user.username} (${req.session.passport.user.id}) has edited ${cat.Name}.`,
              con
            );
            res.render("admin_editcat.ejs", {
              LoggedIn: true,
              cat: cat,
            });
          }
        );
      }
    );
  } else res.redirect("/auth/discord");
});

app.get("/admin/editart/:id", async function (req, res) {
  await backend.resetLocals(app, con);
  req.params.id = await utils.sanitize(req.params.id);
  if (req.isAuthenticated) {
    con.query(
      `SELECT * FROM Staff WHERE UserID="${req.session.passport.user.id}"`,
      async (e, row) => {
        if (e) throw e;
        if (!row[0]) return res.redirect("/404");
        con.query(`SELECT * FROM docscats`, async (e, row) => {
          if (e) throw e;
          if (!row[0]) return res.redirect("/404");
          let cats = row;
          con.query(
            `SELECT * FROM docsarts WHERE ID="${req.params.id}"`,
            async (e, row) => {
              if (e) throw e;
              if (!row[0]) return res.redirect("/404");
              let article = row[0];
              await backend.audit(
                `Article Edited`,
                `${req.session.passport.user.username} (${req.session.passport.user.id}) has edited ${article.Title}.`,
                con
              );
              res.render("admin_editart.ejs", {
                LoggedIn: true,
                cats: cats,
                art: article,
              });
            }
          );
        });
      }
    );
  } else res.redirect("/auth/discord");
});

app.post("/backend/update/cat/:id", async function (req, res) {
  await backend.resetLocals(app, con);
  if (!req.params.id) return res.redirect("/404");
  let id = await utils.sanitize(req.params.id);
  if (req.isAuthenticated) {
    req.body.categoryname = await utils.sanitize(req.body.categoryname);
    req.body.categorylink = await utils.sanitize(req.body.categorylink);
    req.body.categoryposition = await utils.sanitize(req.body.categoryposition);
    req.body.categorydesc = await utils.sanitize(req.body.categorydesc, true);
    con.query(
      `SELECT * FROM staff WHERE UserID="${req.session.passport.user.id}"`,
      async (e, row) => {
        if (e) throw e;
        if (!row[0]) return res.redirect("/404");
        if (req.files[0]) {
          fs.writeFileSync(
            `./public/images/category_${id}.png`,
            req.files[0].buffer
          );
        }
        con.query(
          `UPDATE docscats SET Name = "${req.body.categoryname}", Description = "${req.body.categorydesc}", Link = "${req.body.categorylink}",  Position = "${req.body.position}" WHERE ID="${id}"`,
          async (e) => {
            if (e) throw e;
            await backend.audit(
              `Category Updated`,
              `${req.session.passport.user.username} (${req.session.passport.user.id}) updated a category (${req.body.categoryname}).`,
              con
            );
            return res.redirect(`/admin/pages`);
          }
        );
      }
    );
  } else res.redirect("/auth/discord");
});

app.post("/backend/update/art/:id", async function (req, res) {
  await backend.resetLocals(app, con);
  if (!req.params.id) return res.redirect("/404");
  if (req.isAuthenticated()) {
    let id = await utils.sanitize(req.params.id);
    req.body.category = await utils.sanitize(req.body.category);
    req.body.title = await utils.sanitize(req.body.title);
    req.body.link = await utils.sanitize(req.body.link);
    req.body.position = await utils.sanitize(req.body.position);
    req.body.content = await utils.sanitize(req.body.content, true);
    if (!req.body.roleid) req.body.roleid = "none";
    req.body.roleid = await utils.sanitize(req.body.roleid);
    con.query(
      `SELECT * FROM Staff WHERE UserID = "${req.session.passport.user.id}"`,
      async (e, row) => {
        if (e) throw e;
        if (!row[0]) return res.redirect("/404");
        console.log(req.body.category);
        con.query(
          `UPDATE docsarts SET CategoryID = "${req.body.category}", Title = "${req.body.title}", Link = "${req.body.link}", Content = "${req.body.content}", Position = "${req.body.position}", DiscordRoleIDs = " ${req.body.roleid}" WHERE ID = "${id}"`,
          async (e) => {
            if (e) throw e;
            await backend.audit(
              `Article Updated`,
              `${req.session.passport.user.username} (${req.session.passport.user.id}) updated an article (${req.body.title}).`,
              con
            );
            return res.redirect(`/admin/pages`);
          }
        );
      }
    );
  } else res.redirect("/auth/discord");
});

app.post("/backend/update/settings", async function (req, res) {
  await backend.resetLocals(app, con);
  if (req.isAuthenticated()) {
    req.body.sitename = await utils.sanitize(req.body.sitename);
    req.body.sitecolor = await utils.sanitize(req.body.sitecolor);
    if (!req.body.sitecolor.startsWith("#"))
      req.body.sitecolor = `#${req.body.sitecolor}`;
    req.body.loggingchannelid = await utils.sanitize(req.body.loggingchannelid);
    req.body.guildid = await utils.sanitize(req.body.guildid);
    if (
      typeof req.body.loggingchannelid != "undefined" &&
      req.body.loggingchannelid != ""
    ) {
      req.body.loggingchannelid = await utils.sanitize(
        req.body.loggingchannelid
      );
    } else {
      req.body.loggingchannelid = await utils.sanitize("none");
    }
    con.query(
      `SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`,
      async (e, row) => {
        if (e) throw e;
        if (!row[0]) return res.redirect("/404");
        con.query(
          `UPDATE sitesettings SET Name = "${req.body.sitename}", Color = "${req.body.sitecolor}", LoggingChannel = "${req.body.loggingchannelid}", GuildID = "${req.body.guildid}"`,
          async (e) => {
            if (e) throw e;
          }
        );
        await backend.audit(
          `Settings Updated`,
          `${req.session.passport.user.username} (${req.session.passport.user.id}) updated the site settings.`,
          con
        );
        await backend.discordLog(
          "⚙️ Settings Updated!",
          `${req.session.passport.user.username}#${req.session.passport.user.discriminator} has updated website settings!`,
          con
        );
        return res.redirect("/admin");
      }
    );
  } else res.redirect("/auth/discord");
});

app.get("/backend/delete/cat/:id", async function (req, res) {
  await backend.resetLocals(app, con);
  if (!req.params.id) return res.redirect("/404");
  req.params.id = await utils.sanitize(req.params.id);
  if (req.isAuthenticated()) {
    con.query(
      `SELECT * FROM Staff WHERE UserID= "${req.session.passport.user.id}"`,
      async (e, row) => {
        if (e) throw e;
        if (!row[0]) return res.redirect("/404");
        con.query(
          `SELECT * FROM docscats WHERE ID = "${req.params.id}"`,
          async (e, row) => {
            if (e) throw e;
            if (!row[0]) return res.redirect("/admin/pages");
            let cat = row[0];
            con.query(
              `DELETE FROM docscats WHERE ID = "${req.params.id}" LIMIT 1`,
              async (e) => {
                if (e) throw e;
                await backend.audit(
                  `Docs Category Deleted`,
                  `${req.session.passport.user.username} (${req.session.passport.user.id}) removed category ${cat.Name}.`,
                  con
                );
                return res.redirect(`/admin/pages`);
              }
            );
          }
        );
      }
    );
  } else res.redirect("/auth/discord");
});

app.get("/backend/delete/art/:id", async function (req, res) {
  await backend.resetLocals(app, con);
  if (!req.params.id) return res.redirect("/404");
  if (req.isAuthenticated()) {
    req.params.id = await utils.sanitize(req.params.id);
    con.query(
      `SELECT * FROM Staff WHERE UserID = "${req.session.passport.user.id}"`,
      async (e, row) => {
        if (e) throw e;
        if (!row[0]) return res.redirect("/404");
        con.query(
          `SELECT * FROM docsarts WHERE ID = "${req.params.id}"`,
          async (e, row) => {
            if (e) throw e;
            if (!row[0]) return res.redirect("/admin/pages");
            let art = row[0];
            con.query(
              `DELETE FROM docsarts WHERE ID = "${req.params.id}" LIMIT 1`,
              async (e) => {
                if (e) throw e;
                await backend.audit(
                  `Article Deleted`,
                  `${req.session.passport.user.username} (${req.session.passport.user.id}) removed article ${art.Title}.`,
                  con
                );
                return res.redirect(`/admin/pages`);
              }
            );
          }
        );
      }
    );
  } else res.redirect("/auth/discord");
});

app.get("/backend/delete/logs", async function (req, res) {
  await backend.resetLocals(app, con);
  if (req.isAuthenticated()) {
    if (config.ownerIDs.includes(req.session.passport.user.id)) {
      con.query(`DELETE FROM auditlogs`, async (e) => {
        if (e) throw e;
      });
      res.redirect("/admin/logs");
    } else {
      res.send("Only an owner can delete audit logs.");
    }
  } else res.redirect("/auth/discord");
});

app.get("/backend/delete/navbutton/:id", async function (req, res) {
  await backend.resetLocals(app, con);
  if (!req.params.id) return res.redirect("/404");
  if (req.isAuthenticated()) {
    req.params.id = await utils.sanitize(req.params.id);
    con.query(
      `SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`,
      async (e, row) => {
        if (e) throw e;
        if (!row[0]) return res.redirect("/404");
        con.query(
          `DELETE FROM navbar WHERE ID = "${req.params.id}" LIMIT 1`,
          async (e) => {
            if (e) throw e;
            await backend.audit(
              `Navbar Deleted`,
              `${req.session.passport.user.username} (${req.session.passport.user.id}) deleted a navbar button.`,
              con
            );
            return res.redirect(`/admin/settings`);
          }
        );
      }
    );
  } else res.redirect("/auth/discord");
});

app.get("/dev", async (req, res) => {
  res.redirect("https://discord.gg/hekkjCywmT");
});

config.redirects.forEach((re) => {
  app.get(`/${re.name}`, async (req, res) => {
    res.redirect(re.link);
  });
});

app.get("/auth/discord", passport.authenticate("discord"));
app.get("/logout", async function (req, res) {
  req.logout(function (e) {
    if (e) {
      return next(e);
    }
    res.redirect("/");
  });
});

app.get(
  "/auth/discord/callback",
  passport.authenticate("discord", { failureRedirect: "/" }),
  async function (req, res) {
    req.session?.loginRef
      ? res.redirect(req.session.loginRef)
      : res.redirect("/");
    delete req.session?.loginRef;
  }
);

app.get("/404", function (req, res) {
  if (req.isAuthenticated()) {
    res.render("404.ejs", { LoggedIn: true });
  } else res.render("404.ejs", { LoggedIn: false });
});

app.get("*", function (req, res) {
  res.redirect("/404");
});

app.listen(config.port);

process.on("unhandledRejection", (err) => {
  if (config.debugMode) console.log(chalk.red(err));
});
