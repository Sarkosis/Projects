import React from "react";
import config from "../config.json";
const About = () => {
  if (config.theme === 1) {
    return (
      <div
        name="about"
        className="w-full h-screen bg-gradient-to-b from-gray-800 to-black text-white"
      >
        <div className="max-w-screen-lg p-4 mx-auto flex flex-col justify-center w-full h-full">
          <div className="pb-8">
            <p className="text-4xl font-bold inline border-b-4 border-gray-500">
              About
            </p>
          </div>
          <p className="text-xl mt-20 text-center">
            {config.about.description}
          </p>
        </div>
      </div>
    );
  } else if (config.theme === 2) {
    return (
      <div
        name="about"
        className="w-full h-screen bg-gradient-to-b from-white to-gray-600 text-black"
      >
        <div className="max-w-screen-lg p-4 mx-auto flex flex-col justify-center w-full h-full">
          <div className="pb-8">
            <p className="text-4xl font-bold inline border-b-4 border-black">
              About
            </p>
          </div>
          <p className="text-xl mt-20 text-center">
            {config.about.description}
          </p>
        </div>
      </div>
    );
  }
};
export default About;
