import config from "../config.json";
import React from "react";
import { RiMailSendLine } from "react-icons/ri";

const Contact = () => {
  let mail = `mailto:${config.contacts.email}?subject=Portfolio Contacts`;
  if (config.theme === 1) {
    return (
      <div
        name="contact"
        className="w-full h-screen bg-gradient-to-b from-black to-gray-800 p-4 text-white"
      >
        <div className="flex flex-col p-4 justify-center max-w-screen-lg mx-auto h-full">
          <div className="pb-8">
            <p className="text-4xl font-bold inline border-b-4 border-gray-500">
              Contacts
            </p>
            <p className="py-6">Click the button below to email me!</p>
            <button className="group text-white w-fit px-6 py-3 my-2 flex items-center rounded-md  bg-gradient-to-r from-cyan-500 to-blue-500 cursor-pointer">
              <a href={mail} target="_blank">
                Email Me &nbsp;
              </a>
              <span className="group-hover:rotate-[360deg] duration-300">
                <RiMailSendLine size={20} />
              </span>
            </button>
          </div>
        </div>
      </div>
    );
  } else if (config.theme === 2) {
    return (
      <div
        name="contact"
        className="w-full h-screen bg-gradient-to-b from-gray-600 to-white p-4 text-black"
      >
        <div className="flex flex-col p-4 justify-center max-w-screen-lg mx-auto h-full">
          <div className="pb-8">
            <p className="text-4xl font-bold inline border-b-4 border-black">
              Contacts
            </p>
            <p className="py-6">Click the button below to email me!</p>
            <button className="group text-white w-fit px-6 py-3 my-2 flex items-center rounded-md bg-blue-800 cursor-pointer">
              <a href={mail} target="_blank">
                Email Me &nbsp;
              </a>

              <span className="group-hover:rotate-[360deg] duration-300">
                <RiMailSendLine size={20} />
              </span>
            </button>
          </div>
        </div>
      </div>
    );
  }
};

export default Contact;
