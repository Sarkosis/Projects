import React from "react";
import logo from "../assets/logo.png";
import { HiOutlineArrowNarrowRight } from "react-icons/hi";
import { Link } from "react-scroll";
import config from "../config.json";

const Home = () => {
  if (config.theme === 1) {
    return (
      <div
        name="home"
        className="h-screen w-full bg-gradient-to-b from-black via-black to-gray-800 text-white"
      >
        <div className="max-w-screen-lg mx-auto flex flex-col items-center h-full px-4 md:flex-row">
          <div className="flex flex-col justify-center h-full">
            <h2 className="text-4xl sm:text-7xl font-bold text-white">
              {config.home.title}
            </h2>
            <p className="text-gray-500 py-4 max-w-md">
              {config.home.description}
            </p>

            <div>
              <Link to="portfolio" smooth duration={500}>
                <button className="group text-white w-fit px-6 py-3 my-2 flex items-center rounded-md  bg-gradient-to-r from-cyan-500 to-blue-500 cursor-pointer">
                  Portfolio &nbsp;
                  <span className="group-hover:rotate-90 duration-300">
                    <HiOutlineArrowNarrowRight size={20} />
                  </span>
                </button>
              </Link>
            </div>
          </div>
          <div>
            <img
              src={logo}
              alt="my profile"
              className="rounded-2xl mx-auto w-2/3 md:w-full"
            />
          </div>
        </div>
      </div>
    );
  } else if (config.theme === 2) {
    return (
      <div
        name="home"
        className="h-screen w-full bg-gradient-to-b from-gray-600 via-gray-600 to-white text-black"
      >
        <div className="max-w-screen-lg mx-auto flex flex-col items-center h-full px-4 md:flex-row">
          <div className="flex flex-col justify-center h-full">
            <h2 className="text-4xl sm:text-7xl font-bold text-white">
              {config.home.title}
            </h2>
            <p className="text-black py-4 max-w-md">
              {config.home.description}
            </p>

            <div>
              <Link to="portfolio" smooth duration={500}>
                <button className="group text-white w-fit px-6 py-3 my-2 flex items-center rounded-md bg-blue-800 cursor-pointer">
                  Portfolio &nbsp;
                  <span className="group-hover:rotate-90 duration-300">
                    <HiOutlineArrowNarrowRight size={20} />
                  </span>
                </button>
              </Link>
            </div>
          </div>
          <div>
            <img
              src={logo}
              alt="my profile"
              className="rounded-2xl mx-auto w-2/3 md:w-full"
            />
          </div>
        </div>
      </div>
    );
  }
};

export default Home;
