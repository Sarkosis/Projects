import React from "react";
import config from "../config.json";
import { Link } from "react-scroll";
import {
  FaGithub,
  FaDiscord,
  FaYoutube,
  FaTiktok,
  FaTwitter,
  FaInstagram,
} from "react-icons/fa";

const Footer = () => {
  const navlinks = [
    {
      id: 1,
      link: "home",
    },
    {
      id: 2,
      link: "about",
    },
    {
      id: 3,
      link: "portfolio",
    },
    {
      id: 4,
      link: "experience",
    },
  ];
  if (config.contacts.enabled === true) {
    navlinks.push({
      id: 5,
      link: "contact",
    });
  }

  let links = [];
  if (config.socials.github.enabled === true) {
    links.push({
      id: 1,
      child: (
        <>
          <FaGithub size={35} />
        </>
      ),
      href: config.socials.github.url,
    });
  }

  if (config.socials.discord.enabled === true) {
    links.push({
      id: 2,
      child: (
        <>
          <FaDiscord size={35} />
        </>
      ),
      href: config.socials.discord.url,
    });
  }

  if (config.socials.youtube.enabled === true) {
    links.push({
      id: 3,
      child: (
        <>
          <FaYoutube size={35} />
        </>
      ),
      href: config.socials.youtube.url,
    });
  }

  if (config.socials.tiktok.enabled === true) {
    links.push({
      id: 4,
      child: (
        <>
          <FaTiktok size={35} />
        </>
      ),
      href: config.socials.tiktok.url,
    });
  }

  if (config.socials.twitter.enabled === true) {
    links.push({
      id: 5,
      child: (
        <>
          <FaTwitter size={35} />
        </>
      ),
      href: config.socials.twitter.url,
    });
  }

  if (config.socials.instagram.enabled === true) {
    links.push({
      id: 6,
      child: (
        <>
          <FaInstagram size={35} />
        </>
      ),
      href: config.socials.instagram.url,
    });
  }

  if (config.theme === 1 && config.socials.enabled === true) {
    return (
      <footer className="bg-black text-white py-12 p-10">
        <ul className="p-0 text-lg my-0 text-center">
          {navlinks.map(({ id, link }) => (
            <li
              key={id}
              className="px-4 cursor-pointer capitalize text-white font-semibold lg:hover:scale-105 duration-200 lg:hover:text-gray-600 lg:inline-block items-center"
            >
              <Link to={link} smooth duration={500}>
                {link}
              </Link>
            </li>
          ))}
        </ul>
      </footer>
    );
  } else if (config.theme === 1 && config.socials.enabled === false) {
    return (
      <footer className="bg-black text-white py-12 p-10">
        <ul className="p-0 text-lg my-0 text-center">
          {navlinks.map(({ id, link }) => (
            <li
              key={id}
              className="px-4 cursor-pointer capitalize text-white font-semibold lg:hover:scale-105 duration-200 lg:hover:text-gray-600 lg:inline-block items-center"
            >
              <Link to={link} smooth duration={500}>
                {link}
              </Link>
            </li>
          ))}
        </ul>
      </footer>
    );
  } else if (config.theme === 2 && config.socials.enabled === true) {
    return (
      <footer className="bg-gray-800 text-white py-12 p-10">
        <ul className="p-0 text-lg my-0 text-center">
          {navlinks.map(({ id, link }) => (
            <li
              key={id}
              className="px-4 cursor-pointer capitalize text-white font-semibold lg:hover:scale-105 duration-200 lg:hover:text-gray-600 lg:inline-block items-center"
            >
              <Link to={link} smooth duration={500}>
                {link}
              </Link>
            </li>
          ))}
        </ul>
      </footer>
    );
  } else if (config.theme === 2 && config.socials.enabled === false) {
    return (
      <footer className="bg-gray-800 text-white py-12 p-10">
        <ul className="p-0 text-lg my-0 text-center">
          {navlinks.map(({ id, link }) => (
            <li
              key={id}
              className="px-4 cursor-pointer capitalize text-white font-semibold lg:hover:scale-105 duration-200 lg:hover:text-gray-600 lg:inline-block items-center"
            >
              <Link to={link} smooth duration={500}>
                {link}
              </Link>
            </li>
          ))}
        </ul>
      </footer>
    );
  }
};

export default Footer;
