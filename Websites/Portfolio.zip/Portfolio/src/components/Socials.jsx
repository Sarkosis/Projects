import React from "react";
import {
  FaGithub,
  FaDiscord,
  FaYoutube,
  FaTiktok,
  FaTwitter,
  FaInstagram,
} from "react-icons/fa";
import config from "../config.json";

const Socials = () => {
  let links = [];
  if (config.socials.github.enabled === true) {
    links.push({
      id: 1,
      child: (
        <>
          Github <FaGithub size={30} />
        </>
      ),
      href: config.socials.github.url,
    });
  }

  if (config.socials.discord.enabled === true) {
    links.push({
      id: 2,
      child: (
        <>
          Discord <FaDiscord size={30} />
        </>
      ),
      href: config.socials.discord.url,
    });
  }

  if (config.socials.youtube.enabled === true) {
    links.push({
      id: 3,
      child: (
        <>
          Youtube <FaYoutube size={30} />
        </>
      ),
      href: config.socials.youtube.url,
    });
  }

  if (config.socials.tiktok.enabled === true) {
    links.push({
      id: 4,
      child: (
        <>
          Tiktok <FaTiktok size={30} />
        </>
      ),
      href: config.socials.tiktok.url,
    });
  }

  if (config.socials.twitter.enabled === true) {
    links.push({
      id: 5,
      child: (
        <>
          Twitter <FaTwitter size={30} />
        </>
      ),
      href: config.socials.twitter.url,
    });
  }

  if (config.socials.instagram.enabled === true) {
    links.push({
      id: 6,
      child: (
        <>
          Instagram <FaInstagram size={30} />
        </>
      ),
      href: config.socials.instagram.url,
    });
  }
  if (config.theme === 1) {
    return (
      <div className="hidden lg:flex flex-col top-[35%] left-0 fixed">
        <ul>
          {links.map(({ id, child, href }) => (
            <li
              key={id}
              className={
                "flex justify-between items-center w-40 h-14 px-4 ml-[-100px] hover:ml-[-10px] hover:rounded-md duration-30 bg-gradient-to-r from-cyan-500 to-blue-500"
              }
            >
              <a
                href={href}
                className="flex justify-between items-center w-full text-white"
              >
                {child}
              </a>
            </li>
          ))}
        </ul>
      </div>
    );
  } else if (config.theme === 2) {
    return (
      <div className="hidden lg:flex flex-col top-[35%] left-0 fixed">
        <ul>
          {links.map(({ id, child, href }) => (
            <li
              key={id}
              className={
                "flex justify-between items-center w-40 h-14 px-4 ml-[-100px] hover:ml-[-10px] hover:rounded-md duration-30 bg-blue-800"
              }
            >
              <a
                href={href}
                className="flex justify-between items-center w-full text-white"
              >
                {child}
              </a>
            </li>
          ))}
        </ul>
      </div>
    );
  }
};
export default Socials;
