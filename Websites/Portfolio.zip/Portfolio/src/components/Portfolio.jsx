import React from "react";
import config from "../config.json";

const Portfolio = () => {
  const portfolios = [];
  config.projects.forEach(async function (project, i) {
    if (project.enabled !== true) return;
    portfolios.push({
      id: i + 1,
      src: project.img,
      name: project.name,
      url: project.url,
    });
  });
  if (config.theme === 1) {
    return (
      <div
        name="portfolio"
        className="bg-gradient-to-b from-black to-gray-800 w-full text-white md:h-screen"
      >
        <div className="max-w-screen-lg p-4 mx-auto flex flex-col justify-center w-full h-full">
          <div className="pb-8">
            <p className="text-4xl font-bold inline border-b-4 border-gray-500">
              Portfolio
            </p>
            <p className="py-6">Check out some of my previous work!</p>
          </div>

          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-8 px-12 sm:px-0">
            {portfolios.map(({ id, src, name, url }) => (
              <div key={id} className="shadow-md rounded-lg shadow-blue-400">
                <img
                  src={src}
                  alt=""
                  className="rounded-md duration-200 hover:scale-105"
                />
                <div className="flex items-center justify-center">
                  <button className="w-1/2 px-6 py-3 m-4 duration-200 hover:scale-105">
                    <a href={url} target="_blank">
                      {name}
                    </a>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  } else if (config.theme === 2) {
    return (
      <div
        name="portfolio"
        className="bg-gradient-to-b from-gray-600 to-white w-full text-black md:h-screen"
      >
        <div className="max-w-screen-lg p-4 mx-auto flex flex-col justify-center w-full h-full">
          <div className="pb-8">
            <p className="text-4xl font-bold inline border-b-4 border-black">
              Portfolio
            </p>
            <p className="py-6">Check out some of my previous work!</p>
          </div>

          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-8 px-12 sm:px-0">
            {portfolios.map(({ id, src, name, url }) => (
              <div key={id} className="shadow-md rounded-lg shadow-slate-900">
                <img
                  src={src}
                  alt=""
                  className="rounded-md duration-200 hover:scale-105"
                />
                <div className="flex items-center justify-center">
                  <button className="w-1/2 px-6 py-3 m-4 duration-200 hover:scale-105">
                    <a href={url} target="_blank">
                      {name}
                    </a>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }
};

export default Portfolio;
