import React from "react";
import config from "../config.json";

const Expierence = () => {
  const techs = [];
  config.experience.forEach(async function (e, i) {
    if (e.enabled !== true) return;
    techs.push({
      id: i + 1,
      src: e.src,
      name: e.title,
    });
  });
  if (config.theme === 1) {
    return (
      <div
        name="experience"
        className="bg-gradient-to-b from-gray-800 to-black w-full h-screen"
      >
        <div className="max-w-screen-lg mx-auto p-4 flex flex-col justify-center w-full h-full text-white">
          <div>
            <p className="text-4xl font-bold border-b-4 border-gray-500 p-2 inline">
              Experience
            </p>
            <p className="py-6">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit.
            </p>
          </div>

          <div className="w-full grid grid-cols-2 sm:grid-cols-3 gap-8 text-center py-8 px-12 sm:px-0">
            {techs.map(({ id, src, name }) => (
              <div
                key={id}
                className={`shadow-md hover:scale-105 duration-500 py-2 rounded-lg shadow-blue-400`}
              >
                <img src={src} alt="" className="w-20 mx-auto" />
                <p className="mt-4">{name}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  } else if (config.theme === 2) {
    return (
      <div
        name="experience"
        className="bg-gradient-to-b from-white to-gray-600 w-full h-screen"
      >
        <div className="max-w-screen-lg mx-auto p-4 flex flex-col justify-center w-full h-full text-black">
          <div>
            <p className="text-4xl font-bold border-b-4 border-black p-2 inline">
              Experience
            </p>
            <p className="py-6">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit.
            </p>
          </div>

          <div className="w-full grid grid-cols-2 sm:grid-cols-3 gap-8 text-center py-8 px-12 sm:px-0">
            {techs.map(({ id, src, name }) => (
              <div
                key={id}
                className={`shadow-md hover:scale-105 duration-500 py-2 rounded-lg shadow-slate-900`}
              >
                <img src={src} alt="" className="w-20 mx-auto" />
                <p className="mt-4">{name}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }
};

export default Expierence;
