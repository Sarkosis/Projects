import Home from "./components/Home";
import NavBar from "./components/NavBar";
import Socials from "./components/Socials";
import About from "./components/About";
import Portfolio from "./components/Portfolio";
import Experience from "./components/Experience";
import Contact from "./components/Contact";
import Footer from "./components/Footer"
import config from "./config.json";

function App() {
  if (config.contacts.enabled === true && config.socials.enabled === true) {
    return (
      <div>
        <NavBar />
        <Home />
        <About />
        <Portfolio />
        <Experience />
        <Contact />
        <Socials />
        <Footer />
      </div>
    );
  } else if (
    config.contacts.enabled === true &&
    config.socials.enabled === false
  ) {
    return (
      <div>
        <NavBar />
        <Home />
        <About />
        <Portfolio />
        <Experience />
        <Contact />
        <Footer />
      </div>
    );
  } else if (
    config.contacts.enabled === false &&
    config.socials.enabled === true
  ) {
    return (
      <div>
        <NavBar />
        <Home />
        <About />
        <Portfolio />
        <Experience/>
        <Socials />
        <Footer />
      </div>
    );
  } else if (
    config.contacts.enabled === false &&
    config.socials.enabled === false
  ) {
    return (
      <div>
        <NavBar />
        <Home />
        <About />
        <Portfolio />
        <Experience />
        <Footer />
      </div>
    );
  }
}

export default App;
