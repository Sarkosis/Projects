CREATE DATABASE IF NOT EXISTS sarkdocs;
USE sarkdocs;
CREATE TABLE IF NOT EXISTS sitesettings(
    Name TEXT,
    Color TEXT,
    LoggingChannel TEXT,
    GuildID TEXT,
);
CREATE TABLE IF NOT EXISTS docscats(
    UniqueID TEXT,
    Name TEXT,
    Description TEXT,
    Link TEXT,
    Position INT,
    Views INT
);
CREATE TABLE IF NOT EXISTS docsarts(
    UniqueID TEXT,
    CategoryID TEXT,
    Title TEXT,
    Content TEXT,
    Link TEXT,
    DiscordRoleIDs TEXT,
    Position INT,
    Views INT
);

CREATE TABLE IF NOT EXISTS staff(UserID TEXT);

CREATE TABLE IF NOT EXISTS navbar(
    UniqueID TEXT, 
    Name TEXT, 
    Link TEXT
);

CREATE TABLE IF NOT EXISTS auditlogs(
    DateCreated TEXT,
    Title TEXT,
    Description TEXT
);

INSERT INTO auditlogs (DateCreated, Title, Description)
VALUES (
        "~~~",
        "Setup Complete",
        "You have completed the documentation site setup!"
    );
INSERT INTO staff (UserID)
VALUES ("828427080500379649");
INSERT INTO sitesettings (Name, Color, LoggingChannel, GuildID)
VALUES ("My Docs", "#04081E", "none", "none");