const config = require("./config.json");
const express = require("express");
const chalk = require("chalk");
const mysql = require("mysql");
const utils = require("hyperz-utils");
const backend = require("./backend.js");
const DiscordStrategy = require("passport-discord-hyperz").Strategy;
const passport = require("passport");
const fs = require("fs");
const app = express();
let con = mysql.createConnection(config.mysql);
backend.init(app, con);
passport.serializeUser(function (user, done) {
  done(null, user);
});
passport.deserializeUser(function (obj, done) {
  done(null, obj);
});
passport.use(
  new DiscordStrategy(
    {
      clientID: config.discord.oauthID,
      clientSecret: config.discord.oauthToken,
      callbackURL: `${
        config.domain.endsWith("/") ? config.domain.slice(0, -1) : config.domain
      }/auth/discord/callback`,
      scope: ["identify", "guilds", "email"],
      prompt: "consent",
    },
    function (accessToken, refreshToken, profile, done) {
      process.nextTick(function () {
        return done(null, profile);
      });
    }
  )
);

// Routing
app.get("/", async function (req, res) {
  await backend.resetLocals(app);
  if (req.isAuthenticated()) {
    con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
      if (e) { console.log(e); }
      let staff = false;
      if (row[0]) staff = true;
      res.render("index.ejs", {
        staff: staff,
        LoggedIn: true,
      });
    });
  } else {
    res.render("index.ejs", {
      staff: false,
      LoggedIn: false,
    });
  }
});

app.get("/a/:articlelink", async function (req, res) {
  if (!req.params.articlelink) return res.redirect("/404");
  req.params.articlelink = await backend.sanitize(req.params.articlelink);
  con.query(`SELECT * FROM docsarts WHERE Link = "${req.params.articlelink}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    let article = row[0];
    con.query(`SELECT * FROM docscats WHERE UniqueID = "${article.CategoryID}"`, async (e, row) => {
      if (e) { console.log(e); }
      if (!row[0]) return res.redirect("/404");
      let category = row[0];
      return res.redirect(`/c/${category.Link}/${article.Link}`);
    });
  });
});

app.get("/c/:catlink", async function (req, res) {
  await backend.resetLocals(app);
  if (!req.params.catlink) return res.redirect("/404");
  req.params.catlink = await backend.sanitize(req.params.catlink);
  con.query(`SELECT * FROM docscats WHERE Link = "${req.params.catlink}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    let category = row[0];
    category.Description = await utils.mdConvert(category.Description);
    con.query(`SELECT * FROM docsarts WHERE CategoryID = "${category.UniqueID}"`, async (e, row) => {
      if (e) { console.log(e); }
      let articles = row || [];
      con.query(`UPDATE docscats SET Views = "${Number(category.Views + 1)}" WHERE UniqueID = "${category.UniqueID}"`, async (e) => {
        if (e) { console.log(e); }
        if (req.isAuthenticated()) {
          con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
            if (e) { console.log(e); }
            let staff = false;
            if (row[0]) staff = true;
            res.render("category.ejs", {
              category: category,
              articles: articles,
              staff: staff,
              LoggedIn: true
            });
          });
        } else {
          res.render("category.ejs", {
            category: category,
            articles: articles,
            staff: false,
            LoggedIn: false
          });
        }
      });
    });
  });
});

app.get("/c/:catlink/:articlelink", async function (req, res) {
 await backend.resetLocals(app);
 if (!req.params.catlink) return res.redirect("/404");
 if (!req.params.articlelink) return res.redirect("/404");
 req.params.catlink = await backend.sanitize(req.params.catlink);
 req.params.articlelink = await backend.sanitize(req.params.articlelink);
 con.query(`SELECT * FROM docscats WHERE Link = "${req.params.catlink}"`, async (e, row) => {
  if (e) { console.log(e); }
  if (!row[0]) return res.redirect("/404");
  let category = row[0];
  con.query(`SELECT * FROM docsarts WHERE CategoryID = "${category.UniqueID}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    let articles = row || [];
    con.query(`SELECT * FROM docsarts WHERE Link = "${req.params.articlelink}"`, async (e, row) => {
      if (e) { console.log(e); }
      if (!row[0]) return res.redirect("/404");
      let article = row[0];
      if (article.DiscordRoleIDs !== "none") {
        let roles = await backend.hasRole(req.session?.passport?.user?.id || null, article);
        if (roles == false) { 
          article.Content = await utils.mdConvert(":::danger\nYou don't have the required discord roles to view this article!\n:::"); 
        } else article.Content = await utils.mdConvert(article.Content);
      } else article.Content = await utils.mdConvert(article.Content);
      con.query(`UPDATE docsarts SET Views = "${Number(article.Views + 1)}" WHERE UniqueID = "${article.UniqueID}"`, async (e) => {
        if (e) { console.log(e); }
        if (req.isAuthenticated()) {
          con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
            if (e) { console.log(e); }
            let staff = false;
            if (row[0]) staff = true;
            res.render("article.ejs", {
              category: category,
              articles: articles,
              article: article,
              staff: staff,
              LoggedIn: true,
            });
          });
        } else {
          res.render("article.ejs", {
            category: category,
            articles: articles,
            article: article,
            staff: false,
            LoggedIn: false,
          });
        }
      });
    });
  });
 });
});

app.get('/search', async function(req, res) {
  await backend.resetLocals(app);
  if (req.isAuthenticated()) {
    con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
      if (e) { console.log(e); }
      let staff = false;
      if (row[0]) staff = true;
      res.render('search.ejs', { 
        search: { valid: false, results: {  } },
        staff: staff,
        LoggedIn: true 
      });
    });
  } else {
    res.render('search.ejs', { 
      search: { valid: false, results: {  } },
      staff: false,
      LoggedIn: false
    });
  }
});

app.post('/search', async function(req, res) {
  await backend.resetLocals(app);
  req.body.search = await backend.sanitize(req.body.search);
  con.query(`SELECT * FROM docscats WHERE Name LIKE "%${req.body.search}%"`, async (err, row) => {
    if (err) { console.log(err); }
    let valid = true;
    let categories = row || [];
    con.query(`SELECT * FROM docsarts WHERE Title LIKE "%${req.body.search}%"`, async (err, row) => {
      if (err) { console.log(err); }
      let articles = row || [];
      if (!articles[0] && !categories[0]) valid = false;
      if(req.isAuthenticated()) {
        con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
          if (e) { console.log(e); }
          let staff = false;
          if (row[0]) staff = true;
          res.render('search.ejs', { 
            search: { valid: valid, results: { categories: categories, articles: articles }, query: req.body.search },
            staff: staff,
            LoggedIn: true 
          });
        });
      } else {
          res.render('search.ejs', { 
          search: { valid: valid, results: { categories: categories, articles: articles }, query: req.body.search },
          staff: false,
          LoggedIn: false 
        });
      };
    });
  });
});

app.get("/admin", async function (req, res) {
  await backend.resetLocals(app);
  if (req.isAuthenticated()) { 
    con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
      if (e) { console.log(e); }
      if (!row[0]) return res.redirect("/404");
      await backend.audit("Admin Page Accessed", `${req.session.passport.user.username} (${req.session.passport.user.id}) has accessed the site's administrator page!`);
      return res.render("admin.ejs", {
        staff: true,
        LoggedIn: true,
        user: req.session.passport.user,
      });
    });
  } else return res.redirect("/auth/discord");
});

app.get("/admin/:category", backend.checkAuth, async function (req, res) {
  await backend.resetLocals(app);
  const logs = await backend.fetchFromTable("auditlogs");
  const articles = await backend.fetchFromTable("docsarts");
  const categories = await backend.fetchFromTable("docscats");
  const nav = await backend.fetchFromTable("navbar");
  const settings = await backend.fetchFromTable("sitesettings");
  const staff = await backend.fetchFromTable("staff");
  let data = {
    logs: logs,
    articles: articles,
    categories: categories,
    nav: nav,
    settings: settings[0],
    staff: staff
  };
  if (!fs.existsSync(`./src/views/admin_${req.params.category}.ejs`)) return res.redirect("/404");
  con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    res.render(`admin_${req.params.category}.ejs`, {
      data: data,
      staff: true,
      user: req.session.passport.user,
      LoggedIn: true
    });
  });
});

app.get("/admin/edit/:type/:uniqueid", backend.checkAuth, async function (req, res) {
  await backend.resetLocals(app);
  if (!req.params.type) return res.redirect("/404");
  if (!req.params.uniqueid) return res.redirect("/404");
  con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    switch (req.params.type) {
      case "category": {
        con.query(`SELECT * FROM docscats WHERE UniqueID = "${req.params.uniqueid}"`, async (e, row) => {
          if (e) { console.log(e); }
          if (!row[0]) return res.redirect("/404");
          let category = row[0];
          await backend.audit("Category Edited", `${req.session.passport.user.username} (${req.session.passport.user.id}) has edited a category (${category.Name}).`)
          res.render("admin_editcategory.ejs", {
            category: category,
            staff: true,
            user: req.session.passport.user,
            LoggedIn: true
          });
        });
      }
      break;
      case "article": {
        con.query(`SELECT * FROM docsarts WHERE UniqueID = "${req.params.uniqueid}"`, async (e, row) => {
          if (e) { console.log(e); }
          if (!row[0]) return res.redirect("/404");
          let article = row[0];
          await backend.audit("Article Edited", `${req.session.passport.user.username} (${req.session.passport.user.id}) has edited an article (${article.Title}).`)
          res.render("admin_editarticle.ejs", {
            article: article,
            staff: true,
            user: req.session.passport.user,
            LoggedIn: true
          });
        });
      }
      break;
    
      default:
        break;
    }
  });
});

app.post("/backend/create/staff", backend.checkAuth, async function (req, res) {
  await backend.resetLocals(app);
  con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    req.body.userid = await backend.sanitize(req.body.userid);
    con.query(`INSERT INTO staff (UserID) VALUES ("${req.body.userid}")`, async (e) => {
      if (e) { console.log(e); }
      await backend.audit("Staff Created", `${req.session.passport.user.username} (${req.session.passport.user.id}) has added a user to the staff team (${req.body.userid}).`);
      return res.redirect("/admin/settings");
    });
  });
});

app.post("/backend/create/nav", backend.checkAuth, async function (req, res) {
  await backend.resetLocals(app);
  con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    req.body.buttonname = await backend.sanitize(req.body.buttonname);
    req.body.buttonlink = await backend.sanitize(req.body.buttonlink);
    let uniqueid = await backend.genRandom(12);
    con.query(`INSERT INTO navbar (UniqueID, Name, Link) VALUES ("${uniqueid}", "${req.body.buttonname}", "${req.body.buttonlink}")`, async (e) => {
      if (e) { console.log(e); }
      await backend.audit("Nav Button Created", `${req.session.passport.user.username} (${req.session.passport.user.id}) has created a new navigation button (${req.body.buttonname}).`);
      return res.redirect("/admin/settings");
    });
  });
});

app.post("/backend/create/category", backend.checkAuth, async function(req, res) {
  await backend.resetLocals(app);
  con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    req.body.name = await backend.sanitize(req.body.name);
    req.body.link = await backend.sanitize(req.body.link);
    req.body.position = await backend.sanitize(req.body.position);
    req.body.description = await backend.sanitize(req.body.description);
    let uniqueid = await backend.genRandom(15);
    con.query(`INSERT INTO docscats (UniqueID, Name, Description, Link, Position, Views) VALUES ("${uniqueid}", "${req.body.name}", "${req.body.description}", "${req.body.link}", "${req.body.position}", "0")`, 
    async (e) => {
      if (e) { console.log(e); }
      try {
        fs.writeFileSync(`./public/images/category-${uniqueid}.png`, req.files[0].buffer);
      } catch (e) {}
      await backend.audit("Category Created", `${req.session.passport.user.username} (${req.session.passport.user.id}) has created a new documentation category (${req.body.name}).`);
      await backend.discord("📰 New Category", `${req.session.passport.user.username} has created a new documentation [category](${config.domain.endsWith("/") ? config.domain.slice(0, -1) : config.domain}/c/${req.body.link})`);
      return res.redirect("/admin/categories");
    });
  });
});

app.post("/backend/create/article", backend.checkAuth, async function(req, res) {
  await backend.resetLocals(app);
  con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    req.body.categoryid= await backend.sanitize(req.body.categoryid);
    req.body.title = await backend.sanitize(req.body.title);
    req.body.link = await backend.sanitize(req.body.link);
    req.body.position = await backend.sanitize(req.body.position);
    req.body.description = await backend.sanitize(req.body.description);
    req.body.roleid = await backend.sanitize(req.body.roleid);
    let uniqueid = await backend.genRandom(15);
    con.query(`INSERT INTO docsarts (UniqueID, CategoryID, Title, Content, Link, DiscordRoleIDs, Position, Views) VALUES ("${uniqueid}", "${req.body.categoryid}", "${req.body.title}", "${req.body.description}", "${req.body.link}", "${req.body.roleid || "none"}", "${req.body.position}", "0")`, async (e) => {
      if (e) { console.log(e); }
      await backend.audit("Article Created", `${req.session.passport.user.username} (${req.session.passport.user.id}) has created a new documentation article (${req.body.title}).`);
      await backend.discord("📰 New Article", `${req.session.passport.user.username} has created a new documentation article`);
      return res.redirect("/admin/articles");
    });
  });
});

app.post("/backend/update/category/:uniqueid", backend.checkAuth, async function (req, res) {
  await backend.resetLocals(app);
  if (!req.params.uniqueid) return res.redirect("/404");
  con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    req.body.name = await backend.sanitize(req.body.name);
    req.body.link = await backend.sanitize(req.body.link);
    req.body.position = await backend.sanitize(req.body.position);
    req.body.description = await backend.sanitize(req.body.description);
    con.query(`UPDATE docscats SET Name = "${req.body.name}", Description = "${req.body.description}", Link = "${req.body.link}", Position = "${req.body.position}" WHERE UniqueID = "${req.params.uniqueid}"`,
    async (e) => {
      if (e) { console.log(e); }
      if (req.files[0]) {
        fs.writeFileSync(`./public/images/category-${req.params.uniqueid}.png`, req.files[0].buffer);
      }
      await backend.audit("Category Updated", `${req.session.passport.user.username} (${req.session.passport.user.id}) has updated a category (${req.body.name}).`);
      return res.redirect("/admin/categories");
    });
  });
});

app.post("/backend/update/article/:uniqueid", backend.checkAuth, async function (req, res) {
  await backend.resetLocals(app);
  if (!req.params.uniqueid) return res.redirect("/404");
  con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    req.body.categoryid= await backend.sanitize(req.body.categoryid);
    req.body.title = await backend.sanitize(req.body.title);
    req.body.link = await backend.sanitize(req.body.link);
    req.body.position = await backend.sanitize(req.body.position);
    req.body.description = await backend.sanitize(req.body.description);
    req.body.roleid = await backend.sanitize(req.body.roleid);
    con.query(`UPDATE docsarts SET CategoryID = "${req.body.categoryid}", Title = "${req.body.title}", Content = "${req.body.description}", Link = "${req.body.link}", DiscordRoleIDs = "${req.body.roleid}", Position = "${req.body.position}" WHERE UniqueID = "${req.params.uniqueid}"`, async (e) => {
      if (e) { console.log(e); }
      await backend.audit("Articles Updated", `${req.session.passport.user.username} (${req.session.passport.user.id}) has updated an article (${req.body.title}).`);
      return res.redirect("/admin/articles");
    });
  });
});

app.post("/backend/update/settings", backend.checkAuth, async function (req, res) {
  con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    req.body.name = await backend.sanitize(req.body.name);
    req.body.color = await backend.sanitize(req.body.color);
    req.body.guildid = await backend.sanitize(req.body.guildid);
    req.body.loggingchannelid = await backend.sanitize(req.body.loggingchannelid);
    let validhex = await backend.checkHex(req.body.color);
    if (validhex.valid == false) req.body.color = validhex.hex; 
    con.query(`UPDATE sitesettings SET Name = "${req.body.name}", Color = "${req.body.color}", GuildID = "${req.body.guildid}", LoggingChannel = "${req.body.loggingchannelid}"`, async (e) => {
      if (e) { console.log(e); }
      if (typeof req.files != 'undefined' && req.files[0]) {

        await req.files.forEach(function(file) {
          if(file.fieldname == 'siteicon') {
              fs.writeFileSync(`./public/assets/logo.png`, file.buffer);
          } else if(file.fieldname == 'sitebg') {
              fs.writeFileSync(`./public/assets/background.jpg`, file.buffer);
          };
      });
      }
      await backend.discord("⚙️ Site Settings Updated", `${req.session.passport.user.username} has updated the site settings.`);
      await backend.audit("Settings Updated", `${req.session.passport.user.username} (${req.session.passport.user.id}) has updated the site settings.`);
      return res.redirect("/admin/settings");
    });
  });
});

app.get("/backend/delete/article/:uniqueid", backend.checkAuth, async function (req, res) {
  await backend.resetLocals(app);
  if (!req.params.uniqueid) return res.redirect("/404");
  con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    req.params.uniqueid = await backend.sanitize(req.params.uniqueid);
    con.query(`DELETE FROM docsarts WHERE UniqueID = "${req.params.uniqueid}" LIMIT 1`, async (e) => {
      if (e) { console.log(e); }
      await backend.audit("Article Deleted", `${req.session.passport.user.username} (${req.session.passport.user.id}) has deleted an article.`);
      return res.redirect("/admin/articles");
    });
  });
});

app.get("/backend/delete/category/:uniqueid", backend.checkAuth, async function (req, res) {
  await backend.resetLocals(app);
  if (!req.params.uniqueid) return res.redirect("/404");
  con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    req.params.uniqueid = await backend.sanitize(req.params.uniqueid);
    con.query(`DELETE FROM docscats WHERE UniqueID = "${req.params.uniqueid}" LIMIT 1`, async (e) => {
      if (e) { console.log(e); }
      await backend.audit("Category Deleted", `${req.session.passport.user.username} (${req.session.passport.user.id}) has deleted a category.`);
      return res.redirect("/admin/categories");
    });
  });
});

app.get("/backend/delete/staff/:userid", backend.checkAuth, async function (req, res) {
  await backend.resetLocals(app);
  if (!req.params.userid) return res.redirect("/404");
  con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    req.params.userid = await backend.sanitize(req.params.userid);
    con.query(`DELETE FROM staff WHERE UserID = "${req.params.userid}" LIMIT 1`, async (e) => {
      if (e) { console.log(e); }
      await backend.audit("Staff Deleted", `${req.session.passport.user.username} (${req.session.passport.user.id}) has deleted a user from the staff team (${req.params.userid}).`);
      return res.redirect("/admin/settings");
    });
  });
});

app.get("/backend/delete/nav/:uniqueid", backend.checkAuth, async function (req, res) {
  await backend.resetLocals(app);
  if (!req.params.uniqueid) return res.redirect("/404");
  con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    req.params.uniqueid = await backend.sanitize(req.params.uniqueid);
    con.query(`DELETE FROM navbar WHERE UniqueID = "${req.params.uniqueid}" LIMIT 1`, async (e) => {
      if (e) { console.log(e); }
      await backend.audit("Nav Button Deleted", `${req.session.passport.user.username} (${req.session.passport.user.id}) has deleted a navigation button.`);
      return res.redirect("/admin/settings");
    });
  });
});

app.get("/backend/delete/logs", backend.checkAuth, async function (req, res) {
  con.query(`SELECT * FROM staff WHERE UserID = "${req.session.passport.user.id}"`, async (e, row) => {
    if (e) { console.log(e); }
    if (!row[0]) return res.redirect("/404");
    if (config.ownerIDs.includes(req.session.passport.user.id)) {
      con.query(`DELETE FROM auditlogs`, async (e) => {
        if (e) { console.log(e); }
        return res.redirect("/admin/logs");
      });
    } else return res.send({ error: "Only the site owners can reset audit logs!"});
  });
});


app.get("/auth/discord", passport.authenticate("discord"));
app.get("/logout", async function (req, res) {
  req.logout(function (e) {
    if (e) { return next(e); }
    res.redirect("/");
  });
});

app.get(
  "/auth/discord/callback",
  passport.authenticate("discord", { failureRedirect: "/" }),
  async function (req, res) {
    req.session?.loginRef
      ? res.redirect(req.session.loginRef)
      : res.redirect("/");
    delete req.session?.loginRef;
  }
);

app.get("/dev", async (req, res) => { res.redirect("https://discord.gg/hekkjCywmT"); });
app.get("/creator", async (req, res) => { res.redirect("https://discord.gg/hekkjCywmT"); });
app.get("/designer", async (req, res) => { res.redirect("https://discord.gg/hekkjCywmT"); });
app.get("/developer", async (req, res) => { res.redirect("https://discord.gg/hekkjCywmT"); });
app.get("/maker", async (req, res) => { res.redirect("https://discord.gg/hekkjCywmT"); });

app.get("/404", function (req, res) {
  if (req.isAuthenticated()) {
    res.render("404.ejs", { LoggedIn: true });
  } else res.render("404.ejs", { LoggedIn: false });
});

app.get("*", function (req, res) {
  res.redirect("/404");
});

app.listen(config.port);

process.on("unhandledRejection", (err) => {
  if (config.debugMode) console.log(chalk.red(err));
});
