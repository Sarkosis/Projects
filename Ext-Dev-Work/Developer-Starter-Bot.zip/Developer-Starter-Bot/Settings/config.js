const config = {
  bot: {
    clientID: "", // Bot ID.
    token: "", // Bot Token,.
    dbtoken: "", // MongoDB URI.
    license: "", // Product License at https://thedevszone.com
  },
  theme: {
    color: "#000000", // Color theme usng HEX code.
  },
  tickets: {
    ticketlimit: 1, // How many tickets can a member have open at one time?
  },
  stats: {
    presence: "Visual Studio Code", // custom presence.
    activity: "Playing", // activity type; Competing in, Playing, Watching, Listening to, Streaming.
    status: "dnd", // idle, dnd, online, invisible.
  },
};

module.exports = config;
