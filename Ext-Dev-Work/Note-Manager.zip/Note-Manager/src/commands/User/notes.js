const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const utils = require("hyperz-utils");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("note")
    .setDescription("Manage your notes")
    .addSubcommand((sub) =>
      sub
        .setName("create")
        .setDescription("Create a new note!")
        .addStringOption((o) =>
          o.setName("note").setDescription("Input your note").setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("delete")
        .setDescription("Delete a note!")
        .addNumberOption((o) =>
          o
            .setName("noteid")
            .setDescription("Input your note id")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub.setName("view").setDescription("View all of your notes")
    ),

  async execute(interaction, client) {
    let { options } = interaction;
    let sub = options.getSubcommand();
    let note = options.getString("note");
    let noteid = options.getNumber("noteid");
    switch (sub) {
      case "create":
        {
          let date = await utils.fetchTime(
            client.config.time.tz,
            client.config.time.format
          );
          await client.con.query(
            `SELECT COUNT(*) as total FROM notes WHERE userid = "${interaction.user.id}"`,
            async (e, res) => {
              if (e) {
                if (client.config.debugmode) {
                  console.log(e.stack);
                }
              }
              let id = res[0]?.total + 1;
              await client.con.query(
                `SELECT * FROM notes WHERE userid = "${interaction.user.id}" AND noteid = '${id}'`,
                async (e, row) => {
                  if (e) {
                    if (client.config.debugmode) {
                      console.log(e.stack);
                    }
                  }
                  if (row[0]) id++;
                  await client.con.query(
                    `INSERT INTO notes (noteid, userid, note, datecreated) VALUES ("${id}", "${interaction.user.id}", "${note}", "${date}")`,
                    async (e) => {
                      if (e) {
                        if (client.config.debugmode) {
                          console.log(e.stack);
                        }
                      }
                      return interaction.reply({
                        content: `Your note was saved to the data base as note #${id}`,
                        ephemeral: true,
                      });
                    }
                  );
                }
              );
            }
          );
        }

        break;
      case "delete":
        {
          await client.con.query(
            `SELECT * FROM notes WHERE userid = "${interaction.user.id}" AND noteid = "${noteid}"`,
            async (e, row) => {
              if (e) {
                if (client.config.debugmode) {
                  console.log(e.stack);
                }
              }
              if (!row[0]) {
                return interaction.reply({
                  content: "No note was found with the inserted ID",
                  ephemeral: true,
                });
              }
              await client.con.query(
                `DELETE FROM notes WHERE userid = "${interaction.user.id}" AND noteid = '${noteid}'`,
                async (e) => {
                  if (e) {
                    if (client.config.debugmode) {
                      console.log(e.stack);
                    }
                  }
                  return interaction.reply({
                    content: `Note #${noteid} was deleted!`,
                    ephemeral: true,
                  });
                }
              );
            }
          );
        }

        break;
      case "view":
        {
          await client.con.query(
            `SELECT * FROM notes WHERE userid = '${interaction.user.id}'`,
            async (e, rows) => {
              if (e) {
                if (client.config.debugmode) {
                  console.log(e.stack);
                }
              }
              let embed = new EmbedBuilder()
                .setColor(client.config.color)
                .setTitle(`${interaction.user.tag}'s Notes`)
                .setDescription("View your notes below!");
              let fields = [];
              rows.forEach((row) => {
                if (fields.length == 25) return;
                fields.push({
                  name: `Note #${row.noteid}`,
                  value: `${row.note}\n\n**Created ${row.datecreated}**`,
                });
              });
              embed.addFields(fields);
              return interaction.reply({
                embeds: [embed],
                ephemeral: true,
              });
            }
          );
        }
        break;

      default:
        break;
    }
  },
};
