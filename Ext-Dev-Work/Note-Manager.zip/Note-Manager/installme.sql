CREATE DATABASE IF NOT EXISTS notemanager;
USE notemanager;
CREATE TABLE IF NOT EXISTS notes(
    noteid TEXT,
    userid TEXT,
    note TEXT,
    datecreated TEXT
);
CREATE TABLE IF NOT EXISTS staff(userid TEXT);