CREATE TABLE IF NOT EXISTS ticketsettings(
    GuildID VARCHAR(255) PRIMARY KEY,
    TranscriptChannel VARCHAR(255),
    Category VARCHAR(255),
    StaffRole VARCHAR(255)
);
CREATE TABLE IF NOT EXISTS panels(
    GuildID VARCHAR(255),
    TicketName VARCHAR(255),
    TicketDescription TEXT
);
CREATE TABLE IF NOT EXISTS ticketdata(
    GuildID VARCHAR(255),
    OpenMember VARCHAR(255),
    CloseMember VARCHAR(255),
    CreatedTimestamp VARCHAR(255),
    ClosedTimeStamp VARCHAR(255),
    TicketType VARCHAR(255),
    Locked BOOLEAN,
    Closed BOOLEAN,
    ChannelID VARCHAR(255),
    TicketID INT NOT NULL AUTO_INCREMENT,
    PRIMARY KEY (TicketID)
);
CREATE TABLE IF NOT EXISTS stickymessages(
    GuildID VARCHAR(255),
    ChannelID VARCHAR(255),
    StickyMessage TEXT
);