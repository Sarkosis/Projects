const config = {
  bot: {
    clientID: "", // Bot ID
    token: "", // Bot Token,
  },
  theme: {
    color: "#000000", // Color theme using Hex codes
  },
};

module.exports = config;
