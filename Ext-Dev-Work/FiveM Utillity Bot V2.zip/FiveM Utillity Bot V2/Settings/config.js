const config = {
  bot: {
    clientID: "1046926284900540477", // Bot's ID
    token: "MTA0NjkyNjI4NDkwMDU0MDQ3Nw.GxeWq3.WuVsQAdrYmSFpklqTCZQPMJxPvqKMf0hXPC4mM", // Bot's Token
    dbtoken: "mongodb+srv://Sarkosis:SadCowboy101@cluster0.vtqr8t4.mongodb.net/test", // Mongo URI Connection
  },
};

module.exports = config;
