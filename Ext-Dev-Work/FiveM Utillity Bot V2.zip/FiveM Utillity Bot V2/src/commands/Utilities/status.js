const { EmbedBuilder, SlashCommandBuilder } = require("discord.js");
const FiveM = require("fivem");
const embedSchema = require("../../schemas/embedSettings");
const fivemSchema = require("../../schemas/fivemSettings");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("status")
    .setDescription("Shows the fiveM server status"),
  async execute(interaction, client) {
    if (interaction.channel.isDMBased())
      return interaction.reply({
        content: "You cannot use this command in Direce Messages!",
        ephemeral: true,
      });
    const embedData = await embedSchema.findOne({
      GuildID: interaction.guild.id,
    });
    const fivemData = await fivemSchema.findOne({
      GuildID: interaction.guild.id,
    });

    if (!fivemData)
      return interaction.reply({
        content:
          "Please setup the fivem server settings before using this command!",
        ephemeral: true,
      });
    const server = new FiveM.Server(fivemData?.ServerIP);
    const embed = new EmbedBuilder();
    embed.setColor(embedData?.Color || "White");
    embed.setAuthor({
      name: `${fivemData?.ServerName} Server Status`,
      iconURL: interaction.guild.iconURL(),
    });
    const status = JSON.stringify(await server.getServerStatus());
    if (status.includes("true")) {
      embed.addFields({ name: "Server Status", value: "`Online!`" });
      embed.setColor("Green");
    } else {
      embed.setFields({ name: "Server Status", value: "`Offline!`" });
      embed.setColor("Red");
    }
    embed.addFields({
      name: "Active Players",
      value: `\`${
        (await server.getPlayers()) + "/" + (await server.getMaxPlayers())
      }\``,
      inline: true,
    });
    embed.addFields({ name: "\u200b", value: "\u200b", inline: true });
    embed.setColor("Green");
    embed.addFields({
      name: "Server Connect",
      value: `\`${fivemData?.ServerConnectURL}\``,
      inline: true,
    });
    embed.setFooter({
      text: embedData?.Footer || interaction.guild.name,
      iconURL: embedData?.IconURL || interaction.guild.iconURL(),
    });
    embed.setThumbnail(embedData?.Thumbnail || interaction.guild.iconURL());
    return interaction.reply({ embeds: [embed] });
  },
};
