const { EmbedBuilder, SlashCommandBuilder } = require("discord.js");
const fivem = require("discord-fivem-api");
const embedSchema = require("../../schemas/embedSettings");
const fivemSchema = require("../../schemas/fivemSettings");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("players")
    .setDescription("Get the FiveM server's player count"),
  async execute(interaction, client) {
    if (interaction.channel.isDMBased())
      return interaction.reply({
        content: "You cannot use this command in Direce Messages!",
        ephemeral: true,
      });
    const embedData = await embedSchema.findOne({
      GuildID: interaction.guild.id,
    });
    const fivemData = await fivemSchema.findOne({
      GuildID: interaction.guild.id,
    });
    if (!fivemData)
      return interaction.reply({
        content:
          "Please setup the fivem server settings before using this command!",
        ephemeral: true,
      });
    const server = new fivem.DiscordFivemApi(fivemData?.ServerIP);
    server.getPlayers().then((data) => {
      let result = [];
      let index = 1;
      for (let player of data) {
        result.push(
          `\n > ${player.name} | ID: ${player.id} | Ping: ${player.ping}`
        );
      }
      const embed = new EmbedBuilder()
        .setColor(embedData?.Color || "White")
        .setAuthor({
          name: `${fivemData?.ServerName} Server Players`,
          iconURL: interaction.guild.iconURL(),
        })
        .setTitle(`Players (${data.length}/${fivemData?.ServerCap})`)
        .setDescription(`${result.length > 0 ? result : "No Players Online!"}`)
        .addFields({
          name: "Active Players",
          value: `\`${data.length + "/" + `${fivemData?.ServerCap}`}\``,
          inline: true,
        })
        .addFields({
          name: "Server Connect",
          value: `\`connect ${fivemData?.ServerConnectURL}\``,
          inline: true,
        })
        .setThumbnail(embedData?.Thumbnail || interaction.guild.iconURL())
        .setFooter({
          text: embedData?.Footer || interaction.guild.name,
          iconURL: embedData?.IconURL || interaction.guild.iconURL(),
        })
        .setTimestamp();
      return interaction.reply({ embeds: [embed] });
    });
  },
};
