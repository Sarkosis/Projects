const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const embedSchema = require("../../schemas/embedSettings");
const fivemSchema = require("../../schemas/fivemSettings");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("fivem-server-info")
    .setDescription("Show the FiveM Server information"),
  async execute(interaction, client) {
    if (interaction.channel.isDMBased())
      return interaction.reply({
        content: "You cannot use this command in Direce Messages!",
        ephemeral: true,
      });
    const embedData = await embedSchema.findOne({
      GuildID: interaction.guild.id,
    });
    const fivemData = await fivemSchema.findOne({
      GuildID: interaction.guild.id,
    });
    if (!fivemData)
      return interaction.reply({
        content:
          "Please setup the fivem server settings before using this command!",
        ephemeral: true,
      });
    const embed = new EmbedBuilder();
    embed.setColor(embedData?.Color || "White");
    embed.setAuthor({
      name: `${fivemData?.ServerName} Server Info`,
      iconURL: interaction.guild.iconURL(),
    });
    embed.setColor(embedData?.Color || "White").addFields(
      {
        name: `Server Connect`,
        value: `> ${fivemData?.ServerConnectURL}`,
        inline: false,
      },
      {
        name: `Server Store`,
        value: `> ${fivemData?.Store}`,
        inline: false,
      },
      {
        name: `Server Website`,
        value: `> ${fivemData?.ServerSite}`,
        inline: false,
      },
      {
        name: `Server Owner`,
        value: `> 👑 <@${fivemData?.OwnerID}>`,
        inline: false,
      }
    );
    embed
      .setThumbnail(embedData?.Thumbnail || interaction.guild.iconURL())
      .setFooter({
        text: embedData?.Footer || interaction.guild.name,
        iconURL: embedData?.IconURL || interaction.guild.iconURL(),
      });
    return interaction.reply({ embeds: [embed] });
  },
};
