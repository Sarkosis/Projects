const {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
} = require("discord.js");
const modSchema = require("../../schemas/moderationSetting");
const embedSchema = require("../../schemas/embedSettings");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("unban")
    .setDescription("Unban a member")
    .addUserOption((option) =>
      option
        .setName("user")
        .setDescription("User being unbanned")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("Reason for unbanning the user")
        .setRequired(true)
    ),

  async execute(interaction, client) {
    if (interaction.channel.isDMBased())
      return interaction.reply({
        content: "You cannot use this command in a DM Channel!",
        ephemeral: true,
      });
    const user = interaction.options.getUser("user");
    const reason = interaction.options.getString("reason");
    const { member, guild } = interaction;
    const embedData = await embedSchema.findOne({ GuildID: guild.id });
    const modData = await modSchema.findOne({ GuildID: guild.id });
    if (!modData || !modData?.ChannelID || !modData?.unban?.RoleID)
      return interaction.reply({
        content:
          "Please configure the unban permissions before using this command!",
        ephemeral: true,
      });
    // Role permissions check
    if (!member.roles.cache.some((role) => role.id === modData?.unban.RoleID))
      return interaction.reply({
        content: permData?.Message || "You cannot use this command!",
        ephemeral: true,
      });

    // Permissions check for bot
    if (!guild.members.me.permissions.has(PermissionFlagsBits.BanMembers))
      return interaction.reply({
        content: "I don't have the permissions for this.",
        ephemeral: true,
      });
    const embed = new EmbedBuilder();
    embed
      .setAuthor({
        name: `${client.user.username}`,
        iconURL: `${client.user.displayAvatarURL()}`,
      })
      .setColor(embedData?.Color || "White")
      .setTitle("**__Unbanned User__**")
      .setDescription(
        `> **__Unbanned User:__** <@${user.id}> (${user.id})\n > **__Executor:__** ${member} (${member.id})\n > **__Reason:__** ${reason}`
      )
      .setThumbnail(embedData?.Thumbnail || `${guild.iconURL()}`)
      .setFooter({
        text: `User Unbanned `,
        iconURL: embedData.IconURL || `${client.user.displayAvatarURL()}`,
      })
      .setTimestamp();
    await guild.bans.fetch().then(async (bans) => {
      if (bans.size == 0)
        return interaction.reply({
          content: "No bans detected in this guild.",
          ephemeral: true,
        });
      let bannedID = await bans.find((ban) => ban.user.id == user.id);
      if (!bannedID)
        return interaction.reply({
          content: "User is not banned from this guild.",
          ephemeral: true,
        });
      if (bannedID) {
        await guild.bans.remove(user.id);
        interaction.reply({
          embeds: [embed],
        });
        const channel = await guild.channels.fetch(modData?.ChannelID);
        embed
          .setAuthor({
            name: `${client.user.username}`,
            iconURL: `${client.user.displayAvatarURL()}`,
          })
          .setColor(embedData?.Color || "White")
          .setTitle("**__New Action Log__**")
          .setDescription(
            `> **__Unbanned User:__** <@${user.id}> (${user.id})\n > **__Executor:__** ${member} (${member.id})\n > **__Reason:__** ${reason}`
          )
          .setThumbnail(embedData?.Thumbnail || `${guild.iconURL()}`)
          .setFooter({
            text: `User Unbanned `,
            iconURL: embedData.IconURL || `${client.user.displayAvatarURL()}`,
          })
          .setTimestamp();
        const webhooks = await channel.fetchWebhooks();
        const webhook = webhooks.find((wh) => wh.name === "Action Logs");
        if (webhook) {
          await webhook.send({
            embeds: [embed],
          });
        } else {
          channel
            .createWebhook({
              name: "Action Logs",
              avatar: `${client.user.displayAvatarURL()}`,
              reason: "Logs",
            })
            .then((wh) => {
              wh.send({
                embeds: [embed],
              });
            });
        }
      } else return;
    });
  },
};
