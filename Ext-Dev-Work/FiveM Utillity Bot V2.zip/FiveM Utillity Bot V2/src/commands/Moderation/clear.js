const {
  SlashCommandBuilder,
  ChannelType,
  EmbedBuilder,
} = require("discord.js");
const modSchema = require("../../schemas/moderationSetting");
const embedSchema = require("../../schemas/embedSettings");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("clear")
    .setDescription("Clear the chat")
    .addChannelOption((option) =>
      option
        .setName("channel")
        .setDescription("The channel to clear chat")
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true)
    )
    .addNumberOption((option) =>
      option
        .setName("amount")
        .setDescription("Amount of messages being deleted")
        .setMinValue(1)
        .setMaxValue(50)
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("Reason warranting the clear")
        .setRequired(true)
    ),

  async execute(interaction, client) {
    if (interaction.channel.isDMBased())
      return interaction.reply({
        content: "You cannot use this command in a DM Channel!",
        ephemeral: true,
      });
    const channel = interaction.options.getChannel("channel");
    const amount = interaction.options.getNumber("amount");
    const reason = interaction.options.getString("reason");
    const { member, guild } = interaction;
    const embedData = await embedSchema.findOne({ GuildID: guild.id });
    const modData = await modSchema.findOne({ GuildID: guild.id });
    if (!modData || !modData?.ChannelID || !modData?.clear?.RoleID)
      return interaction.reply({
        content:
          "Please setup the clear permissions before running this command!",
        ephemeral: true,
      });
    // Command user's role check
    if (!member.roles.cache.some((role) => role.id === modData?.unban?.RoleID))
      return interaction.reply({
        content: modData?.Message || "You cannot use this command!",
        ephemeral: true,
      });

    const embed = new EmbedBuilder();
    embed
      .setAuthor({
        name: `${client.user.tag}`,
        iconURL: `${client.user.displayAvatarURL()}`,
      })
      .setColor(embedData?.Color || "White")
      .setTitle("**__Chat Cleared__**")
      .setDescription(
        `> **__Channel:__** ${channel} (${channel.id})\n > **__Executor:__** ${member} (${member.id})\n > **__Amount:__** ${amount}\n > **__Reason:__** ${reason}`
      )
      .setThumbnail(embedData?.Thumbnail || `${client.user.displayAvatarURL()}`)
      .setFooter({
        text: `Cleared Chat`,
        iconURL: embedData?.IconURL || `${client.user.displayAvatarURL()}`,
      })
      .setTimestamp();
    if (amount >= 51)
      return interaction.reply({
        content: "You cannot delete more than 50 messages at a time!",
        ephemeral: true,
      });
    await channel.bulkDelete(amount, (filterOld = true));
    interaction.reply({
      embeds: [embed],
    });

    embed
      .setAuthor({
        name: `${client.user.tag}`,
        iconURL: `${client.user.displayAvatarURL()}`,
      })
      .setColor(embedData?.Color || "White")
      .setTitle("**__New Action Log__**")
      .setDescription(
        `> **__Channel:__** ${channel} (${channel.id})\n > **__Executor:__** ${member} (${member.id})\n **__Amount:__** ${amount}\n > **__Reason:__** ${reason}`
      )
      .setThumbnail(embedData?.Thumbnail || `${client.user.displayAvatarURL()}`)
      .setFooter({
        text: `Cleared Chat`,
        iconURL: embedData?.IconURL || `${client.user.displayAvatarURL()}`,
      })
      .setTimestamp();
    const logchannel = await guild.channels.fetch(modData?.ChannelID);
    const webhooks = await logchannel.fetchWebhooks();
    const webhook = webhooks.find((wh) => wh.name === "Action Logs");
    if (webhook) {
      await webhook.send({
        embeds: [embed],
      });
    } else {
      logchannel
        .createWebhook({
          name: "Action Logs",
          avatar: `${client.user.displayAvatarURL()}`,
          reason: "Logs",
        })
        .then((wh) => {
          wh.send({
            embeds: [embed],
          });
        });
    }
  },
};
