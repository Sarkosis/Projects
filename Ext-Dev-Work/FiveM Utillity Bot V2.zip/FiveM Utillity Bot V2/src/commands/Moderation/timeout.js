const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const modSchema = require("../../schemas/moderationSetting");
const embedSchema = require("../../schemas/embedSettings");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("mute")
    .setDescription("Timeout a member.")
    .addUserOption((option) =>
      option
        .setName("member")
        .setDescription("select a member to mute")
        .setRequired(true)
    )
    .addNumberOption((option) =>
      option
        .setName("time")
        .setDescription("The amount of minutes to timeout the member.")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("Reason warranting the mute.")
        .setRequired(true)
    ),

  async execute(interaction, client) {
    if (interaction.channel.isDMBased())
      return interaction.reply({
        content: "You cannot use this command in a DM Channel!",
        ephemeral: true,
      });
    const member = interaction.options.getMember("member");
    const reason = interaction.options.getString("reason");
    const time = interaction.options.getNumber("time");
    const guild = interaction.guild;
    const embedData = await embedSchema.findOne({ GuildID: guild.id });
    const modData = await modSchema.findOne({ GuildID: guild.id });
    if (!modData || !modData?.ChannelID || !modData?.mute?.RoleID)
      return interaction.reply({
        content:
          "Please configure the mute permissions before running this command.",
        ephemeral: true,
      });
    // Role checking
    if (
      !interaction.member.roles.cache.some(
        (role) => role.id === modData?.mute?.RoleID
      )
    )
      return interaction.reply({
        content: modData?.Message || "You cannot use this command!",
        ephemeral: true,
      });

    if (
      interaction.member.roles.highest.position < member.roles.highest.position
    )
      return interaction.reply({
        content:
          "You cannot mute this member, their role is higher than yours!",
        ephemeral: true,
      });
    const embed = new EmbedBuilder();
    embed
      .setAuthor({
        name: `${client.user.tag}`,
        iconURL: `${client.user.displayAvatarURL()}`,
      })
      .setColor(embedData?.Color || "White")
      .setTitle("**__Member Muted__**")
      .setDescription(
        `> **__Muted User:__** <@${member.id}> (${member.id})\n > **__Executor:__** ${interaction.user} (${interaction.user.id})\n > **__Time:__** ${time} Minute(s)\n > **__Reason:__** *${reason}*`
      )
      .setThumbnail(embedData?.Thumbnail || `${guild.iconURL()}`)
      .setFooter({
        text: "User Muted ",
        iconURL: embedData?.IconURL || `${client.user.displayAvatarURL()}`,
      })
      .setTimestamp();
    member.timeout(time * 60 * 1000);
    interaction.reply({
      embeds: [embed],
    });
    const channel = await guild.channels.fetch(modData?.ChannelID);
    embed
      .setAuthor({
        name: `${client.user.tag}`,
        iconURL: `${client.user.displayAvatarURL()}`,
      })
      .setColor(embedData?.Color || "White")
      .setTitle("**__New Action Log__**")
      .setDescription(
        `> **__Muted User:__** <@${member.id}> (${member.id})\n > **__Executor:__** ${interaction.user} (${interaction.user.id})\n > **__Time:__** ${time} Minute(s)\n > **__Reason:__** *${reason}*`
      )
      .setThumbnail(embedData?.Thumbnail || `${guild.iconURL()}`)
      .setFooter({
        text: "User Muted ",
        iconURL: embedData?.IconURL || `${client.user.displayAvatarURL()}`,
      })
      .setTimestamp();
    const webhooks = await channel.fetchWebhooks();
    const webhook = webhooks.find((wh) => wh.name === "Action Logs");
    if (webhook) {
      await webhook.send({
        embeds: [embed],
      });
    } else {
      channel
        .createWebhook({
          name: "Action Logs",
          avatar: `${client.user.displayAvatarURL()}`,
          reason: "Logs",
        })
        .then((wh) => {
          wh.send({
            embeds: [embed],
          });
        });
    }
  },
};
