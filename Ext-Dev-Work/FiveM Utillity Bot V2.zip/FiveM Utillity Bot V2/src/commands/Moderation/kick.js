const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require("discord.js");
const modSchema = require("../../schemas/moderationSetting");
const embedSchema = require("../../schemas/embedSettings");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("kick")
    .setDescription("Kick a member")
    .addUserOption((option) =>
      option
        .setName("member")
        .setDescription("The member being kicked")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("Reason for the kick")
        .setRequired(true)
    ),

  async execute(interaction, client) {
    if (interaction.channel.isDMBased())
      return interaction.reply({
        content: "You cannot use this command in a DM Channel!",
        ephemeral: true,
      });
    const member = interaction.options.getMember("member");
    const reason = interaction.options.getString("reason");
    const { guild } = interaction;
    const embedData = await embedSchema.findOne({ GuildID: guild.id });
    const modData = await modSchema.findOne({ GuildID: guild.id });
    if (!modData || !modData?.ChannelID || !modData?.kick?.RoleID)
      return interaction.reply({
        content: "Please setup the kick permissions before running the command",
        ephemeral: true,
      });
    // Command user's role check
    if (
      !interaction.member.roles.cache.some(
        (role) => role.id === modData?.kick?.RoleID
      )
    )
      return interaction.reply({
        content: modData?.Message || "You cannot use this command!",
        ephemeral: true,
      });
    // Bot permissions check
    if (
      !guild.members.me.permissions.has(PermissionFlagsBits.KickMembers) ||
      guild.members.me.roles.highest.position < member.roles.highest.position
    )
      return interaction.reply({
        content: "I don't have the required permissions for this.",
        ephemeral: true,
      });
    // Checking if user is trying to kick a member with a higher role
    if (
      interaction.member.roles.highest.position < member.roles.highest.position
    )
      return interaction.reply({
        content: "You cannot ban this member, their role is higher than yours!",
        ephemeral: true,
      });
    const embed = new EmbedBuilder();
    embed
      .setAuthor({
        name: `${client.user.tag}`,
        iconURL: `${client.user.displayAvatarURL()}`,
      })
      .setColor(embedData?.Color || "White")
      .setTitle("**__Kicked Member__**")
      .setDescription(
        `> **__Kicked Member:__** <@${member.id}> (${member.id})\n > **__Executor:__** ${interaction.user} (${interaction.user.id})\n > **__Reason:__** ${reason}`
      )
      .setThumbnail(embedData?.Thumbnail || `${guild.iconURL()}`)
      .setFooter({
        text: "User Kicked ",
        iconURL: embedData?.IconURL || `${client.user.displayAvatarURL()}`,
      })
      .setTimestamp();
    interaction.reply({
      embeds: [embed],
    });
    const channel = await guild.channels.fetch(modData?.ChannelID);
    embed
      .setAuthor({
        name: `${client.user.tag}`,
        iconURL: `${client.user.displayAvatarURL()}`,
      })
      .setColor(embedData?.Color || "White")
      .setTitle("**__Kicked Member__**")
      .setDescription(
        `> **__Kicked Member:__** <@${member.id}> (${member.id})\n > **__Executor:__** ${interaction.user} (${interaction.user.id})\n > **__Reason:__** ${reason}`
      )
      .setThumbnail(embedData?.Thumbnail || `${guild.iconURL()}`)
      .setFooter({
        text: "User Kicked ",
        iconURL: embedData?.IconURL || `${client.user.displayAvatarURL()}`,
      })
      .setTimestamp();
    const webhooks = await channel.fetchWebhooks();
    const webhook = webhooks.find((wh) => wh.name === "Action Logs");
    if (webhook) {
      await webhook.send({
        embeds: [embed],
      });
    } else {
      channel
        .createWebhook({
          name: "Action Logs",
          avatar: `${client.user.displayAvatarURL()}`,
          reason: "Logs",
        })
        .then((wh) => {
          wh.send({
            embeds: [embed],
          });
        });
    }
  },
};
