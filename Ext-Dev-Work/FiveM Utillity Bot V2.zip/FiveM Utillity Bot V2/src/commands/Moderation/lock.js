const {
  SlashCommandBuilder,
  ChannelType,
  EmbedBuilder,
} = require("discord.js");
const modSchema = require("../../schemas/moderationSetting");
const embedSchema = require("../../schemas/embedSettings");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("lock")
    .setDescription("Lock the current channel")
    .addChannelOption((option) =>
      option
        .setName("channel")
        .setDescription("The channel being locked")
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true)
    )
    .addNumberOption((option) =>
      option
        .setName("time")
        .setDescription("The amount of minutes the channel will be locked")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("reason")
        .setDescription("The reason for the lock")
        .setRequired(true)
    ),

  async execute(interaction, client) {
    if (interaction.channel.isDMBased())
      return interaction.reply({
        content: "You cannot use this command in a DM Channel!",
        ephemeral: true,
      });
    const channel = interaction.options.getChannel("channel");
    const time = interaction.options.getNumber("time");
    const reason = interaction.options.getString("reason");
    const { guild, member } = interaction;
    const embedData = await embedSchema.findOne({ GuildID: guild.id });
    const modData = await modSchema.findOne({ GuildID: guild.id });
    if (!modData || !modData?.ChannelID || !modData?.lock?.RoleID)
      return interaction.reply({
        content: "Please configure the lock perms before using the command.",
        ephemeral: true,
      });
    // Role permissions check
    if (!member.roles.cache.some((role) => role.id === modData?.lock?.RoleID))
      return interaction.reply({
        content: modData?.Message || "You cannot use this command!",
        ephemeral: true,
      });

    const embed = new EmbedBuilder();
    embed
      .setAuthor({
        name: `${client.user.tag}`,
        iconURL: `${client.user.displayAvatarURL()}`,
      })
      .setColor(embedData?.Color || "White")
      .setTitle("**__Channel Locked__**")
      .setDescription(
        `> **__Channel:__** ${channel} (${channel.id})\n > **__Executor:__** ${member} (${member.id})\n > **__Time:__** ${time} Minutes\n > **__Reason:__** ${reason}`
      )
      .setThumbnail(embedData?.Thumbnail || `${guild.iconURL()}`)
      .setFooter({
        text: `Channel Locked `,
        iconURL: embedData?.IconURL || `${client.user.displayAvatarURL()}`,
      })
      .setTimestamp();
    await channel.permissionOverwrites.edit(guild.roles.everyone.id, {
      SendMessages: false,
    });

    await interaction.reply({
      embeds: [embed],
    });

    setTimeout(function () {
      channel.permissionOverwrites.edit(guild.roles.everyone.id, {
        SendMessages: true,
      });
    }, time * 60000);
    embed
      .setAuthor({
        name: `${client.user.tag}`,
        iconURL: `${client.user.displayAvatarURL()}`,
      })
      .setColor(embedData?.Color || "White")
      .setTitle("**__Channel Locked__**")
      .setDescription(
        `> **__Channel:__** ${channel} (${channel.id})\n > **__Executor:__** ${member} (${member.id})\n > **__Time:__** ${time} Minutes\n > **__Reason:__** ${reason}`
      )
      .setThumbnail(embedData?.Thumbnail || `${guild.iconURL()}`)
      .setFooter({
        text: `Channel Locked `,
        iconURL: embedData?.IconURL || `${client.user.displayAvatarURL()}`,
      })
      .setTimestamp();
    const logchannel = await guild.channels.fetch(modData?.ChannelID);
    const webhooks = await logchannel.fetchWebhooks();
    const webhook = webhooks.find((wh) => wh.name === "Action Logs");
    if (webhook) {
      await webhook.send({
        embeds: [embed],
      });
    } else {
      logchannel
        .createWebhook({
          name: "Action Logs",
          avatar: `${client.user.displayAvatarURL()}`,
          reason: "Logs",
        })
        .then((wh) => {
          wh.send({
            embeds: [embed],
          });
        });
    }
  },
};
