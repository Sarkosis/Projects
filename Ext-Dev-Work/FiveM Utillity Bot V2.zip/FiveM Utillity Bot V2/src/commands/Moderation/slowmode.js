const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
} = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setName("slowmode")
    .setDescription("Toggle slowmode in a channel")
    .addSubcommand((subcommand) =>
      subcommand
        .setName("activate")
        .setDescription("Activate slowmode in a channel")
        .addChannelOption((option) =>
          option
            .setName("channel")
            .setDescription("The channel to activate slowmode in")
            .setRequired(true)
            .addChannelTypes(ChannelType.GuildText)
        )
        .addIntegerOption((option) =>
          option
            .setName("time")
            .setDescription("The time to activate slowmode in")
            .setRequired(true)
        )
        .addNumberOption((option) =>
          option
            .setName("timeout")
            .setDescription(
              "Amount of time for slowmode to be reset (miniutes)"
            )
            .setRequired(false)
        )
    )
    .addSubcommand((subcommand) =>
      subcommand
        .setName("deactivate")
        .setDescription("deactivate slowmode in a channel")
        .addChannelOption((option) =>
          option
            .setName("channel")
            .setDescription("The channel to activate slowmode in")
            .setRequired(true)
            .addChannelTypes(ChannelType.GuildText)
        )
    ),

  async execute(interaction, client) {
    if (interaction.channel.isDMBased())
      return interaction.reply({
        content: "You cannot use this command in a DM Channel!",
        ephemeral: true,
      });
    const { guild, options } = interaction;
    const sub = options.getSubcommand();
    const channel = options.getChannel("channel");
    const time = options.getInteger("time");
    const timeout = options.getNumber("timeout");

    switch (sub) {
      case "activate":
        {
          channel.setRateLimitPerUser(time);
          await interaction.reply({
            content: `Slowmode has been activated in ${channel} with a limit of ${time} seconds per message!`,
          });
          if (timeout) {
            setTimeout(() => {
              channel.setRateLimitPerUser(0);
              return channel.send({
                content: `Slowmode has been deactivated in ${channel}!`,
              });
            }, timeout * 10000);
          }
        }
        break;
      case "deactivate":
        {
          channel.setRateLimitPerUser(0);
          return interaction.reply({
            content: `Slowmode has been deactivated in ${channel}!`,
          });
        }
        break;
      default: {
        return interaction.reply({
          content: "Invalid subcommand",
          ephemeral: true,
        });
      }
    }
  },
};
