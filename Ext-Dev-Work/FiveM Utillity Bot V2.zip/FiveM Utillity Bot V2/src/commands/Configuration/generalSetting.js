const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const embedSchema = require("../../schemas/embedSettings");
const moderationSetting = require("../../schemas/moderationSetting");
const fiveMSchema = require("../../schemas/fivemSettings");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("general_settings")
    .setDescription("Configure the General settings")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sub) =>
      sub
        .setName("embed_settings")
        .setDescription("Configure the embed settings for this guild")
        .addStringOption((option) =>
          option
            .setName("color")
            .setDescription("The embed color for this guild")
            .setChoices(
              { name: "Aqua", value: "Aqua" },
              { name: "Blue", value: "Blue" },
              { name: "Blurple", value: "Blurple" },
              { name: "DarkAqua", value: "DarkAqua" },
              { name: "DarkBlue", value: "DarkBlue" },
              { name: "DarkGold", value: "DarkGold" },
              { name: "DarkGreen", value: "DarkGreen" },
              { name: "DarkGrey", value: "DarkGrey" },
              { name: "DarkNavy", value: "DarkNavy" },
              { name: "DarkOrange", value: "DarkOrange" },
              { name: "DarkPurple", value: "DarkPurple" },
              { name: "DarkRed", value: "DarkRed" },
              { name: "DarkVividPink", value: "DarkVividPink" },
              { name: "DarkerGrey", value: "DarkerGrey" },
              { name: "Gold", value: "Gold" },
              { name: "Green", value: "Green" },
              { name: "Grey", value: "Grey" },
              { name: "Greyple", value: "Greyple" },
              { name: "LightGrey", value: "lightGrey" },
              { name: "Navy", value: "Navy" },
              { name: "Orange", value: "Orange" },
              { name: "Purple", value: "Purple" },
              { name: "Red", value: "Red" },
              { name: "White", value: "White" },
              { name: "Yellow", value: "Yellow" }
            )
            .setRequired(true)
        )
        .addStringOption((option) =>
          option
            .setName("footer")
            .setDescription("The embed footer for this guild")
            .setRequired(true)
        )
        .addStringOption((option) =>
          option
            .setName("icon")
            .setDescription(
              "A valid Image URL for the icon of the embeds of this guild"
            )
            .setRequired(true)
        )
        .addStringOption((option) =>
          option
            .setName("thumbnail")
            .setDescription(
              "A valid Image URL for the embed thumbails of this guild"
            )
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("no_perms")
        .setDescription("Configure the no-permissions message for this guild.")
        .addStringOption((option) =>
          option
            .setName("message")
            .setDescription("The no-permissions message")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("server_info")
        .setDescription("Configure the FiveM Server info for this guild")
        .addUserOption((option) =>
          option
            .setName("owner")
            .setDescription("The FiveM server owner")
            .setRequired(true)
        )
        .addStringOption((option) =>
          option
            .setName("serverip")
            .setDescription("The FiveM server IP Address")
            .setRequired(true)
        )
        .addStringOption((option) =>
          option
            .setName("servername")
            .setDescription("The FiveM server name")
            .setRequired(true)
        )
        .addStringOption((option) =>
          option
            .setName("server-connecturl")
            .setDescription("The FiveM server connect URL")
            .setRequired(true)
        )
        .addNumberOption((option) =>
          option
            .setName("server-capacity")
            .setDescription("The FiveM server capacity")
            .setRequired(true)
        )
        .addStringOption((option) =>
          option
            .setName("server-site")
            .setDescription("The FiveM server site")
            .setRequired(true)
        )
        .addStringOption((option) =>
          option
            .setName("store")
            .setDescription("The FiveM server store")
            .setRequired(false)
        )
    ),

  async execute(interaction, client) {
    if (interaction.channel.isDMBased())
      return interaction.reply({
        content: "This command cannot be ran in Direct Messages!",
        ephemeral: true,
      });
    const sub = interaction.options.getSubcommand();
    switch (sub) {
      case "embed_settings": {
        const embedColor = interaction.options.getString("color");
        const embedFooter = interaction.options.getString("footer");
        const embedIconURL = interaction.options.getString("icon");
        const embedThumbnail = interaction.options.getString("thumbnail");
        await embedSchema.findOneAndUpdate(
          { GuildID: interaction.guild.id },
          {
            Color: embedColor,
            Footer: embedFooter,
            IconURL: embedIconURL,
            Thumbnail: embedThumbnail,
          },
          { new: true, upsert: true }
        );
        return interaction.reply({
          content: `> \`Embed Color:\` **${embedColor}**\n> \`Embed Footer:\` **${embedFooter}**\n> \`Embed Icon:\` **${embedIconURL}**\n> \`Embed Thumbnail:\` **${embedThumbnail}**`,
          ephemeral: true,
        });
      }
      case "no_perms": {
        const message = interaction.options.getString("no_perms");
        await moderationSetting.findOne(
          { GuildID: interaction.guild.id },
          { Message: message },
          { new: true, upsert: true }
        );
        return interaction.reply({
          content: `> \`No Permissions Message:\` **${message}**`,
          ephemeral: true,
        });
      }
      case "server_info": {
        const owner = interaction.options.getMember("owner");
        const serverIP = interaction.options.getString("serverip");
        const serverName = interaction.options.getString("servername");
        const serverURL = interaction.options.getString("server-connecturl");
        const serverCap = interaction.options.getNumber("server-capacity");
        const serverSite = interaction.options.getString("server-site");
        const serverStore =
          interaction.options.getString("store") || "No current store";
        await fiveMSchema.findOneAndUpdate(
          { GuildID: interaction.guild.id },
          {
            OwnerID: owner.id,
            OwnerName: owner.user.username,
            ServerIP: serverIP,
            ServerName: serverName,
            ServerConnectURL: serverURL,
            ServerCap: serverCap,
            ServerSite: serverSite,
            Store: serverStore,
          },
          { new: true, upsert: true }
        );
        return interaction.reply({
          content: `> \`Server Owner:\` ${owner}\n> \`Server IP:\` ${serverIP}\n> \`Server Name:\` ${serverName}\n> \`Server Connection URL:\` ${serverURL}\n> \`Server Capacity:\` ${serverCap}\n> \`Server Site:\` ${serverSite}\n> \`Server Store:\` ${serverStore}\n`,
          ephemeral: true,
        });
      }
      default:
        break;
    }
  },
};
