const {
  SlashCommandBuilder,
  PermissionFlagsBits,
} = require("discord.js");
const modSchema = require("../../schemas/moderationSetting");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("moderation_settings")
    .setDescription("Configure this guild's moderation settings")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sub) =>
      sub
        .setName("ban_perms")
        .setDescription("Configure this guild's ban permissions")
        .addRoleOption((option) =>
          option
            .setName("role")
            .setDescription("The role with ban permissions")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("unban_perms")
        .setDescription("Configure this guild's unban permissions")
        .addRoleOption((option) =>
          option
            .setName("role")
            .setDescription("The role with unban permissions")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("kick_perms")
        .setDescription("Configure this guild's kick permissions")
        .addRoleOption((option) =>
          option
            .setName("role")
            .setDescription("The role with kick permissions")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("clear_perms")
        .setDescription("Configure this guild's clear permissions")
        .addRoleOption((option) =>
          option
            .setName("role")
            .setDescription("The role with clear permissions")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("lock_perms")
        .setDescription("Configure this guild's lock permissions")
        .addRoleOption((option) =>
          option
            .setName("role")
            .setDescription("The role with lock permissions")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("slowmode_perms")
        .setDescription("Configure this guild's slowmode permissions")
        .addRoleOption((option) =>
          option
            .setName("role")
            .setDescription("The role with slowmode permissions")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("mute_perms")
        .setDescription("Configure this guild's mute permissions")
        .addRoleOption((option) =>
          option
            .setName("role")
            .setDescription("The role with mute permissions")
            .setRequired(true)
        )
    ),

  async execute(interaction, client) {
    if (interaction.channel.isDMBased())
      return interaction.reply({
        content: "This command cannot be ran in Direct Messages!",
        ephemeral: true,
      });
    const role = interaction.options.getRole("role");
    const sub = interaction.options.getSubcommand();
    switch (sub) {
      case "ban_perms": {
        await modSchema.findOneAndUpdate(
          { GuildID: interaction.guild.id },
          { ban: { RoleID: role.id } },
          { new: true, upsert: true }
        );
        return interaction.reply({
          content: `> \`Ban Role:\` **${role}**`,
          ephemeral: true,
        });
      }
      case "unban_perms": {
        await modSchema.findOneAndUpdate(
          { GuildID: interaction.guild.id },
          { unban: { RoleID: role.id } },
          { new: true, upsert: true }
        );
        return interaction.reply({
          content: `> \`Unban Role:\` **${role}**`,
          ephemeral: true,
        });
      }
      case "kick_perms": {
        await modSchema.findOneAndUpdate(
          { GuildID: interaction.guild.id },
          { kick: { RoleID: role.id } },
          { new: true, upsert: true }
        );
        return interaction.reply({
          content: `> \`Kick Role:\` **${role}**`,
          ephemeral: true,
        });
      }
      case "clear_perms": {
        await modSchema.findOneAndUpdate(
          { GuildID: interaction.guild.id },
          { clear: { RoleID: role.id } },
          { new: true, upsert: true }
        );
        return interaction.reply({
          content: `> \`Clear Role:\` **${role}**`,
          ephemeral: true,
        });
      }
      case "lock_perms": {
        await modSchema.findOneAndUpdate(
          { GuildID: interaction.guild.id },
          { lock: { RoleID: role.id } },
          { new: true, upsert: true }
        );
        return interaction.reply({
          content: `> \`Lock Role:\` **${role}**`,
          ephemeral: true,
        });
      }
      case "slowmode_perms": {
        await modSchema.findOneAndUpdate(
          { GuildID: interaction.guild.id },
          { slowmode: { RoleID: role.id } },
          { new: true, upsert: true }
        );
        return interaction.reply({
          content: `> \`Slowmode Role:\` **${role}**`,
          ephemeral: true,
        });
      }
      case "mute_perms": {
        await modSchema.findOneAndUpdate(
          { GuildID: interaction.guild.id },
          { mute: { RoleID: role.id } },
          { new: true, upsert: true }
        );
        return interaction.reply({
          content: `> \`Mute Role:\` **${role}**`,
          ephemeral: true,
        });
      }

      default:
        break;
    }
  },
};
