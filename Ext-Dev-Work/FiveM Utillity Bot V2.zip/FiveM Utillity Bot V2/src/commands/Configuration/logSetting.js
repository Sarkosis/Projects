const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
} = require("discord.js");
const modSchema = require("../../schemas/moderationSetting");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("log_settings")
    .setDescription("Configure this guild's logging settings")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sub) =>
      sub
        .setName("mod_logs")
        .setDescription("Configure this guild's moderation log settings")
        .addChannelOption((option) =>
          option
            .setName("channel")
            .setDescription("The log channel")
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true)
        )
    ),

  async execute(interaction, client) {
    if (interaction.channel.isDMBased())
      return interaction.reply({
        content: "This command cannot be ran in Direct Messages!",
        ephemeral: true,
      });
    const sub = interaction.options.getSubcommand();
    switch (sub) {
      case "mod_logs": {
        const channel = interaction.options.getChannel("channel");
        await modSchema.findOneAndUpdate(
          { GuildID: interaction.guild.id },
          { ChannelID: channel.id },
          { new: true, upsert: true }
        );
        return interaction.reply({
          content: `\`Moderation Logs:\` **${channel}**`,
          ephemeral: true,
        });
      }

      default:
        break;
    }
  },
};
