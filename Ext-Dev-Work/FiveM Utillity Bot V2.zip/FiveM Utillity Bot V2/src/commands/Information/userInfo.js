const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const embedSchema = require("../../schemas/embedSettings");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("user-info")
    .setDescription("Your Information")
    .addUserOption((option) =>
      option
        .setName("member")
        .setDescription("The member wwho information you want to view")
        .setRequired(true)
    ),

  async execute(interaction, client) {
    if (interaction.channel.isDMBased())
      return interaction.reply({
        content: "You cannot use commands in a DM Channel!",
        ephemeral: true,
      });
    const member = interaction.options.getMember("member");
    const { guild } = interaction;
    const embed = new EmbedBuilder();
    const data = await embedSchema.findOne({ GuildID: guild.id });
    embed
      .setAuthor({
        name: `${member.user.tag}`,
        iconURL: `${member.user.displayAvatarURL()}`,
      })
      .setColor(data?.Color || "White")
      .setTitle(`Member Information`)
      .setFields(
        {
          name: `**__Name__**`,
          value: `
              > **Username:** *${member.user.username}*
              > **User Tag:** *${member.user.tag}*
              > **Nickname:** *${member.nickname || "No Nickname"}*`,
          inline: true,
        },
        {
          name: `**__User ID__**`,
          value: ` > *${member.id}*`,
          inline: false,
        },
        {
          name: `**__Role Count__**`,
          value: ` > *${member.roles.cache.size}*`,
          inline: false,
        },
        {
          name: `**__Account Creation Date__**`,
          value: ` > *<t:${parseInt(member.user.createdTimestamp / 1000)}:R>*`,
          inline: false,
        },
        {
          name: "**__Server Join Date__**",
          value: `> *<t:${parseInt(member.joinedTimestamp / 1000)}:R>*`,
          inline: false,
        },
        {
          name: "**__Highest Role__**",
          value: ` > *${member.roles.highest}*`,
          inline: false,
        },
        {
          name: "**__Presence__**",
          value: `
              > **Activities:** *${member.presence.activities}*
              > **Status:** *${member.presence.status}*`,
          inline: false,
        },
        {
          name: "**__Display Color__**",
          value: `
              > **Color:** *${member.displayColor}*
              > **Hex:** *${member.displayHexColor}*`,
          inline: false,
        }
      )
      .setFooter({
        text: data?.Footer || `${guild.name}`,
        iconURL: data?.IconURL || `${client.user.displayAvatarURL()}`,
      })
      .setTimestamp(Date.now())
      .setThumbnail(data?.Color || `${client.user.displayAvatarURL()}`);

    return interaction.reply({
      embeds: [embed],
    });
  },
};
