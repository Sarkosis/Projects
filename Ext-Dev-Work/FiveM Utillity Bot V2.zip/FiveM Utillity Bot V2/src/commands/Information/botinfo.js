const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const embedSchema = require("../../schemas/embedSettings");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("botinfo")
    .setDescription("Find info about the bot"),

  async execute(interaction, client) {
    if (interaction.channel.isDMBased())
      return interaction.reply({
        content: "You cannot use commands in a DM Channel!",
        ephemeral: true,
      });
    const { guild } = interaction;
    const embed = new EmbedBuilder();
    const data = await embedSchema.findOne({ GuildID: guild.id });
    embed
      .setAuthor({
        name: `${client.user.tag}`,
        iconURL: `${client.user.displayAvatarURL()}`,
      })
      .setColor(data?.Color || "White")
      .setTitle("**__Bot Information__**")
      .setFields(
        {
          name: "**__Name__**",
          value: `> **Name:** ${client.user.username}\n> **Discriminator:** #${client.user.discriminator}\n`,
          inline: false,
        },
        {
          name: "**__Description__**",
          value: `> **Description:** ${
            client.application.description || "No description."
          }\n> **Created:** <t:${parseInt(
            client.application.createdTimestamp / 1000
          )}:R>\n> **Is Public:** ${
            client.application.botPublic || "Unknown"
          }\n> **Tags:** ${client.application.tags || "No tags"}`,
          inline: false,
        },
        {
          name: "**__Extra__**",
          value: `> **In ${client.guilds.cache.size} Guild(s)**\n> **Watching ${client.channels.cache.size} Channels**\n> **Using ${client.emojis.cache.size} Custom Emojis**`,
          inline: false,
        }
      )
      .setThumbnail(data?.Thumbnail || `${client.user.displayAvatarURL()}`)
      .setFooter({
        text: data?.Footer || `${guild.name}`,
        iconURL: data?.IconURL || `${client.user.displayAvatarURL()}`,
      })
      .setTimestamp();
    return interaction.reply({
      embeds: [embed],
    });
  },
};
