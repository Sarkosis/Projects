const {
  SlashCommandBuilder,
  EmbedBuilder,
  ChannelType,
} = require("discord.js");
const embedSchema = require("../../schemas/embedSettings");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("server-info")
    .setDescription("Display Information about the server."),

  async execute(interaction, client) {
    if (interaction.channel.isDMBased())
      return interaction.reply({
        content: "You cannot use commands in a DM Channel!",
        ephemeral: true,
      });
    const { guild } = interaction;
    const { name, ownerId, description } = guild;
    const embed = new EmbedBuilder();
    const data = await embedSchema.findOne({ GuildID: guild.id });
    embed
      .setAuthor({
        name: `${interaction.user.tag}`,
        iconURL: `${interaction.user.displayAvatarURL()}`,
      })
      .setColor(data?.Color || "White")
      .setTitle("**Server Information**")
      .setFields(
        {
          name: "**General**",
          value: `
              > *Name:* ${name}
              > *Created:* <t:${parseInt(guild.createdTimestamp / 1000)}:R>
              > *Owner:* <@${ownerId}>
              > *Description:* ${description || "*No Server Description*"}`,
        },
        {
          name: "**Users**",
          value: `
            > *Members:* ${guild.members.cache.filter((m) => !m.user.bot).size}
            > *Bots:* ${guild.members.cache.filter((m) => m.user.bot).size}
            > *Total: ${guild.memberCount} *`,
        },
        {
          name: "**Channels**",
          value: `
              > *Text:* ${
                guild.channels.cache.filter(
                  (c) => c.type === ChannelType.GuildText
                ).size
              }
              > *Voice:* ${
                guild.channels.cache.filter(
                  (c) => c.type === ChannelType.GuildVoice
                ).size
              }
              > *Forum:* ${
                guild.channels.cache.filter(
                  (c) => c.type === ChannelType.GuildForum
                ).size
              }
              > *Thread:* ${
                guild.channels.cache.filter(
                  (c) =>
                    c.type === ChannelType.PublicThread &&
                    ChannelType.PrivateThread
                ).size
              }
              > *Categories:* ${
                guild.channels.cache.filter(
                  (c) => c.type === ChannelType.GuildCategory
                ).size
              }
              > *Stages:* ${
                guild.channels.cache.filter(
                  (c) => c.type === ChannelType.GuildStageVoice
                ).size
              }
              > *Announcement:* ${
                guild.channels.cache.filter(
                  (c) => c.type === ChannelType.GuildAnnouncement
                ).size
              }
              > *Total:* ${guild.channels.cache.size}`,
        },
        {
          name: "**Emojis and Stickers**",
          value: `
              > *Animated:* ${guild.emojis.cache.filter((e) => e.animated).size}
              > *Static:* ${guild.emojis.cache.filter((e) => !e.animated).size}
              > *Animated:* ${guild.stickers.cache.size}
              > *Total:* ${
                guild.stickers.cache.size + guild.emojis.cache.size
              }`,
        },
        {
          name: "**Nitro Statistics**",
          value: `
              > *Tier:* ${guild.premiumTier}
              > *Boosts:* ${guild.premiumSubscriptionCount}
              > *Boosters:* ${
                guild.members.cache.filter((m) => m.premiumSince).size
              }
              > *Booster Role:* ${
                guild.roles.premiumSubscriberRole || "*No Booster Role Set*"
              }`,
        },
        {
          name: "**Roles**",
          value: `
              > *Total:* ${guild.roles.cache.size}`,
        }
      )
      .setFooter({
        text: data?.Footer || `${guild.name}`,
        iconURL: data?.IconURL || `${client.user.displayAvatarURL()}`,
      })
      .setThumbnail(data?.Thumbnail || `${client.user.displayAvatarURL()}`)
      .setTimestamp();

    return interaction.reply({
      embeds: [embed],
    });
  },
};
