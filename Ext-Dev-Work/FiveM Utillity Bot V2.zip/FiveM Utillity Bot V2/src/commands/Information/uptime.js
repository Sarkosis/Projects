const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("uptime")
    .setDescription("Return My uptime"),
  async execute(interaction, client) {
    const days = Math.floor(client.uptime / 86400000);
    const hours = Math.floor(client.uptime / 3600000) % 24;
    const minutes = Math.floor(client.uptime / 60000) % 60;
    const seconds = Math.floor(client.uptime / 1000) % 60;
    await interaction.reply({
      content: `**__I have been online for ${days} days, ${hours} hours, ${minutes} minutes, and ${seconds} seconds.__**`,
      ephemeral: true,
    });
  },
};
