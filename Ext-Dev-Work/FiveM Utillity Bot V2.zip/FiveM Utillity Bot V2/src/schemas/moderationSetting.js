const { Schema, model } = require("mongoose");

let modSchema = new Schema({
  GuildID: String,
  ban: {
    RoleID: String,
  },
  unban: {
    RoleID: String,
  },
  kick: {
    RoleID: String,
  },
  mute: {
    RoleID: String,
  },
  lock: {
    RoleID: String,
  },
  clear: {
    RoleID: String,
  },
  slowmode: {
    RoleID: String,
  },
  ChannelID: String,
  Message: String,
});

module.exports = model("moderationsettings", modSchema);
