const { Schema, model } = require("mongoose");

let embedSchema = new Schema({
  GuildID: String,
  Color: String,
  Footer: String,
  IconURL: String,
  Thumbnail: String,
});

module.exports = model("embedsettings", embedSchema)