const { Schema, model } = require("mongoose");

let fivemSchema = new Schema({
  GuildID: String,
  OwnerID: String,
  OwnerName: String,
  ServerIP: String,
  ServerName: String,
  ServerConnectURL: String,
  ServerCap: Number,
  ServerSite: String,
  Store: {
    type: String,
    default: "No Store",
  },
});

module.exports = model("fivemdata", fivemSchema);
