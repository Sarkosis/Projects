const { ActivityType } = require("discord.js");
module.exports = {
  name: "ready",
  once: true,
  async execute(client) {
    client.user.setPresence({
      activities: [
        {
          name: `${client.users.cache.size} users in ${client.guilds.cache.size} guild(s)`,
          type: ActivityType.Watching,
        },
      ],
    });
    client.user.setStatus("dnd");
    console.log(`${client.user.tag} is online.`);
  },
};
