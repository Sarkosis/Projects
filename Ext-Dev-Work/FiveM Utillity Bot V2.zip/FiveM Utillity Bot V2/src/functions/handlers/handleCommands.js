const { REST } = require("@discordjs/rest");
const chalk = require("chalk");
const { Routes } = require("discord-api-types/v9");
const fs = require("fs");
const { bot } = require("../../../Settings/config");
module.exports = (client) => {
  client.handleCommands = async () => {
    const commandFolders = fs.readdirSync("./src/commands");
    for (const folder of commandFolders) {
      const commandFiles = fs
        .readdirSync(`./src/commands/${folder}`)
        .filter((file) => file.endsWith(".js"));

      const { commands, commandArray } = client;
      for (const file of commandFiles) {
        const command = require(`../../commands/${folder}/${file}`);
        commands.set(command.data.name, command);
        commandArray.push(command.data.toJSON());
      }
    }
    const rest = new REST({ version: "9" }).setToken(bot.token);
    try {
      console.log(
        chalk.yellow(
          `[INFO]: Started Refreshing ${client.commands.size} (/) commands.`
        )
      );

      await rest.put(Routes.applicationCommands(bot.clientID), {
        body: client.commandArray,
      });
      console.log(
        chalk.blue(
          `[INFO]: Finished Reloaing ${client.commands.size} (/) commands.`
        )
      );
    } catch (error) {
      console.error(error);
    }
  };
};
