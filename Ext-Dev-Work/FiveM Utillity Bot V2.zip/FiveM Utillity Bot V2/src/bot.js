const { connect } = require("mongoose");
const {
  Client,
  Collection,
  GatewayIntentBits,
  Partials,
} = require("discord.js");
const fs = require("fs");
const { bot } = require("../Settings/config");
const figlet = require("figlet");
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildPresences,
  ],
  partials: [Partials.GuildMember, Partials.Message, Partials.Channel],
});

client.commands = new Collection();
client.commandArray = [];

const functionFolders = fs.readdirSync(`./src/functions`);
for (const folder of functionFolders) {
  const functionsFiles = fs
    .readdirSync(`./src/functions/${folder}`)
    .filter((file) => file.endsWith(".js"));
  for (const file of functionsFiles)
    require(`./functions/${folder}/${file}`)(client);
}
client.setMaxListeners(0);
client.handleEvents(client);
client.handleCommands();
client.login(bot.token);
(async () => {
  await connect(bot.dbtoken, {
    useNewURLParser: true,
    useUnifiedTopology: true,
  }).catch(console.error);
})();
figlet("Fivem Utility Bot V2", function (err, data) {
  if (err) throw err;
  console.log(data);
});
