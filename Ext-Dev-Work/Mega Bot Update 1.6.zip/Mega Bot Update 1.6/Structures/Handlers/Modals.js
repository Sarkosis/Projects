const { Events } = require("../Validations/EventNames");

/**
 * @param {Client} client
 */
module.exports = async (client, PG, Ascii) => {
	const Table = new Ascii("Modals Loaded");

	(await PG(`${process.cwd()}/Events/Modals/*/*.js`)).map(async (file) => {
		const modal = require(file);

		if (!Events.includes(modal.name) || !modal.name) {
			await Table.addRow(
				`${modal.name || "MISSING"}`,
				`⛔ Loggers Event name is either invalid or missing: ${modal.path}`
			);
			return;
		}

		if (modal.once) {
			client.once(modal.name, (...args) => modal.execute(...args, client));
		} else {
			client.on(modal.name, (...args) => modal.execute(...args, client));
		}

		await Table.addRow(modal.description, "🟢 LOADED");
	});

	console.log(Table.toString());
};
