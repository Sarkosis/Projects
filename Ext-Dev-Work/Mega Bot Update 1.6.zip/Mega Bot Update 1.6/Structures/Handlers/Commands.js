﻿const { Perms } = require("../Validations/Permissions");
const { Client } = require("discord.js");
const GuildID = require('../config.json').GuildID

/**
 * @param {Client} client
 */
module.exports = async (client, PG, Ascii) => {
  const Table = new Ascii("Command Loaded");

  CommandsArray = [];

  (await PG(`${process.cwd()}/Commands/*/*.js`)).map(async (file) => {
    const command = require(file);

    if (!command.name)
      return Table.addRow(
        file.split("/")[7],
        "⛔ FAILED",
        "Missing a name Bud!"
      );

    if (!command.context && !command.description)
      return Table.addRow(
        command.name,
        "⛔ FAILED",
        "Missing a description Bud!"
      );

    if (command.permission) {
      if (Perms.includes(command.permission)) command.defaultPermission = false;
      else
        return Table.addRow(
          command.name,
          "⛔ FAILED",
          "Permission is invalid Bud!"
        );
    }

    client.commands.set(command.name, command);
    CommandsArray.push(command);

    await Table.addRow(command.name, "✔ READY!");
  });

  console.log(Table.toString());

  // Permissions Check //

  client.on("ready", async () => {
    const mainGuild = await client.guilds.cache.get(GuildID);
    mainGuild.commands.set(CommandsArray);
  });
};