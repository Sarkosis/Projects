const { Client, Collection } = require("discord.js");
const client = new Client({intents: 32767});
const { Token } = require("./config.json");
const { promisify } = require('util');
const { glob } = require('glob');
const PG = promisify(glob);
const Ascii = require("ascii-table");
const { DisTube } = require("distube");
const { SpotifyPlugin } = require("@distube/spotify");
const { YtDlpPlugin } = require("@distube/yt-dlp");
const discordModals = require('discord-modals')
discordModals(client);

client.commands = new Collection();


client.distube = new DisTube(client, {
    emitNewSongOnly: true,
    leaveOnFinish: true,
    emitAddSongWhenCreatingQueue: false,
    plugins: [new SpotifyPlugin(), new YtDlpPlugin()]
  })
  module.exports = client;
require("../Systems/GiveawaySys")(client);
client.filters = new Collection();
client.filtersLog = new Collection();
client.voiceGenerator = new Collection();



["Events", "Commands", "Modals"].forEach(handler => {
    require(`./Handlers/${handler}`)(client, PG, Ascii)
})
client.login(Token)