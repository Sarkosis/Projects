const { model, Schema } = require("mongoose");

module.exports = model("modlog", new Schema({
    GuildID: String,
    ChannelID: String,
    })
);