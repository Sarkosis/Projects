const { CommandInteraction, MessageEmbed, Client } = require("discord.js");

module.exports = {
    name: "dm",
    description: "Dm a user as the bot",
    permission: "ADMINISTRATOR",
    options: [
        {
           name: "user",
           description: "Who do you want to dm?",
           type: "USER",
           required: true
        },
        {
            name: "content",
            description: "What do you want to dm the user?",
            type: "STRING",
            required: true
        }
    ],
    /**
     * 
     * @param {CommandInteraction} interaction 
     * @param {Client} client 
     */
    async execute(interaction, client) {
    const { options, guild } = interaction;

    const Target = options.getMember("user");
    const Content = options.getString("content");


    const embed = new MessageEmbed()
    .setAuthor(`Message from ${interaction.user.tag}`, interaction.user.avatarURL({dynamic: true}))
    .setThumbnail(client.user.avatarURL({dynamic: true}))
    .setDescription(`${Content}`)
    .setTimestamp()
    .setFooter(interaction.guild.name, interaction.guild.iconURL({dynamic: true}));

    Target.send({embeds: [embed]});
    interaction.reply({content: `Your message has been sent to ${Target}!`, ephemeral: true});

    }

}