const { CommandInteraction, MessageEmbed, Client } = require("discord.js");
const config = require("../../Structures/config.json");
const UnverifyRoleID = require(`../../Structures/config.json`).UnverifyRoleID;
module.exports = { 
    name: "verify",
    description: "Get verified",

    /**
     * 
     * @param {CommandInteraction} interaction 
     * @param {Client} client 
     */
    async execute(interaction, client) {
        if (interaction.member.roles.cache.has(`${config.VerifyRoleID}`)) {
            return interaction.reply({content: "You are already verified!", ephemeral: true})
        } else {
            const embed = new MessageEmbed()
            .setThumbnail(client.user.displayAvatarURL({dynamic: true}))
            .setFooter(interaction.guild.name + ' @2022', interaction.guild.iconURL({dynamic: true}))
            .setDescription(`**Congrats**!\n> You have become verified! You can now see other channels!`);
            interaction.member.roles.add(`${config.VerifyRoleID}`);
            interaction.member.roles.remove(UnverifyRoleID);
            
            return interaction.reply({embeds: [embed], ephemeral: true});
        }
    }
}