const { MessageEmbed, CommandInteraction, Client } = require("discord.js");
const { Modal, TextInputComponent, showModal, ModalSubmitInteraction } = require('discord-modals')

module.exports = {
  name: "report",
  usage: "/report",
  description: "Report a user.",
  /**
   * 
   * @param {CommandInteraction} interaction
   * @param {Client} client
   */
  async execute(interaction, client) {

    const modal = new Modal()
    .setCustomId('report')
    .setTitle('Report a user.')
    .addComponents(
    new TextInputComponent()
      .setCustomId('user')
      .setLabel('User ID')
      .setStyle('SHORT')
      .setMinLength(10)
      .setMaxLength(25)
      .setPlaceholder('User ID. EX: 539975000799838249')
      .setRequired(true),
    new TextInputComponent()
      .setCustomId('reason')
      .setLabel('What is the reason for the report?')
      .setStyle('SHORT')
      .setMinLength(3)
      .setMaxLength(50)
      .setPlaceholder('What is the reason for the report?')
      .setRequired(true),
    );
    
    showModal(modal, {
      client: client,
      interaction: interaction
    })
  }
}