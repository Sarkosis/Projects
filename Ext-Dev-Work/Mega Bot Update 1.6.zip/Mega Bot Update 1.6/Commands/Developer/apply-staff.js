const { MessageEmbed, CommandInteraction, Client } = require("discord.js");
const { Modal, TextInputComponent, showModal, ModalSubmitInteraction } = require('discord-modals')

module.exports = {
  name: "apply-staff",
  usage: "/apply",
  description: "Staff Application",
  /**
   * 
   * @param {CommandInteraction} interaction
   * @param {Client} client
   */
  async execute(interaction, client) {

    const modal = new Modal()
    .setCustomId('application')
    .setTitle('Staff Application')
    .addComponents(
    new TextInputComponent()
      .setCustomId('age')
      .setLabel('What is your age?')
      .setStyle('SHORT')
      .setMinLength(2)
      .setMaxLength(2)
      .setPlaceholder('Must be 13 or above')
      .setRequired(true),
    new TextInputComponent()
      .setCustomId('experience')
      .setLabel('Do you have any experience as staff?')
      .setStyle('SHORT')
      .setMinLength(2)
      .setMaxLength(4)
      .setPlaceholder('Do you have any experience as staff? yes,no,some')
      .setRequired(true),
    new TextInputComponent()
      .setCustomId('mod')
      .setLabel('Why do you want to be a staff member?')
      .setStyle('LONG')
      .setMinLength(15)
      .setMaxLength(200)
      .setPlaceholder('Answer in brief.')
      .setRequired(true),
      new TextInputComponent()
      .setCustomId('Why')
      .setLabel('Why should we choose you over others?')
      .setStyle('LONG')
      .setMinLength(15)
      .setMaxLength(200)
      .setPlaceholder('Answer in brief.')
      .setRequired(true),
    );
    
    showModal(modal, {
      client: client,
      interaction: interaction
    })
  }
}