const { CommandInteraction, MessageEmbed, Client } = require("discord.js");
const config = require("../../Structures/config.json");
module.exports = {
    name: "verifypanel",
    description: "Opens a verify Panel!",
    permission: "ADMINISTRATOR",
    options: [
        {
            name: "channel",
            description: "What is the channel that the embed should be sent to?",
            type: "CHANNEL",
            required: true
        },
        // Please go to the config and define a verified role if you haven't already! Thank you!
    ],
    /**
     * 
     * @param {CommandInteraction} interaction 
     * @param {Client} client 
     */
    async execute(interaction, client) {
        if (!config.ownerIDS.includes(interaction.member.id)) {
            return interaction.reply({content: "You do not have permissions to use this command! | Owner only!", ephemeral: true});
        } else {
            const embed = new MessageEmbed()
            .setTitle(`Verification`)
            .setThumbnail(client.user.displayAvatarURL({dynamic: true}))
            .setDescription(`Please do /verify to get verified and be able to see other channels!`)
            .setFooter(interaction.guild.name + " @2022", interaction.guild.iconURL({dynamic: true}));

            const Channel = interaction.options.getChannel("channel");
            interaction.reply({content: "Verification embed sent.", ephemeral: true})
            Channel.send({embeds: [embed]});
            console.log(`Verification embed sent.`)
        }


    }
}