const { CommandInteraction, Client, MessageEmbed } = require("discord.js");
const { ApplicationLog } = require("../../Structures/config.json");
const ApplicationacceptRole = require("../../Structures/config.json").ApplicationacceptRole;
module.exports = {
    name: "application",
    description: "Accept or deny an application!",
    permission: "ADMINISTRATOR",
    options: [
        {
            name: "user-id",
            description: "Provide the users ID",
            type: "USER",
            required: true
        },
        {
            name: "message-id",
            description: "Provide the application message ID",
            type: "STRING",
            required: true
        },
        {
            name: "options",
            description: "Pick a choice",
            type: "STRING",
            choices: [
                {
                    name: "Accept",
                    value: "accept"
                },
                {
                    name: "Deny",
                    value: "deny"
                }
            ],
        }
    ],

    /**
     * 
     * @param {CommandInteraction} interaction 
     * @param {Client} client 
     */
    async execute(interaction, client) {
        const Options = interaction.options.getString("options");
        const user = interaction.options.getMember("user-id");
        const msg = interaction.options.getString("message-id");
	const channel = client.channels.cache.get(`${ApplicationLog}`);
        const embed = new MessageEmbed()
        .setTitle(`Application response`);
        switch(Options) {
            case "accept" : {
                embed.setDescription(`Hey! Congrats on passing your **Staff Application**!
                Please head to the server and create a ticket to get your interview done!
                `);
                try {
                user.send({embeds: [embed]});
                } catch(err) {
                    console.log(`The user isnt able to be messaged!`);
                }
                interaction.reply({content: "Response sent!", ephemeral: true});
               	channel.send({ content: `${user}\'s staff application has been accepted by: ${interaction.user}` });
		user.roles.add(ApplicationacceptRole);
                
            }
            break;
            case "deny" : {
                embed.setDescription(`Hey! Sorry on failing your **Staff Application**.
                After 24 hours you may re apply! Any questions please head to the Support Channel and create a ticket!

                Sincerely - Staff Team!
                `);
                user.send({embeds: [embed]});
                interaction.reply({content: "Response sent!"});
		channel.send({ content: `${user}\'s staff application has been denied by: ${interaction.user}` });
            }   
    }
}
}