const { CommandInteraction, MessageEmbed, Client } = require("discord.js");

module.exports = {
    name: "serverinfo",
    description: "Displays the server's info!",
    /**
     * 
     * @param {CommandInteraction} interaction 
     * @param {Client} client 
     */
    execute(interaction, client) {
        const { guild } = interaction;

        const { createdTimestamp, ownerId, description, members, memberCount, channels } = guild;


        const embed = new MessageEmbed()
        .setColor("AQUA")
        .setAuthor(guild.name, guild.iconURL({dynamic: true}))
        .setThumbnail(guild.iconURL({dynamic: true}))
        .setFields(
            {
                name: "GENERAL",
                value: 
                `
                Name: ${guild.name}
                Created: <t:${parseInt(createdTimestamp / 1000)}:R>
                Owner: <@${ownerId}>
                Description: ${description}


                `
            },
            {
                name: `👥 | Users`,
                value: 
                `
                - Members: ${members.cache.filter((m) => !m.user.bot).size}
                - Bots: ${members.cache.filter((m) => m.user.bot).size}

                - Total: ${memberCount}
                `
            },
            {
                name: "📄 | Channels",
                value: 
                `
                - Text: ${channels.cache.filter((c) => c.type === "GUILD_TEXT").size}
                - Voice: ${channels.cache.filter((c) => c.type === "GUILD_VOICE").size}
                - Threads: ${channels.cache.filter((c) => c.type === "GUILD_NEWS_THREAD" && "GUILD_PRIVATE_THREAD" && "GUILD_PUBLIC_THREAD").size}
                - Categories: ${channels.cache.filter((c) => c.type === "GUILD_CATEGORY").size}
                - Stages: ${channels.cache.filter((c) => c.type === "GUILD_STAGE_VOICE").size}
                - News: ${channels.cache.filter((c) => c.type === "GUILD_NEWS").size}

                - Total: ${channels.cache.size}


                `
            }
        )
        interaction.reply({embeds: [embed]})
    }
}