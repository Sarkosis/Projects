const { CommandInteraction } = require("discord.js");

module.exports = {
  name: "credit",
  description: "View the credits for this bot!",
  /**
   * 
   * @param {CommandInteraction} interaction 
   */
  execute(interaction) {
    interaction.reply({content: "**Creators:**\n[@Mr B](https://www.thedevszone.com/) Man who Wrote Bot \n[@TheDevZone](https://discord.gg/nfNb6Q84Vj) \n[@Xolify](https://xolifyzdevelopement.xyz/) who helped me when i needed it "});
  }
}