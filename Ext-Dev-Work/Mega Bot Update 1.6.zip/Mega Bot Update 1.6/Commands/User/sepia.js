const { CommandInteraction, MessageEmbed, Client, MessageAttachment } = require('discord.js');
const { Canvas } = require('canvacord');
 
module.exports = {
    name: "sepia",
    description: "idek bruh",
    options: [
        {
            name: "targetuser",
            description: "Select the member",
            type: "USER",
            required: true
        },
    ],

    /**
     * @param {CommandInteraction} interaction
     */

     async execute(interaction) {
        const { options } = interaction

         const ssuser = options.getUser("targetuser");

         const avatar = ssuser.displayAvatarURL({ format: 'png' });

         const image = await Canvas.sepia(avatar);

         const attachment = new MessageAttachment(image, "sepia.gif");

         interaction.reply({ files: [attachment]})

     },
};