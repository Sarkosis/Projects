const { MessageEmbed, CommandInteraction, MessageActionRow, MessageButton } = require("discord.js");


module.exports = {
    name: "help",
    description: "Help Menu",
    /**
     * 
     * @param {CommandInteraction} interaction 
     */
    async execute(interaction) {
        const { guild } = interaction;
        const embed = new MessageEmbed()
        .setDescription(`**Help menu**\n\nUse the buttons below to scroll through the help categorys!`)
        .setTimestamp()
        .setFooter(guild.name, guild.iconURL({dynamic: true}))
        const Buttons = new MessageActionRow();
        Buttons.addComponents(
            new MessageButton()
            .setCustomId("user-cmd")
            .setLabel("User Commands")
            .setStyle("PRIMARY")
            .setEmoji("🎎"),
            new MessageButton()
            .setCustomId("admin-cmd")
            .setLabel("Admin Commands")
            .setStyle("PRIMARY")
            .setEmoji("✈"),
            new MessageButton()
            .setCustomId("own-cmd")
            .setLabel("Owner Commands")
            .setStyle("PRIMARY")
            .setEmoji("🎫"),
        );

            interaction.reply({embeds: [embed], components: [Buttons]})
    }
}