const { Client, CommandInteraction, MessageEmbed } = require('discord.js');

module.exports = {
    name: "ping",
    description: "Try it and see!",
    /**
     * 
     * @param {CommandInteraction} interaction 
     * @param {Client} client 
     */
     async execute(interaction, client) {
        const embed = new MessageEmbed()
        .setColor('GREEN')
        .setDescription(`🏓 ${Math.round(client.ws.ping)}ms`)
        interaction.reply({embeds: [embed]})
        console.log(`ping.js | ${interaction.user.tag} used this command!`)
    }
}