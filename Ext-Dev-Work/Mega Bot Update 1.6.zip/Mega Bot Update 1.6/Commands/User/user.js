const { CommandInteraction, MessageEmbed, Client } = require("discord.js");
const moment = require("moment");

module.exports = {
    name: "user",
    description: "Get a users information or your info",
    options: [
        {
            name: "user",
            description: "Who's info do you want to get?",
            type: "USER",
            required: false

        }
    ],
    /**
     * 
     * @param {CommandInteraction} interaction 
     * @param {Client} client 
     * @param {moment} moment
     */
    async execute(interaction, client, moment) {
        const { options } = interaction;
        const Target = options.getMember("user");  
        const embed = new MessageEmbed()
        .setColor("AQUA")
        if(Target) {
            embed.setAuthor('User information of ' + Target.user.tag, Target.displayAvatarURL({dynamic: true}))
            embed.setThumbnail(Target.displayAvatarURL({dynamic: true}))
            embed.addFields(
                {
                    name: "User Name:",
                    value: `${Target.displayName}`,
                    inline: true
                },
                {
                    name: "ID:",
                    value: `${Target.id}`,
                    inline: true
                },
                {
                    name: "Bot:",
                    value: `${Target.user.bot}`,
                    inline: true
                },
                {
                    name: "Joined server:",
                    value: `<t:${parseInt(Target.joinedTimestamp / 1000)}:R>`,
                    inline: false
                },
                {
                    name: "Account Created:",
                    value: `<t:${parseInt(Target.user.createdTimestamp / 1000)}:R>`,
                    inline: false
                },
                {
                    name: "Roles:",
                    value: `${Target.roles.cache.map(r => r).join(" ").replace("@everyone", " ") || "None"} `,
                    inline: false
                },
                
            )
            .setImage(Target.displayAvatarURL({dynamic: true}));
            interaction.reply({embeds: [embed]})
        } else {
            embed.setAuthor('Your Information', interaction.user.displayAvatarURL({dynamic: true}))
            embed.setThumbnail(interaction.user.displayAvatarURL({dynamic: true}))
            embed.addFields(
                {
                    name: "User Name:",
                    value: `${interaction.member.displayName}`,
                    inline: true
                },
                {
                    name: "ID:",
                    value: `${interaction.user.id}`,
                    inline: true
                },
                {
                    name: "Bot:",
                    value: `${interaction.user.bot}`,
                    inline: true
                },
                {
                    name: "Joined server:",
                    value: `<t:${parseInt(interaction.member.joinedTimestamp / 1000)}:R>`,
                    inline: false
                },
                {
                    name: "Account Created:",
                    value: `<t:${parseInt(interaction.user.createdTimestamp / 1000)}:R>`,
                    inline: false
                },
                {
                    name: "Roles:",
                    value: `${interaction.member.roles.cache.map(r => r).join(" ").replace("@everyone", " ") || "None"} `,
                    inline: false
                }, 
            )
            .setImage(interaction.user.avatarURL({dynamic: true}))
            interaction.reply({embeds: [embed]})
        }
    }
}