const { CommandInteraction, Client, MessageEmbed, MessageSelectMenu, MessageActionRow } = require(`discord.js`);

module.exports = {
    name: `rolepanel`,
    description: `Setup your dropdown role system`,
    options: [
        {
            name: "role1",
            description: "Provide a role",
            type: "ROLE",
            required: true
        },
        {
            name: "role2",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role3",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role4",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role5",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role6",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role7",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role8",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role9",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role10",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role11",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role12",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role13",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role14",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role15",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role16",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role17",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role18",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role19",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role20",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role21",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role22",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role23",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role24",
            description: "Provide a role",
            type: "ROLE",
        },
        {
            name: "role25",
            description: "Provide a role",
            type: "ROLE",
        },
    ],
    /**
     * @param {CommandInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        const role1 = interaction.options.getRole("role1");
        const role2 = interaction.options.getRole("role2");
        const role3 = interaction.options.getRole("role3");
        const role4 = interaction.options.getRole("role4");
        const role5 = interaction.options.getRole("role5");
        const role6 = interaction.options.getRole("role6");
        const role7 = interaction.options.getRole("role7");
        const role8 = interaction.options.getRole("role8");
        const role9 = interaction.options.getRole("role9");
        const role10 = interaction.options.getRole("role10");
        const role11 = interaction.options.getRole("role11");
        const role12 = interaction.options.getRole("role12");
        const role13 = interaction.options.getRole("role13");
        const role14 = interaction.options.getRole("role14");
        const role15 = interaction.options.getRole("role15");
        const role16 = interaction.options.getRole("role16");
        const role17 = interaction.options.getRole("role17");
        const role18 = interaction.options.getRole("role18");
        const role19 = interaction.options.getRole("role19");
        const role20 = interaction.options.getRole("role20");
        const role21 = interaction.options.getRole("role21");
        const role22 = interaction.options.getRole("role22");
        const role23 = interaction.options.getRole("role23");
        const role24 = interaction.options.getRole("role24");
        const role25 = interaction.options.getRole("role25");

        const embed = new MessageEmbed()
            .setColor("NOT_QUITE_BLACK")
            .setAuthor({name: interaction.guild.name, iconURL: interaction.guild.iconURL({dynamic: true})})
            .setDescription(`If you like to get a role, please select which role you would like! Automatically adds or removes your role depending on if you have it or not.`);

        let rolesArray = [{ label: role1.name, value: role1.id, description: `Select the ${role1.name} role`}];
        let rolesList = [role2, role3, role4, role5, role6, role7, role8, role9, role10, role11, role12, role13, role14, role15, role16, role17, role18, role19, role20, role21, role22, role23, role24, role25];
        for (let i = 0; i < rolesList.length; i++) {
            if (rolesList[i]) rolesArray.push({ label: rolesList[i].name, value: rolesList[i].id, description: `Select the ${rolesList[i].name} role`});
        }

        const roles = new MessageSelectMenu()
            .setCustomId("role-menu")
            .setPlaceholder("Select a role!")
            .setOptions(rolesArray);

        await interaction.channel.send({embeds: [embed], components: [new MessageActionRow().addComponents(roles)]}).catch(() => {
            const embed = new MessageEmbed()
                .setColor("RED")
                .setDescription(`<:denied:941879735200382986> There was an error while trying to setup the dropdown role system`);
            return interaction.reply({ephemeral: true, embeds: [embed]});
        })
        interaction.reply({content: `Done`, ephemeral: true});
    },
}