const { CommandInteraction, Client, MessageEmbed, MessageButton, Guild, MessageActionRow } = require("discord.js");
const { connection } = require("mongoose");

module.exports = {
    name: "tos",
    description: "Agree to the TOS",
    options: [
        {
            name: 'user',
            description: 'Mention the user',
            required: true,
            type: 'USER'
        }],
    /**
     * 
     * @param {CommandInteraction} interaction 
     * @param {Client} client 
     */
    async execute(interaction, client) {
        let deUser = await interaction.options.getUser('user');
        let buttons = new MessageActionRow()
        .addComponents(
            new MessageButton()
                .setCustomId('agreeToS')
                .setLabel('I Agree')
                .setStyle('PRIMARY')
        )
        let embed = new MessageEmbed()
        .setAuthor({ name: deUser.tag, iconURL: deUser.avatarURL({ dynamic: true }) })
        .setTitle(`Terms of Service`)
        .setURL('https://discord.com/terms')
        .setColor('#0099ff')
        .setDescription(`Please **confirm** that you agree to the **[Terms of Service]** \nby pressing the blue button below that says \`I Agree\`.`)
        .setFooter({ text: deUser.id })
        .setTimestamp()
        try { embed.setThumbnail(interaction.guild.iconURL({ dynamic: true })) } catch(e) {}

        await interaction.reply({ embeds: [embed], components: [buttons] })
    }
};