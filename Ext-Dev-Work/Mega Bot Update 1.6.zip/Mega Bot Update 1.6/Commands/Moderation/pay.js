const { CommandInteraction, Client, MessageEmbed, MessageButton, Guild, MessageActionRow } = require("discord.js");
const config = require('../../Structures/config.json');

module.exports = {
    name: "pay",
    description: "Pay Command",
    options: [
        {
            name: 'price',
            description: 'The price of the payment',
            required: true,
            type: 'STRING'
        }],
    /**
     * 
     * @param {CommandInteraction} interaction 
     * @param {Client} client 
     */
    async execute(interaction, client) {
        let price = await interaction.options.getString("price")
        if(config.utility_module.usePayPal) {
        let paypalEmbed = new MessageEmbed()
        .setColor(`#427ef5`)
        .setTitle(`PayPal Payment`)
        .setThumbnail(`https://img.icons8.com/color/452/paypal.png`)
        .setDescription(`**PayPal: ||${config.utility_module.aPayPalLink}||**\nNotify us if you have chosen this option.`)
        await interaction.channel.send({ embeds: [paypalEmbed] }).catch(e => {});
    }

    if(config.utility_module.useCashApp) {
        let cashappEmbed = new MessageEmbed()
        .setColor(`#0be000`)
        .setTitle(`CashApp Payment`)
        .setThumbnail(`https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Square_Cash_app_logo.svg/1200px-Square_Cash_app_logo.svg.png`)
        .setDescription(`**CashApp: ||${config.utility_module.aCashAppLink}||**\nNotify us if you have chosen this option.`)
        await interaction.channel.send({ embeds: [cashappEmbed] }).catch(e => {});
    }

    if(config.utility_module.useVenmo) {
        let venmoEmbed = new MessageEmbed()
        .setColor(`#00cee0`)
        .setTitle(`Venmo Payment`)
        .setThumbnail(`https://global-uploads.webflow.com/5f4dd3623430990e705ccbba/5f7f7f2d126b05512021cf9b_app-icon.original.png`)
        .setDescription(`**Venmo: ||${config.utility_module.aVenmoLink}||**\nNotify us if you have chosen this option.`)
        await interaction.channel.send({ embeds: [venmoEmbed] }).catch(e => {});
    }

    let embed = new MessageEmbed()
    .setAuthor({ name: `${interaction.member.user.tag}`, iconURL: interaction.member.displayAvatarURL() })
    .setDescription(`**Please pay \`${price}\` to __one__ of the above payment methods.**`)
    await interaction.channel.send({ embeds: [embed] }).catch(e => {});
    
    embed.setDescription('I have sent the payment message!')
    
    await interaction.reply({ embeds: [embed], ephemeral: true})
    }
};