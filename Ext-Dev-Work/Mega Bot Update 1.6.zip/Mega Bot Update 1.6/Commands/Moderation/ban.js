const { CommandInteraction, MessageEmbed, Client } = require("discord.js");
const { LogChan, STAFFID } = require("../../Structures/config.json");

module.exports = {
    name: "ban",
    description: "Ban a user.",
    options: [
        {
            name: "user",
            description: "Who is the user you want to ban?",
            type: "USER",
            required: true
        },
        {
            name: "reason",
            description: "What is the reason for the ban?",
            type: "STRING",
            required: true
        }
    ],
    /**
     * 
     * @param {CommandInteraction} interaction 
     * @param {Client} client 
     */
    async execute(interaction, client) {
        const { options, guild } = interaction;
        const Member = options.getMember("user");
        const Reason = options.getString("reason");
        if(Member.roles.cache.has(STAFFID)) {
        if (!Member.permissions.has("KICK_MEMBERS")) return interaction.reply({content: `You can not ban a staff Member!`, ephemeral: true});
        if(Member.id === interaction.user.id) return interaction.reply({content: "You can not ban yourself 😂", ephemeral: true});
        const embed = new MessageEmbed()
        .setColor("RED") 
        .setTitle("A user was banned from the server!")
        .setThumbnail(Member.displayAvatarURL({dynamic: true}))
        .setAuthor(guild.name, guild.iconURL({dynamic: true}))
        .setFields(
            {
                name: "Staff Member:",
                value: `${interaction.user}`
            },
            {
                name: "User:",
                value: `${Member}`
            },
            {
                name: "Reason:",
                value: `${Reason}`
            },

        )
        .setTimestamp()
        .setFooter(guild.name + " | @2022", guild.iconURL({dynamic: true}));

       const MESSAGE = new MessageEmbed()
        .setColor("RED") 
        .setTitle(`You were banned from **${guild.name}**`)
        .setThumbnail(Member.displayAvatarURL({dynamic: true}))
        .setAuthor(guild.name, guild.iconURL({dynamic: true}))
        .setFields(
            {
                name: "Staff Member:",
                value: `${interaction.user}`
            },
            {
                name: "Reason:",
                value: `${Reason}`
            },

        )
        .setTimestamp()
        .setFooter(guild.name + " | @2022", guild.iconURL({dynamic: true}));
        if (!Member.user.bot) return Member.send({embeds: [MESSAGE]}); 
        interaction.reply({embeds: [embed], ephemeral: true});
        await guild.channels.cache.get(LogChan).send({embeds: [embed]});
        await Member.ban({reason: Reason});;
        if (Member.user.bot) return 
        interaction.reply({embeds: [embed], ephemeral: true});
        await guild.channels.cache.get(LogChan).send({embeds: [embed]});
        await Member.ban({reason: Reason});;
        
    } else {
        interaction.reply({content: "You do not have permissions to use this command!", ephemeral: true})
    }
}
}