const { Embed } = require("@discordjs/builders");
const { CommandInteraction, MessageEmbed, Client } = require("discord.js");
const { LogChan } = require("../../Structures/config.json");

module.exports = {
    name: "kick",
    description: "Kick a user.",
    permission: "ADMINISTRATOR",
    options: [
        {
            name: "user",
            description: "Who is the user you want to kick?",
            type: "USER",
            required: true
        },
        {
            name: "reason",
            description: "What is the reason for the kick?",
            type: "STRING",
            required: true
        }
    ],
    /**
     * 
     * @param {CommandInteraction} interaction 
     * @param {Client} client 
     */
    async execute(interaction, client) {
        const { options, guild } = interaction;
        const Member = options.getMember("user");
        const Reason = options.getString("reason");
        const MEMBER = guild.members.cache.get(Member.id);
        if (MEMBER.permissions.has("KICK_MEMBERS")) return interaction.reply({content: `You can not kick a staff member!`, ephemeral: true});
        if(MEMBER.id === interaction.user.id) return interaction.reply({content: "You can not kick yourself 😂", ephemeral: true});
        const embed = new MessageEmbed()
        .setColor("RED") 
        .setTitle("A user was kicked from the server!")
        .setThumbnail(Member.displayAvatarURL({dynamic: true}))
        .setAuthor(guild.name, guild.iconURL({dynamic: true}))
        .setFields(
            {
                name: "Staff Member:",
                value: `${interaction.user}`
            },
            {
                name: "User:",
                value: `${Member}`
            },
            {
                name: "Reason:",
                value: `${Reason}`
            },

        )
        .setTimestamp()
        .setFooter(guild.name + " | @2022", guild.iconURL({dynamic: true}));

       const MESSAGE = new MessageEmbed()
        .setColor("RED") 
        .setTitle(`You were kicked from **${guild.name}**`)
        .setThumbnail(Member.displayAvatarURL({dynamic: true}))
        .setAuthor(guild.name, guild.iconURL({dynamic: true}))
        .setFields(
            {
                name: "Staff Member:",
                value: `${interaction.user}`
            },
            {
                name: "Reason:",
                value: `${Reason}`
            },

        )
        .setTimestamp()
        .setFooter(guild.name + " | @2022", guild.iconURL({dynamic: true}));
        if (!Member.user.bot) return MEMBER.send({embeds: [MESSAGE]}); 
        interaction.reply({embeds: [embed], ephemeral: true});
        await guild.channels.cache.get(LogChan).send({embeds: [embed]});
        await MEMBER.kick();;
        if (Member.user.bot) return 
        interaction.reply({embeds: [embed], ephemeral: true});
        await guild.channels.cache.get(LogChan).send({embeds: [embed]});
        await MEMBER.kick();;
        
    }
    
}