const { CommandInteraction, MessageEmbed, Client } = require("discord.js");

module.exports ={
    name: "clear",
    description: "Deletes messages!",
    permission: "MANAGE_MESSAGES",
    options: [
        {
            name: "amount",
            description: "Amount of messages to delete",
            type: "NUMBER",
            required: true
        },
        {
            name: "user",
            description: "Who's messages do you want to delete!",
            type: "USER",
            required: false
        },
    ],
    /**
     * 
     * @param {CommandInteraction} interaction 
     * @param {Client} client 
     */
    async execute(interaction, client) {
        const { channel, options } = interaction;

        const Amount = options.getNumber("amount");
        if(Amount > 100) return interaction.reply({content: "🚨🚨Wait Hold up Limit is 100✨1-100🚨🚨"});
        if(Amount < 1) return interaction.reply({content: "🚨🚨Wait Hold up are you dumb its ✨1-100🚨🚨"});
        const Member = options.getMember("user");

        const messages = await channel.messages.fetch(); 

        const embed = new MessageEmbed()
        .setColor("RED")

        if(Member) {
            let i = 0;
            const filtered = [];
            (await messages).filter((m) => {
                if(m.author.id === Member.id && Amount > i) {
                    filtered.push(m);
                    i++;
                }
            })
            await channel.bulkDelete(filtered, true).then(messages => {
                embed.setDescription(`🧹 Removed ${messages.size} messages from ${Member}.`)
                interaction.reply({embeds: [embed], ephemeral: true})
            })
        } else {
            await channel.bulkDelete(Amount, true).then(messages => {
                embed.setDescription(`🧹 Removed ${messages.size} messages.`)
                interaction.reply({embeds: [embed], ephemeral: true})
            })
        }
    }
}