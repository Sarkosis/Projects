const { CommandInteraction, Client, MessageEmbed } = require("discord.js");
const { remove } = require("../../Structures/Schemas/TicketDB");


module.exports = {
    name: "ticket-options",
    description: "Add/Remove a user from a ticket.",
    permission: "MANAGE_CHANNELS",
    options: [
        {
            name: "add",
            description: "Add a user to the ticket with their ID",
            type: "USER",
        },
        {
            name: "remove",
            description: "Remove a user from the ticket.",
            type: "USER",
        },
    ],
    /**
     * 
     * @param {CommandInteraction} interaction 
     * @param {Client} client 
     */
    async execute (interaction, client) {
        const { options, channel, guild } = interaction;
        if(options.getMember("add")) {
            const Member = options.getMember("add");
            channel.permissionOverwrites.edit(Member.id, {
                SEND_MESSAGES: true,
                VIEW_CHANNEL: true,
                READ_MESSAGE_HISTORY: true

            })
            const embed = new MessageEmbed()
            .setTitle("A user has been added to the ticket.")
            .setDescription(`User: ${Member}\n\nStaff Member: ${interaction.user}`)
            .setFooter(guild.name, guild.iconURL({dynamic: true}))
            .setTimestamp();
            interaction.reply({embeds: [embed]});
        } else {
            const Member = options.getMember("remove");
            channel.permissionOverwrites.edit(Member.id, {
                SEND_MESSAGES: false,
                VIEW_CHANNEL: false,
                READ_MESSAGE_HISTORY: false

            })
            const embed = new MessageEmbed()
            .setTitle("A user has been removed from the ticket.")
            .setDescription(`User: ${Member}\n\nStaff Member: ${interaction.user}`)
            .setFooter(guild.name, guild.iconURL({dynamic: true}))
            .setTimestamp();
            interaction.reply({embeds: [embed]});
        }
        console.log(`ticket-options.js | ${interaction.user.tag} used this command!`)
    }
}