const { CommandInteraction, MessageEmbed, Client } = require("discord.js");
const { STAFFID } = require("../../Structures/config.json");

module.exports = {
    name: "ticket-messages",
    description: "Send an intro or outro in a ticket!",
    options: [
        {
            name: "options",
            description: "Send a intro message.",
            type: "STRING",
            choices: [
                {
                    name: "intro",
                    value: "intro"
                },
                {
                    name: "outro",
                    value: "outro"
                }
            ],
        }
    ],
    /**
     * 
     * @param {CommandInteraction} interaction 
     * @param {Client} client 
     */
    async execute(interaction, client) {
        const Options = interaction.options.getString("options");
        const embed = new MessageEmbed();
        if (!interaction.member.roles.cache.has(`${STAFFID}`)) {
        return interaction.reply({content: "You do not have permissions to use this command!", ephemeral: true})
        } else {
            switch(Options) {
                case "intro" : {
                    embed.setDescription(`Hey! My name is **${interaction.member.user.username}**, with the __${interaction.guild.name}__ Staff Team! How may I assist you today?`);
                    interaction.reply({content: "Intro sent", ephemeral: true});
                    return interaction.channel.send({embeds: [embed]});
                }
                break;
                case "outro" : {
                    embed.setDescription(`Thanks for choosing __${interaction.guild.name}__!\nSincerely - **${interaction.member.user.username}**`);
                    interaction.reply({content: "Intro sent", ephemeral: true});
                    return interaction.channel.send({embeds: [embed]});
                }
                break;
            }
        }
        console.log(`ticket-messages.js | ${interaction.member.user.tag}`)
    }
}