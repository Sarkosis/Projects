const { MessageEmbed, CommandInteraction, MessageActionRow, MessageButton } = require("discord.js");

const { OPENTICKET } = require("../../Structures/config.json");

module.exports = {
    name: "ticketpanel",
    description: "Open a ticket",
    permission: "ADMINISTRATOR",
    /**
     * 
     * @param {CommandInteraction} interaction 
     */
    async execute(interaction) {
        const { guild } = interaction;
        const embed = new MessageEmbed()
        .setAuthor(guild.name + " | Ticket Panel", guild.iconURL({dynamic: true}))
        .setColor("#36393f")
        .setDescription(`🎟️ Press on of the buttons below to open a ticket of your choice!🔽`)
        
        const Buttons = new MessageActionRow();
        Buttons.addComponents(
            new MessageButton()
            .setCustomId("Buying")
            .setLabel("Buying")
            .setStyle("PRIMARY")
            .setEmoji("💲"),
            new MessageButton()
            .setCustomId("Commission")
            .setLabel("Commission")
            .setStyle("PRIMARY")
            .setEmoji("💵"),
            new MessageButton()
            .setCustomId("Support")
            .setLabel("Support")
            .setStyle("PRIMARY")
            .setEmoji("🧻"),
            new MessageButton()
            .setCustomId("Bug Report")
            .setLabel("Bug Report")
            .setStyle("PRIMARY")
            .setEmoji("🐛"),
        );

        await guild.channels.cache.get(OPENTICKET).send({embeds: [embed], components: [Buttons]})

            interaction.reply({content: `Done | Ticket panel send to <#${OPENTICKET}>`, ephemeral: true})
    }
}