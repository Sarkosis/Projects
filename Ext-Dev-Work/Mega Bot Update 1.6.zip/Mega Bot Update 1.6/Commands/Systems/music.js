const { Client, MessageEmbed, CommandInteraction } = require("discord.js");

module.exports = {
    name: "music",
    description: "Music system.",
    permission: "SEND_MESSAGES",
    options: [
        {
            name: "play",
            description: "Play a song.",
            type: "SUB_COMMAND",
            options: [{ name: "song", description: "Provide a Name or URL of a song.", type: "STRING", required: true }]
        },
        {
            name: "volume",
            description: "Adjust music volume.",
            type: "SUB_COMMAND",
            options: [{ name: "number", description: "1-100", type: "NUMBER", required: true }]
        },
        {
            name: "filters",
            description: "Toggle filters",
            type: "SUB_COMMAND",
            options: [{ name: "set", description: "Choose a filter", type: "STRING", required: true,
            choices: [
                {name: "🔌 Turn off all filters", value: "false"},
                {name: "📣 Toggle 8d filter", value: "8d"},
                {name: "📣 Toggle bassboost filter", value: "bassboost"},
                {name: "📣 Toggle echo filter", value: "echo"},
                {name: "📣 Toggle nightcore filter", value: "nightcore"},
                {name: "📣 Toggle surround filter", value: "surround"},
                {name: "📣 Toggle karaoke filter", value: "karaoke"},
                {name: "📣 Toggle vaporwave filter", value: "vaporwave"},
                {name: "📣 Toggle flanger filter", value: "flanger"},
                {name: "📣 Toggle gate filter", value: "gate"},
                {name: "📣 Toggle haas filter", value: "haas"},
                {name: "📣 Toggle reverse filter", value: "reverse"},
                {name: "📣 Toggle mcompand filter", value: "mcompand"},
                {name: "📣 Toggle phaser filter", value: "phaser"},
                {name: "📣 Toggle tremolo filter", value: "tremolo"},
                {name: "📣 Toggle earwax filter", value: "earwax"},
        
            ]}]
        },
        {
            name: "settings",
            description: "Select option.",
            type: "SUB_COMMAND",
            options: [{ name: "options", description: "Select", type: "STRING", required: true, 
            choices: [
                {name: "⏺ View Queue", value: "queue"},
                {name: "⏭ Skip Song", value: "skip"},
                {name: "⏮ Previous Song", value: "previous"},
                {name: "⏸ Pause Song", value: "pause"},
                {name: "⏯ Resume Song", value: "resume"},
                {name: "⏹ Stop Playing", value: "stop"},
                {name: "🔀 Shuffle Queue", value: "shuffle"},
                {name: "🔃 Toggle Autoplay Modes", value: "AutoPlay"},
                {name: "🔁 Toggle Repeat Modes", value: "RepeatModes"},
            ]}]
        }
    ],
    /**
     * 
     * @param {CommandInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        const { options, member, guild, channel } = interaction;
        const VoiceChannel = member.voice.channel;

        if(!VoiceChannel) 
        return interaction.reply({ content: `> You must be in a voice channel to use music commands.`, ephemeral: true });

        if(guild.me.voice.channelId && VoiceChannel.id !== guild.me.voice.channelId)
        return interaction.reply({ content: `> I'm already playing music in <#${guild.me.voice.channelId}>.`, ephemeral: true });

        try {
            switch(options.getSubcommand()) {
                case "play" : {
                    client.distube.play( VoiceChannel, options.getString("song"), { textChannel: channel, member: member });
                    return interaction.reply({ content: `> <:icons8musicalnotes50:954207390625067058> Request received, processing...` });
                }

                case "volume" : {
                    const Volume = options.getNumber("number");
                    if(Volume > 100 || Volume < 1)
                    return interaction.reply({ content: "You must specify number between 1 and 100." });

                    client.distube.setVolume(VoiceChannel, Volume);
                    return interaction.reply({ content: `<:icons8speaker50:954207390557937684> Volume has been adjust to **${Volume}%**` });
                }
                
                case "settings" : {
                    const queue = await client.distube.getQueue(VoiceChannel);

                    if(!queue)
                    return interaction.reply({ content: `> There is nothing playing`, ephemeral: true });

                    switch(options.getString("options")) {
                        case "skip" : await queue.skip(VoiceChannel);
                        return interaction.reply({ content: "Song has been skipped."});

                        case "previous" : await queue.previous(VoiceChannel);
                        return interaction.reply({ content: "Song has been rewinded."});

                        case "stop" : await queue.stop(VoiceChannel);
                        return interaction.reply({ content: "Song has been stopped."});

                        case "pause" : await queue.pause(VoiceChannel);
                        return interaction.reply({ content: "Song has been paused."});
                        
                        case "resume" : await queue.resume(VoiceChannel);
                        return interaction.reply({ content: "Song has been resumed."});

                        case "shuffle" : await queue.shuffle(VoiceChannel);
                        return interaction.reply({ content: " Queue has been shuffled."});

                        case "AutoPlay" : let autoplay = await queue.toggleAutoplay(VoiceChannel);
                        return interaction.reply({ content: ` Autoplay Mode is set to: **${autoplay ? "ON" : "OFF"}**`});

                        case "RepeatModes" : let repeat = await client.distube.setRepeatMode(VoiceChannel);
                        return interaction.reply({ content: ` Repeat Mode is set to: **${repeat = repeat ? repeat == 2 ? "Queue" : "Current Song" : "OFF"}**`});

                        case "queue" :
                        return interaction.reply({ embeds: [new MessageEmbed()
                        .setColor("AQUA")
                        .setThumbnail(client.user.avatarURL({dynamic: true}))
                        .setDescription(`${queue.songs.slice(0, 10).map(
                            (song, id) => `\n**${id + 1}**. ${song.name} - \`${song.formattedDuration}\``)}`
                        )]});
                    }
                    return;
                }
                
                case "filters" : {
                    const queue = await client.distube.getQueue(VoiceChannel);

                    if(!queue)
                    return interaction.reply({content: " There is no queue"});

                    switch(options.getString("set")) {
                        case "false" : 
                        await queue.setFilter(false);
                        return interaction.reply({content: ` Disabled all filters.`});

                        case "8d" : 
                        await queue.setFilter(`3d`);
                        return interaction.reply({content: ` Toggled the 8D filter.`});

                        case "karaoke" : 
                        await queue.setFilter(`karaoke`);
                        return interaction.reply({content: ` Toggled the karaoke filter.`});
                        
                        case "vaporwave" : 
                        await queue.setFilter(`vaporwave`);
                        return interaction.reply({content: ` Toggled the vaporwave filter.`});

                        case "flanger" : 
                        await queue.setFilter(`flanger`);
                        return interaction.reply({content: ` Toggled the flanger filter.`});

                        case "gate" : 
                        await queue.setFilter(`gate`);
                        return interaction.reply({content: ` Toggled the gate filter.`});

                        case "haas" : 
                        await queue.setFilter(`haas`);
                        return interaction.reply({content: ` Toggled the haas filter.`});

                        case "reverse" : 
                        await queue.setFilter(`reverse`);
                        return interaction.reply({content: ` Toggled the reverse filter.`});

                        case "mcompand" : 
                        await queue.setFilter(`mcompand`);
                        return interaction.reply({content: ` Toggled the mcompand filter.`});

                        case "phaser" : 
                        await queue.setFilter(`phaser`);
                        return interaction.reply({content: ` Toggled the phaser filter.`});

                        case "tremolo" : 
                        await queue.setFilter(`tremolo`);
                        return interaction.reply({content: ` Toggled the tremolo filter.`});

                        case "earwax" : 
                        await queue.setFilter(`earwax`);
                        return interaction.reply({content: ` Toggled the earwax filter.`});

                        case "bassboost" : 
                        await queue.setFilter(`bassboost`);
                        return interaction.reply({content: ` Toggled the bassboost filter.`});
                        
                        case "echo" : 
                        await queue.setFilter(`echo`);
                        return interaction.reply({content: ` Toggled the echo filter.`});
                        
                        case "nightcore" : 
                        await queue.setFilter(`nightcore`);
                        return interaction.reply({content: ` Toggled the nightcore filter.`});
                        
                        case "surround" : 
                        await queue.setFilter(`surround`);
                        return interaction.reply({content: ` Toggled the surround filter.`});
                        
                    }
                }
            }
        } catch (e) {
            const errorEmbed = new MessageEmbed().setColor("RED")
            .setDescription(`Alert: ${e}`)
            return await interaction.reply({ embeds: [errorEmbed] });
        }
    }
}