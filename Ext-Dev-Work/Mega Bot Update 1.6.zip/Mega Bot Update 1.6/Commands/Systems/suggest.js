﻿const { CommandInteraction, MessageEmbed } = require("discord.js");

module.exports = {
    name: "suggest",
    description: "Suggest some thing for the bot!",
    options: [
        {
            name: "type",
            description: "What type of suggestion?",
            type: "STRING",
            required: true,
            choices: [
                {
                    name: "Bots",
                    value: "Bots"
                },
                {
                    name: "Vehicle",
                    value: "Vehicle"
                },
                {
                    name: "Suggestion",
                    value: "Suggestion"
                },
            ]
        },
        {
            name: "name",
            description: "Name of you suggestion!",
            type: "STRING",
            required: true
        },
        {
            name: "content",
            description: "What should this suggestion do?",
            type: "STRING",
            required: true
        }
    ],
    /**
     * 
     * @param {CommandInteraction} interaction 
     */
    async execute(interaction) {
        const { options } = interaction;
        interaction.member.displayAvatarURL({dynamic: true})
        const type = options.getString("type");
        const name = options.getString("name");
        const cont = options.getString("content");
        const embed = new MessageEmbed()
        .setColor("AQUA")
        .setDescription(`${interaction.member} has suggested a ${type}`)
        .addField("Name:", `${name}`, true)
        .addField("Content:", `${cont}`, true)
        .setFooter(`User ID: ${interaction.member.id}`, interaction.member.avatarURL({dynamic: true}))
        const message = await interaction.reply({embeds: [embed], fetchReply: true})
        message.react("✅")
        message.react("❌")
    }
}