const { Client, MessageEmbed, GuildMember } = require("discord.js");
const { LogChan } = require("../../Structures/config.json");

module.exports = {
    name: "userUpdate",
    description: "User Update Logger",


    /**
     * 
     * @param {GuildMember} oldUser 
     * @param {GuildMember} newUser 
     * @param {Client} client
     */
    async execute(oldUser, newUser, client) {
        if (oldUser.displayAvatarURL() != newUser.displayAvatarURL()) {
        const embed = new MessageEmbed()
        .setTitle(`User avatar updated`)
        .setDescription(`User: ${newUser}`)
        .setImage(newUser.avatarURL({dynamic: true}))
        client.channels.cache.get(`${LogChan}`).send({embeds: [embed]});
        } else {

        }
    }
}