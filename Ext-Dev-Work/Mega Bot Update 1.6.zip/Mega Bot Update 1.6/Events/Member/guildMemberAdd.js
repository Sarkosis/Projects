const { MessageEmbed, WebhookClient, GuildMember } = require("discord.js");
const { WelcomeChan, MemberWelcome } = require("../../Structures/config.json");
const MemberJoin = require(`../../Structures/config.json`).MemberJoin;
const UnverifyRoleID = require(`../../Structures/config.json`).UnverifyRoleID;

module.exports = {
    name: "guildMemberAdd",
    /**
     * 
     * @param {GuildMember} member 
     */
    async execute(member) {
    
        const { user, guild } = member;

        member.roles.add(MemberJoin);
        member.roles.add(UnverifyRoleID);
        
        const Welcomer = new WebhookClient({
            id: "id goes here",
            token: "token goes here"
        });
        
        const Welcome = new MessageEmbed()
        .setColor("AQUA")
        .setAuthor(user.tag, user.avatarURL({dynamic: true, size: 512}))
        .setThumbnail(user.avatarURL({dynamic: true, size: 512}))
        .setDescription(`
        Welcome ${member} to the **${guild.name}**!\n
        Account Created: <t:${parseInt(user.createdTimestamp / 1000)}:R>\nLatest Member Count: **${guild.memberCount}**`)
        .setFields(
            {name: `Verify`, value: `<#990103367072223252>`},
            {name: `Rules`, value: `<#720765591702732901>`},
        )
        .setFooter(`ID: ${user.id}`)

        Welcomer.send({embeds: [Welcome]});
        member.send({ embeds: [Welcome] }).catch(() => {});
        
    }
}