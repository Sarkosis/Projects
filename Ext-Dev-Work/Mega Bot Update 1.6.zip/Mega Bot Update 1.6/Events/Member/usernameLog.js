const { Client, MessageEmbed, GuildMember } = require("discord.js");
const { LogChan } = require("../../Structures/config.json");

module.exports = {
    name: "userUpdate",
    description: "User Update Logger",


    /**
     * 
     * @param {GuildMember} oldUser 
     * @param {GuildMember} newUser 
     * @param {Client} client
     */
    async execute(oldUser, newUser, client) {
        if (oldUser.username != newUser.username) {
            console.log(oldUser.username);
            const embed = new MessageEmbed()
            .setAuthor(`User Updated`, client.user.displayAvatarURL())
            .setThumbnail(`${newUser.displayAvatarURL({ dynamic: true })}`)
            .addFields(
                {name: `User:`, value: `${newUser.tag || "someone"}`},
                {name: `Before:`, value: `\`Tag:\` ${oldUser.tag}\n\`ID:\` ${oldUser.id}\n\`Username:\` ${oldUser.username}\n\`#:\` ${oldUser.discriminator}`},
                {name: `After:`, value: `\`Tag:\` ${newUser.tag}\n\`ID:\` ${newUser.id}\n\`Username:\` ${newUser.username}\n\`#:\` ${newUser.discriminator}`},
            )
            .setTimestamp()

            client.channels.cache.get(`${LogChan}`).send({embeds: [embed]});
        }
    }
}