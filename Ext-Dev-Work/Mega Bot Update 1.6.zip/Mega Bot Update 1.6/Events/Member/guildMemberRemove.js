const { MessageEmbed, WebhookClient, GuildMember, Client } = require('discord.js');
const { LeaveChan, MemberLeave } = require("../../Structures/config.json");
module.exports = { 
    name: "guildMemberRemove",
    description: "Guild Member Remove Log",
    /**
     * 
     * @param {GuildMember} member 
     * @paran {Client} client
     */
    async execute(member, client) {
        if (MemberLeave === true) {
        const { user, guild } = member;
        const Welcomer = new WebhookClient({
            id: 'ID',
            token: "token",
        })

        const Welcome = new MessageEmbed()
        .setColor("AQUA")
        .setAuthor(user.tag, user.avatarURL({dynamic: true, size: 512}))
        .setThumbnail(user.avatarURL({dynamic: true, size: 512}))
        .setDescription(`
         ${member} has left the server!\n
        Account Created on: <t:${parseInt(member.user.createdTimestamp / 1000)}:R>\n
        Latest Member Count: **${guild.memberCount}**`)
        .addField("Server Member Since", `<t:${parseInt(member.joinedAt / 1000)}:R>`, false)
        .addField("Discord User Since", `<t:${parseInt(member.user.createdTimestamp / 1000)}:R>`, true)
        .addField(`Presence : `, `**${user.presence?.status || `Online`}**`, true) 

        .setFooter(`ID: ${user.id}`, user.avatarURL({dynamic: true}))
        client.channels.cache.get(`${LeaveChan}`).send({embeds: [Welcome]})
    } else {
        console.log(`MemberLeave is set to false in config.json. | MemberLeave was no executed`)
    }
    }
}