﻿const { 
    ButtonInteraction,
    MessageEmbed,
    MessageActionRow,
    MessageButton
} = require("discord.js");

const DB = require("../../Structures/Schemas/TicketDB");
const { TICKETCATAGORY, TICKETROLEID, STAFFID } = require("../../Structures/config.json");
const {Ticketpingid} = require("../../Structures/config.json")

module.exports = {
    name: "interactionCreate",
    description: "Ticket Buttons",
    /**
     * 
     * @param {ButtonInteraction} interaction 
     */
    async execute(interaction) {
        if (!interaction.isButton()) return;

        const { guild, member, customId } = interaction;

        if(!["Buying", "Commission", "Support", "Bug Report"].includes(customId)) return;

        const ID = Math.floor(Math.random() + 90000) + 10000;

        await guild.channels.create(`${customId + '-' + member.user.username}`, {
            type: "GUILD_TEXT",
            parent: TICKETCATAGORY,
            permissionOverwrites: [
                {
                    id: member.id,
                    allow: ["SEND_MESSAGES", "VIEW_CHANNEL", "READ_MESSAGE_HISTORY"],
                },
                
                {
                    id: guild.roles.everyone.id,
                    deny: ["VIEW_CHANNEL"],
                },
                 
                {
                    id: guild.roles.cache.get(TICKETROLEID),
                    allow: ['SEND_MESSAGES', 'VIEW_CHANNEL', 'READ_MESSAGE_HISTORY'],
                },
            ],
        }).then(async(channel) => {
            await DB.create({
                GuildID: guild.id,
                MemberID: member.id,
                TicketID: customId + '-' + member.user.username,
                ChannelID: channel.id,
                Closed: false,
                Locked: false,
                Type: customId,
            });
            const embed = new MessageEmbed()
        .setAuthor(`${member.user.username}'s Ticket`, guild.iconURL({dynamic: true}))
        .setDescription(`Please describe your issue or problem and a Staff Team Member will be with you shortly!`)
        .setFooter(`The buttons below are staff only!`)
        .setTimestamp();
        const Buttons = new MessageActionRow();
        Buttons.addComponents(
            new MessageButton()
            .setCustomId("ticket-close")
            .setLabel("Close Ticket")
            .setStyle("PRIMARY")
            .setEmoji("📪"),
            new MessageButton()
            .setCustomId("ticket-lock")
            .setLabel("Lock Ticket")
            .setStyle("PRIMARY")
            .setEmoji("🔒"),
            new MessageButton()
            .setCustomId("ticket-unlock")
            .setLabel("UnLock Ticket")
            .setStyle("PRIMARY")
            .setEmoji("🔓"),
        );
            channel.send({
                content: `${member} | <@&${Ticketpingid}>`,
                embeds: [embed],
                components: [Buttons]
            });

            interaction.reply({
                content: `Your ticket has been made | ${channel}`,
                ephemeral: true
            })
        });
    }
};