﻿const { 
    ButtonInteraction, 
    MessageEmbed,
    MessageActionRow,
    MessageButton,
} = require("discord.js");
const { createTranscript } = require("discord-html-transcripts");
const { TRANSCRIPTSID, STAFFID } = require("../../Structures/config.json");
const DB = require("../../Structures/Schemas/TicketDB");

module.exports = {
    name: "interactionCreate",
    description: "Ticket Options",
    /**
     * 
     * @param {ButtonInteraction} interaction 
     */
    async execute(interaction) {
        if (!interaction.isButton()) return;

        const { guild, customId, channel, member } = interaction;
            if(!["ticket-close", "ticket-lock", "ticket-unlock"].includes(customId)) return;

        const embed = new MessageEmbed().setColor("BLUE");


         DB.findOne({ChannelID: channel.id}, async(err, docs) => {
             if(err) throw err;
             if(!docs) 
             return interaction.reply({
                 content: "No data was found related to this ticket. Please delete manually!",
                  ephemeral: true
                });
             
             if(!interaction.member.roles.cache.has(STAFFID)) {
                  return interaction.reply({content: "You do not have permissions to use this button!", ephemeral: true});
             } else 
             switch(customId) {
                 case "ticket-lock" : 
                     if(docs.Locked == true)
                     return interaction.reply({
                         content: "The ticket is already locked!",
                          ephemeral: true
                        });
                     await DB.updateOne({ChannelID: channel.id}, {Locked: true});
                     embed.setDescription("🔒 | This ticket is now locked!");
                     channel.permissionOverwrites.edit(docs.MemberID, {
                         SEND_MESSAGES: false,
                     });
                     channel.permissionOverwrites.edit(STAFFID, {
                         SEND_MESSAGES: false,
                     });

                     [{
                        id: interaction.user.id,
                        allow: ['SEND_MESSAGES', 'VIEW_CHANNEL']
                    },
                    {
                        id: everyoneRole.id,
                        deny: ['SEND_MESSAGES', 'VIEW_CHANNEL']
                    },
                    {
                        id: client.user.id,
                        allow: ['SEND_MESSAGES', 'VIEW_CHANNEL']
                    },
                ]
                     
                     return interaction.reply({embeds: [embed]});
                     break;
                case "ticket-unlock" :
                    if(docs.Locked == false)
                    return interaction.reply({content: "The ticket is already unlocked!", ephemeral: true});
                    await DB.updateOne({ChannelID: channel.id}, {Locked: false})
                    embed.setDescription("🔓 | This ticket is now unlocked!");
                    channel.permissionOverwrites.edit(docs.MemberID, {
                        SEND_MESSAGES: true,
                    });
                    return interaction.reply({embeds: [embed]});
                    break;
                case "ticket-close" :{
                    if(docs.Closed == true)  {
                    return interaction.reply({content: "Ticket is already closed please wait for it to delete!", ephemeral: true});
                    } else {
                        await DB.updateOne({ChannelID: channel.id}, {Closed: true})
                    const attachment = await createTranscript(channel, {
                        limit: -1,
                        returnBuffer: false,
                        fileName: `${docs.Type} - ${docs.TicketID}.html`
                    });                    
                    const MEMBER = guild.members.cache.get(docs.MemberID);
                    const Message = await guild.channels.cache.get(TRANSCRIPTSID).send({embeds: [embed.setAuthor(MEMBER.user.tag, MEMBER.user.displayAvatarURL({dynamic: true})).setTitle(`Transcript Type: ${docs.Type}\nID: ${docs.TicketID}`)
                ],
                files: [attachment],               
                });
 
                interaction.reply({embeds: [embed.setDescription(`The transcript is now saved! | [Transcript](${Message.url})`)]})
                MEMBER.send({embeds: [embed.setAuthor(MEMBER.user.tag, MEMBER.user.displayAvatarURL({dynamic: true})).setTitle(`Transcript`).setDescription(`You ticket has been closed\n Type: **${docs.Type}**\nID: **${docs.TicketID}**\nClosed By: **${interaction.user.tag}**`)],files: [attachment],});
                setTimeout(() => {
                    channel.delete()
                }, 10 * 1000);
            }
            }
             }
    })
    }
}