const client = require("../../Structures/index");
const { MessageEmbed } = require("discord.js");
const Client = require("discord.js");
module.exports = {
    name: "Distube - Ignore the X there is nothing wrong with this file!",
    description: "Distube events",
}
const status = queue =>
    `Volume: \`${queue.volume}%\` | Filter: \`${queue.filters.join(', ') || 'Off'}\` | Loop: \`${queue.repeatMode ? (queue.repeatMode === 2 ? 'All Queue' : 'This Song') : 'Off'
    }\` | Autoplay: \`${queue.autoplay ? 'On' : 'Off'}\``

client.distube
    .on('playSong', (queue, song) => queue.textChannel.send({ embeds: [new MessageEmbed()
        .setFields(
            {
                name: "Playing:",
                value: `${song.name}`,
                inline: true
            },
            {
                name: "Song Duration:",
                value: `${song.formattedDuration}`,
                inline: true
            },
            {
                name: "Requested By:",
                value: `${song.user}`,
                inline: true
            },
        )
        .setImage(song.thumbnail)
        .setTimestamp()
        .setFooter(`Likes: ${song.likes}`)
        ]}
        ))

    .on('addSong', (queue, song) => queue.textChannel.send({ embeds: [new MessageEmbed()
        
        .setFields(
            {name: "Added Song:", value: `${song.name}`},
            {name: "Duration:", value: `${song.formattedDuration}`},
        )
        .setImage(song.thumbnail)
        .setTimestamp()
        .setFooter(`Added  by: ${song.user.tag}`)
    ]}
    ))
    
    .on('addList', (queue, playlist) => queue.textChannel.send({ embeds: [new MessageEmbed()
        
        .setDescription(` | Added \`${playlist.name}\` playlist (${playlist.songs.length} songs) to queue\n${status(queue)}`)]}
    ))

    .on('error', (channel, e) => {
        channel.send({ embeds: [new MessageEmbed()
        
        .setDescription(`An error encountered: ${e.toString().slice(0, 1974)}`)]})
        console.log(e)
    })
    
    .on('empty', queue => queue.textChannel.send({ embeds: [new MessageEmbed()
        
        .setDescription('Voice channel is empty! Leaving the channel...')]})
    )
        
    .on('searchNoResult', (message, query) => messgage.channel.send({ embeds: [new MessageEmbed()
        
        .setDescription(`No result found for \`${query}\`!`)]})
    )
    
    .on('finish', queue => queue.textChannel.send({ embeds: [new MessageEmbed()
        
        .setDescription(`Queue finished, leaving voice channel...`)]})
    )