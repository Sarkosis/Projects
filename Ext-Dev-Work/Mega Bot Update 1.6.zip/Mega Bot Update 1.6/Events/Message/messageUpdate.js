const { MessageEmbed, Message, WebhookClient } = require("discord.js");
const { LogChan, MessageUpdate } = require("../../Structures/config.json");
module.exports = {
    name: "messageUpdate",
    description: "Message Update",
    /**
     * 
     * @param {Message} oldMessage 
     * @param {Message} newMessage 
     */
    execute(oldMessage, newMessage) {
        if (MessageUpdate === true) {
        
        if(oldMessage.author.bot) return;

        if(oldMessage.content === newMessage.content) return;

        const Count = 1950;
        const Original = oldMessage.content.slice(0, Count) + (oldMessage.content.length > 1950 ? "..." : "")
        const Edited = newMessage.content.slice(0, Count) + (newMessage.content.length > 1950 ? "..." : "")
        const Log = new MessageEmbed()
        .setColor("NOT_QUITE_BLACK")
        .setDescription(`A [message](${newMessage.url}) by ${newMessage.author} was **edited** in ${newMessage.channel}`)
        .addField("Original", `\`\`\`${Original}\`\`\``, false)
        .addField("Edited", `\`\`\`${Edited}\`\`\``, false)
        .setFooter(`Member: ${newMessage.author.tag} | ID: ${newMessage.author.id}`, newMessage.author.avatarURL({dynamic: true}))

        if(newMessage.attachments.size > 0) {
            Log.addField(`Attachments`, `${newMessage.attachments.map((a) => a.url)}`, false)
        }
        newMessage.guild.channels.cache.get(LogChan).send({embeds: [Log]})
    } else {
        console.log(`MessageUpdate is set to false in config.json. | MessageUpdate was not executed! | ${newMessage.content.slice(0, 1950) + (newMessage.content.length > 1950 ? "..." : "")} | ${newMessage.author.tag}`)
    }
    }
}