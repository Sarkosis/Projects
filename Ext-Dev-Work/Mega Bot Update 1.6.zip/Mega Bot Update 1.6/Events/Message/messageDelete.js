const { MessageEmbed, Message, WebhookClient } = require("discord.js");
const client = require("../../Structures");
const { LogChan, MessageUpdate } = require("../../Structures/config.json");
module.exports = {
    name: "messageDelete",
    description: "Message Delete",
/**
 * 
 * @param {Message} message 
 */
    execute(message) {
        const embed = new MessageEmbed()
        .setAuthor(`Message Deleted`, client.user.displayAvatarURL({dynamic: true}))
        .setFields(
            {name: `User:`, value: `${message.author}`},
            {name: `Channel:`, value: `${message.channel}\n\n`},
            {name: `Content:`, value: `\`${message.content}\``},
        )
        .setTimestamp()
        .setFooter(message.guild.name + " @2022", message.guild.iconURL({dynamic: true}));

        client.channels.cache.get(`${LogChan}`).send({embeds: [embed]});
    }
}