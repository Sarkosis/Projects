const { 
    ButtonInteraction,
    MessageEmbed,
    MessageActionRow,
    MessageButton,
    Client,
    Guild
} = require("discord.js");

module.exports = {
    name: "interactionCreate",
    description: "Help Buttons",

    /**
     * 
     * @param {ButtonInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        const { customId } = interaction;
        if(!["user-cmd", "admin-cmd", "own-cmd"].includes(customId)) return;

        if(["user-cmd"].includes(customId)) {
            const embed = new MessageEmbed()
            .setTitle(`User Commands`)
            .setThumbnail(client.user.displayAvatarURL({dynamic: true}))
            .setDescription(
                `**User Commands**\n\n[] Required\n () Optional`
                )
            .addFields(
                {name: "/ping", value: "View the bots ping! 🏓"},
                {name: "/status", value: "View the bots stats!"},
                {name: "/user", value: "View a users info!"},
                {name: "/suggests", value: "Suggest something for the server!"},
                {name: "/serverinfo", value: "View the bots stats!"},
                {name: "/credits", value: "View credits of the bot!"},
                {name: "/apply", value: "apply for something."},
            )
            .setTimestamp()
            .setFooter(interaction.guild.name, interaction.guild.iconURL({dynamic: true}));
            interaction.update({embeds: [embed]})
        }
        if (["admin-cmd"].includes(customId)) {
            const embed = new MessageEmbed()
            .setTitle(`Admin Commands`)
            .setThumbnail(client.user.displayAvatarURL({dynamic: true}))
            .setDescription(
                `**Admin Commands**\n[] Required\n () Optional`
                )
            .addFields(
                {name: "/application [id]", value: "id of application then you can approve or deny"},
                {name: "/ban [User] [Reason]", value: "Ban a user from the server!"},
                {name: "/kick [User] [Reason]", value: "Kick a user from the server!"},
                {name: "/clear [Amount] (User)", value: "Deletes messages from a channel or a specific user."},
                {name: "/emitt", value: "Test your welcome and leave message."},
                {name: "/giveaway", value: "Start a giveaway."},
                {name: "/ticket-open", value: "Open up a ticket panel."},
                {name: "/ticket-options", value: "Add/Remove a user from a ticket."},
                {name: "/ticket-messages", value: "Let the bot send an intro or outro message."},
                {name: "/music play", value: "To start to play a song."},
            )
            .setTimestamp()
            .setFooter(interaction.guild.name, interaction.guild.iconURL({dynamic: true}));
            interaction.update({embeds: [embed]})
        }
        if (["own-cmd"].includes(customId)) {
            const embed = new MessageEmbed()
            .setTitle(`Admin Commands`)
            .setThumbnail(client.user.displayAvatarURL({dynamic: true}))
            .setDescription(
                `**Owner Commands**\n[] Required\n () Optional`
                )
            .addFields(
                {name: "/restart", value: "Restart the bot."},
            )
            .setTimestamp()
            .setFooter(interaction.guild.name, interaction.guild.iconURL({dynamic: true}));
            interaction.update({embeds: [embed]})
        }
        
    }
}