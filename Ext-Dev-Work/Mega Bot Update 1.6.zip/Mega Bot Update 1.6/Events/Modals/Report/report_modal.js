const { Client, MessageEmbed, Application } = require("discord.js");
const { ReportLog } = require("../../../Structures/config.json");

module.exports = {
	name: "modalSubmit",
    description: "Report",
	async execute(interaction, client) {

		if (interaction.customId == "report") {
            const user = interaction.getTextInputValue("user");
			const reason = interaction.getTextInputValue("reason");

			const embed = new MessageEmbed()
				.setColor("GREEN")
				.setTitle(`User Report`)
				.setDescription(`Report sent by: <@${interaction.member.id}>`)
				.addField("User:", `<@${user}>`)
				.addField("Reason:", `${reason}`)

			const channel = client.channels.cache.get(`${ReportLog}`);

			channel.send({ embeds: [embed] });

			await interaction.deferReply({ ephemeral: true });
			interaction.followUp("Your report was successfully sent. The staff team will look over it soon!");
		}
	},
};
