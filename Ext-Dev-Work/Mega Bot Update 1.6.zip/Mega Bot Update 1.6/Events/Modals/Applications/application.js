const { Client, MessageEmbed, Application,
    MessageActionRow,
    MessageButton} = require("discord.js");
const { ApplicationLog } = require("../../../Structures/config.json");

module.exports = {
	name: "modalSubmit",
    description: "Application",
	async execute(interaction, client) {

		if (interaction.customId == "application") {
			const age = interaction.getTextInputValue("age");
            const gender = interaction.getTextInputValue("experience");
			const answer = interaction.getTextInputValue("mod");

			const embed = new MessageEmbed()
				.setColor("GREEN")
				.setTitle(`Staff Application`)
				.setDescription(`Application sent by: <@${interaction.member.id}>`)
				.addField("What is your age?", `${age}`)
				.addField("Do you have any experience as staff?", `${gender}`)
				.addField("Why do you want to be a mod?", `${answer}`)
				.addField("Why should we choose you?", `${answer}`);	
			const channel = client.channels.cache.get(`${ApplicationLog}`);

			channel.send({ embeds: [embed] });

			await interaction.deferReply({ ephemeral: true });
			interaction.followUp("Your application was successfully submitted.");
		}
	},
};
