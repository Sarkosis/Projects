const { Client, MessageEmbed, Application } = require("discord.js");

module.exports = {
	name: "modalSubmit",
    description: "Embed Builder",
	async execute(interaction, client) {

		if (interaction.customId == "embed") {
            const Title = interaction.getTextInputValue("title");
			const Content = interaction.getTextInputValue("content");

			const embed = new MessageEmbed()
				.setColor("GREEN")
				.setTitle(`${Title}`)
				.setDescription(`${Content}`)
                .setFooter(`Sent by: ${interaction.member.tag}`,interaction.member.displayAvatarURL({dynamic: true}))

			interaction.channel.send({ embeds: [embed] });

			await interaction.deferReply({ ephemeral: true });
			interaction.followUp("Your embed was successfully sent.");
		}
	},
};
