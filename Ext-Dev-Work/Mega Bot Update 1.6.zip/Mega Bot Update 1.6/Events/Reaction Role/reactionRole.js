const { Client, MessageEmbed, SelectMenuInteraction } = require("discord.js");

module.exports = {
    name: "interactionCreate",
    /**
     * @param {SelectMenuInteraction} interaction 
     * @param {Client} client 
     */
    async execute(interaction, client) {
        if (!interaction.isSelectMenu) return;
        if (interaction.customId !== "role-menu") return;
        const embed = new MessageEmbed();

        const roleToGive = interaction.values[0];
        const roleFetched = await interaction.guild.roles.fetch(roleToGive);
        if (!roleFetched) {
            embed
                .setColor("RED")
                .setDescription(`<:denied:941879735200382986> This role doesn't exist`);
            return interaction.reply({embeds: [embed], ephemeral: true});
        }

        if (roleFetched.managed === true || !roleFetched.editable) {
            embed
                .setColor("RED")
                .setDescription(`<:denied:941879735200382986> I cannot give this role to you`);
            return interaction.reply({embeds: [embed], ephemeral: true});
        }

        if (interaction.member.roles.cache.has(roleToGive)) {
            return await interaction.member.roles.remove(roleFetched).then(() => {
                embed
                    .setColor("GREEN")
                    .setDescription(`<:approved:941879734768398337> Removed the ${roleFetched} role from you`);
                return interaction.reply({embeds: [embed], ephemeral: true});
            }).catch(() => {
                embed
                    .setColor("RED")
                    .setDescription(`<:denied:941879735200382986> I do not have permission to remove that role from you`);
                return interaction.reply({embeds: [embed], ephemeral: true});
            });
        } else {
            return await interaction.member.roles.add(roleFetched).then(() => {
                embed
                    .setColor("GREEN")
                    .setDescription(`<:approved:941879734768398337> Added the ${roleFetched} role to you`);
                return interaction.reply({embeds: [embed], ephemeral: true});
            }).catch(() => {
                embed
                    .setColor("RED")
                    .setDescription(`<:denied:941879735200382986> I do not have permission to add that role to you`);
                return interaction.reply({embeds: [embed], ephemeral: true});
            });
        }
    }
}