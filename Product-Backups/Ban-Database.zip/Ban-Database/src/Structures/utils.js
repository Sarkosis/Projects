const chalk = require("chalk");
const axios = require("axios");
const config = require("../../config.json");
const { EmbedBuilder } = require("discord.js");

async function error(client, content) {
  if (client.config.client.debugmode) {
    console.log(
      chalk.red("DEBUG MODE ERROR: ", content, `\n ${content.stack}`)
    );
  }
}

function hasRole(roleID, member) {
  if (!member.roles.cache.some((role) => role.id === roleID)) {
    return false;
  } else return true;
}

function sortRoles(rows) {
  let sortedroles = [];
  rows.forEach((row) => {
    sortedroles.push(row.RoleID);
  });
  return sortedroles;
}

function hasRoles(checkroles, userroles) {
  let results = [];
  checkroles.forEach((role) => {
    let index = userroles.indexOf(role);
    if (index === -1) {
      results.push("false");
    } else results.push("true");
  });
  let result;
  if (results.indexOf("true") === -1) {
    result = false;
  } else result = true;
  return result;
}

async function versionChecker() {
  setTimeout(async () => {
    const version = require("../../package.json").version;
    const currver = version;
    const req = await axios({
      method: "get",
      url: "https://raw.githubusercontent.com/Sarkosis/version-pub-api/main/versions.json",
      headers: {
        Accept: "application/json, text/plain, */*",
        "User-Agent": "*",
      },
    });
    const latestver = req.data.bandb;
    if (latestver != currver) {
      console.log(
        `${chalk.yellow("[Version Checker]\n")}${chalk.red(
          `You are not on the latest version.\nCurrent Version: ${currver}\nLatest Version: ${latestver}`
        )}`
      );
    } else {
      console.log(
        `${chalk.green("[Version Checker]")} You are on the latest version.`
      );
    }
  }, 1000);
}

async function license(licenseKey, uniqueId) {
  let request = await axios({
    method: "get",
    url: `https://store.sarksdevelopment.com/api/v1/license/check/${licenseKey}`,
    headers: {
      Accept: "application/json, text/plain, */*",
      "User-Agent": "*",
      productid: uniqueId,
    },
  });

  if (request.data.authorized) {
    setTimeout(() => {
      console.log(`${chalk.green.dim("[License Check]")} License Key Accepted`);
    }, 1001);
  } else {
    console.log(`${chalk.red.dim("[License Check]")} License Key Failed`);
    process.exit(1);
  }
}
license(config.licensekey, "1673116248215obFd4gq7M0HAfD");
versionChecker();

function ticketider(t) {
  let ticketid;
  if (t < 10) {
    ticketid = "000" + t;
  } else if (t < 100) {
    ticketid = "00" + t;
  } else if (t < 1000) {
    ticketid = "0" + t;
  } else if (t >= 1000) {
    ticketid = t;
  }
  return ticketid;
}

async function ticketPerms(row, channel) {
  let roles = [];
  row.forEach((r) => {
    roles.push(r.RoleID);
  });
  roles.forEach(async (role) => {
    await channel.permissionOverwrites.edit(role, {
      ViewChannel: true,
      ReadMessageHistory: true,
      SendMessages: true,
      AddReactions: true,
      AttachFiles: true,
      EmbedLinks: true,
      SendMessagesInThreads: true,
      UseApplicationCommands: true,
      UseExternalEmojis: true,
      UseExternalStickers: true,
    });
  });
}

async function logtoservers(client, embed) {
  await client.con.query(`SELECT * FROM guilds`, async (e, rows) => {
    if (e) {
      if (client.config.debugmode) {
        console.log(e.stack);
      }
    }
    for (let data of rows) {
      try {
        let guild = await client.guilds.cache.get(data?.GuildID);
        let thechan = await guild.channels.cache.get(data?.Banlogs);
        setTimeout(async () => {
          await thechan.send({ embeds: [embed] }).catch(() => {});
        }, 5000);
      } catch (error) {}
    }
  });
}

async function gban(client, user) {
  await client.con.query(
    `SELECT * FROM guilds WHERE AutoBans = "true"`,
    async (e, rows) => {
      if (e) {
        if (client.config.debugmode) {
          console.log(e.stack);
        }
      }
      for (let data of rows) {
        try {
          let guild = await client.guilds.cache.get(data?.GuildID);
          setTimeout(async () => {
            await guild.bans.create(user.id);
          }, 5000);
        } catch (error) {
          console.log(error);
        }
      }
    }
  );
}

async function gunban(client, user) {
  await client.con.query(
    `SELECT * FROM guilds WHERE AutoUnbans = "true"`,
    async (e, rows) => {
      if (e) {
        if (client.config.debugmode) {
          console.log(e.stack);
        }
      }
      for (let data of rows) {
        try {
          let guild = await client.guilds.cache.get(data?.GuildID);
          setTimeout(async () => {
            await guild.bans.remove(user.id);
          }, 5000);
        } catch (error) {}
      }
    }
  );
}

async function syncbans(client, guild) {
  await client.con.query(`SELECT * FROM cases`, async (e, rows) => {
    if (e) {
      if (client.config.debugmode) {
        console.log(e.stack);
      }
    }
    for (let data of rows) {
      try {
        setTimeout(async () => {
          await guild.bans.create(data?.UserID);
        }, 5000);
      } catch (error) {}
    }
    await client.con.query(
      `SELECT * FROM blacklistedusers`,
      async (e, rows) => {
        if (e) {
          if (client.config.debugmode) {
            console.log(e.stack);
          }
        }
        for (let data of rows) {
          try {
            setTimeout(async () => {
              await guild.bans.create(data?.UserID);
            }, 5000);
          } catch (error) {}
        }
        try {
          let theg = await client.guilds.cache.get(
            client.config.support.guildid
          );
          let thec = await theg.channels.cache.get(
            client.config.support.synclogs
          );
          let embed = new EmbedBuilder()
            .setColor(client.config.color)
            .setTitle("Bans Synced")
            .setDescription(`${guild.name} has synced bans with the database!`)
            .setFooter({ text: `Guild ID | ${guild.id}` });
          thec.send({ embeds: [embed] }).catch(() => {});
        } catch (error) {}
      }
    );
  });
}

exports.hasRoles = hasRoles;
exports.sortRoles = sortRoles;
exports.ticketPerms = ticketPerms;
exports.ider = ticketider;
exports.error = error;
exports.hasRole = hasRole;
exports.logtoservers = logtoservers;
exports.gban = gban;
exports.gunban = gunban;
exports.syncbans = syncbans;
