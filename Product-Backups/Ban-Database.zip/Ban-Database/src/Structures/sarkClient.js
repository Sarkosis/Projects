const { Client, Collection } = require("discord.js");
class SarkClient extends Client {
  constructor(options = {}) {
    super(options);
    this.utils = require("./utils");
    this.config = require("../../config.json");
    this.commands = new Collection();
    this.commandArray = [];
  }
}

exports.SarkClient = SarkClient;
