const {
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  ChannelType,
} = require("discord.js");

module.exports = {
  name: "interactionCreate",
  async execute(interaction, client) {
    if (interaction.isButton()) {
      let { customId, guild, channel } = interaction;
      let dabuttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("a")
          .setStyle(ButtonStyle.Success)
          .setDisabled(true)
          .setLabel("Controls:"),
        new ButtonBuilder()
          .setCustomId("auto-bans-toggle")
          .setStyle(ButtonStyle.Primary)
          .setLabel("Toggle Auto Bans"),
        new ButtonBuilder()
          .setCustomId("auto-unbans-toggle")
          .setStyle(ButtonStyle.Primary)
          .setLabel("Toggle Auto Unbans"),
        new ButtonBuilder()
          .setCustomId("set-ban-logs")
          .setStyle(ButtonStyle.Primary)
          .setLabel("Set Ban Logs")
      );
      let thebuttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("b")
          .setStyle(ButtonStyle.Success)
          .setDisabled(true)
          .setLabel("Controls:"),
        new ButtonBuilder()
          .setCustomId("set-report-logs")
          .setStyle(ButtonStyle.Primary)
          .setLabel("Set Report Logs"),
        new ButtonBuilder()
          .setCustomId("set-appeal-logs")
          .setStyle(ButtonStyle.Primary)
          .setLabel("Set Appeal Logs")
      );
      switch (customId) {
        case "auto-bans-toggle":
          {
            await client.con.query(
              `SELECT * FROM guilds WHERE GuildID = "${guild.id}"`,
              async (e, row) => {
                if (e) {
                  if (client.config.debugmode) {
                    console.log(e.stack);
                  }
                }
                let autobans;
                if (row[0]?.AutoBans === "true") {
                  autobans = "false";
                } else if (row[0]?.AutoBans === "false") {
                  autobans = "true";
                }
                await client.con.query(
                  `UPDATE guilds SET AutoBans = "${autobans}" WHERE GuildID = '${guild.id}'`,
                  async (e) => {
                    if (e) {
                      if (client.config.debugmode) {
                        console.log(e.stack);
                      }
                    }
                    await client.con.query(
                      `SELECT * FROM guilds WHERE GuildID = "${guild.id}"`,
                      async (e, row) => {
                        if (e) {
                          if (client.config.debugmode) {
                            console.log(e.stack);
                          }
                        }
                        let embed = new EmbedBuilder()
                          .setColor(client.config.color)
                          .setTitle("Guild Settings")
                          .setDescription(
                            `>>> **Automatic Bans:** - ${row[0]?.AutoBans}\n**Automatic Unbans:** - ${row[0]?.AutoUnbans}\n**Ban Logs:** <#${row[0]?.Banlogs}>\n**Report Logs:** <#${row[0]?.ReportLogs}>\n**Appeal Logs:** <#${row[0]?.AppealLogs}>`
                          );

                        await interaction.update({
                          embeds: [embed],
                          ephemeral: true,
                        });
                      }
                    );
                  }
                );
              }
            );
          }

          break;
        case "auto-unbans-toggle":
          {
            await client.con.query(
              `SELECT * FROM guilds WHERE GuildID = "${guild.id}"`,
              async (e, row) => {
                if (e) {
                  if (client.config.debugmode) {
                    console.log(e.stack);
                  }
                }
                let autounbans;
                if (row[0]?.AutoUnbans === "true") {
                  autounbans = "false";
                } else if (row[0]?.AutoUnbans === "false") {
                  autounbans = "true";
                }
                await client.con.query(
                  `UPDATE guilds SET AutoUnbans = "${autounbans}" WHERE GuildID = '${guild.id}'`,
                  async (e) => {
                    if (e) {
                      if (client.config.debugmode) {
                        console.log(e.stack);
                      }
                    }
                    await client.con.query(
                      `SELECT * FROM guilds WHERE GuildID = "${guild.id}"`,
                      async (e, row) => {
                        if (e) {
                          if (client.config.debugmode) {
                            console.log(e.stack);
                          }
                        }
                        let embed = new EmbedBuilder()
                          .setColor(client.config.color)
                          .setTitle("Guild Settings")
                          .setDescription(
                            `>>> **Automatic Bans:** - ${row[0]?.AutoBans}\n**Automatic Unbans:** - ${row[0]?.AutoUnbans}\n**Ban Logs:** <#${row[0]?.Banlogs}>\n**Report Logs:** <#${row[0]?.ReportLogs}>\n**Appeal Logs:** <#${row[0]?.AppealLogs}>`
                          );

                        await interaction.update({
                          embeds: [embed],
                          ephemeral: true,
                        });
                      }
                    );
                  }
                );
              }
            );
          }

          break;
        case "set-ban-logs":
          {
            let question = new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId("dummy")
                .setDisabled(true)
                .setStyle(ButtonStyle.Primary)
                .setLabel("Mention the ban logs channel")
            );
            await interaction.update({
              components: [question],
              ephemeral: true,
            });
            channel
              .awaitMessages({ max: 1, time: 60000, errors: ["time"] })
              .then(async (col) => {
                let thechan = col.first().mentions.channels.first();
                if (!thechan) {
                  await interaction.editReply({
                    components: [dabuttons, thebuttons],
                    ephemeral: true,
                  });
                  col.first().delete();
                  return channel
                    .send("There were no channels mentions")
                    .then((m) =>
                      setTimeout(() => {
                        m.delete();
                      }, 4000)
                    );
                }

                if (thechan.type !== ChannelType.GuildText) {
                  await interaction.editReply({
                    components: [dabuttons, thebuttons],
                    ephemeral: true,
                  });
                  col.first().delete();
                  return channel
                    .send(
                      "The mentioned channel wasn't a channel from this guild!"
                    )
                    .then((m) =>
                      setTimeout(() => {
                        m.delete();
                      }, 4000)
                    );
                }

                await client.con.query(
                  `UPDATE guilds SET Banlogs = "${thechan.id}" WHERE GuildID = '${guild.id}'`,
                  async (e) => {
                    if (e) {
                      if (client.config.debugmode) {
                        console.log(e.stack);
                      }
                    }
                    await client.con.query(
                      `SELECT * FROM guilds WHERE GuildID = '${guild.id}'`,
                      async (e, row) => {
                        if (e) {
                          if (client.config.debugmode) {
                            console.log(e.stack);
                          }
                        }
                        let embed = new EmbedBuilder()
                          .setColor(client.config.color)
                          .setTitle("Guild Settings")
                          .setDescription(
                            `>>> **Automatic Bans:** - ${row[0]?.AutoBans}\n**Automatic Unbans:** - ${row[0]?.AutoUnbans}\n**Ban Logs:** <#${row[0]?.Banlogs}>\n**Report Logs:** <#${row[0]?.ReportLogs}>\n**Appeal Logs:** <#${row[0]?.AppealLogs}>`
                          );

                        await interaction
                          .editReply({
                            embeds: [embed],
                            components: [dabuttons, thebuttons],
                            ephemeral: true,
                          })
                          .then(async () => {
                            await col.first().delete();
                          })
                          .catch(() => {});
                      }
                    );
                  }
                );
              });
          }

          break;
        case "set-report-logs":
          {
            let question = new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId("dummy")
                .setDisabled(true)
                .setStyle(ButtonStyle.Primary)
                .setLabel("Mention the report logs channel")
            );
            await interaction.update({
              components: [question],
              ephemeral: true,
            });
            channel
              .awaitMessages({ max: 1, time: 60000, errors: ["time"] })
              .then(async (col) => {
                let thechan = col.first().mentions.channels.first();
                if (!thechan) {
                  await interaction.editReply({
                    components: [dabuttons, thebuttons],
                    ephemeral: true,
                  });
                  col.first().delete();
                  return channel
                    .send("There were no channels mentions")
                    .then((m) =>
                      setTimeout(() => {
                        m.delete();
                      }, 4000)
                    );
                }

                if (thechan.type !== ChannelType.GuildText) {
                  await interaction.editReply({
                    components: [dabuttons, thebuttons],
                    ephemeral: true,
                  });
                  col.first().delete();
                  return channel
                    .send(
                      "The mentioned channel wasn't a channel from this guild!"
                    )
                    .then((m) =>
                      setTimeout(() => {
                        m.delete();
                      }, 4000)
                    );
                }

                await client.con.query(
                  `UPDATE guilds SET ReportLogs = "${thechan.id}" WHERE GuildID = '${guild.id}'`,
                  async (e) => {
                    if (e) {
                      if (client.config.debugmode) {
                        console.log(e.stack);
                      }
                    }
                    await client.con.query(
                      `SELECT * FROM guilds WHERE GuildID = '${guild.id}'`,
                      async (e, row) => {
                        if (e) {
                          if (client.config.debugmode) {
                            console.log(e.stack);
                          }
                        }
                        let embed = new EmbedBuilder()
                          .setColor(client.config.color)
                          .setTitle("Guild Settings")
                          .setDescription(
                            `>>> **Automatic Bans:** - ${row[0]?.AutoBans}\n**Automatic Unbans:** - ${row[0]?.AutoUnbans}\n**Ban Logs:** <#${row[0]?.Banlogs}>\n**Report Logs:** <#${row[0]?.ReportLogs}>\n**Appeal Logs:** <#${row[0]?.AppealLogs}>`
                          );

                        await interaction
                          .editReply({
                            embeds: [embed],
                            components: [dabuttons, thebuttons],
                            ephemeral: true,
                          })
                          .then(async () => {
                            await col.first().delete();
                          })
                          .catch(() => {});
                      }
                    );
                  }
                );
              });
          }

          break;
        case "set-appeal-logs":
          {
            let question = new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId("dummy")
                .setDisabled(true)
                .setStyle(ButtonStyle.Primary)
                .setLabel("Mention the appeal logs channel")
            );
            await interaction.update({
              components: [question],
              ephemeral: true,
            });
            channel
              .awaitMessages({ max: 1, time: 60000, errors: ["time"] })
              .then(async (col) => {
                let thechan = col.first().mentions.channels.first();
                if (!thechan) {
                  await interaction.editReply({
                    components: [dabuttons, thebuttons],
                    ephemeral: true,
                  });
                  col.first().delete();
                  return channel
                    .send("There were no channels mentions")
                    .then((m) =>
                      setTimeout(() => {
                        m.delete();
                      }, 4000)
                    );
                }

                if (thechan.type !== ChannelType.GuildText) {
                  await interaction.editReply({
                    components: [dabuttons, thebuttons],
                    ephemeral: true,
                  });
                  col.first().delete();
                  return channel
                    .send(
                      "The mentioned channel wasn't a channel from this guild!"
                    )
                    .then((m) =>
                      setTimeout(() => {
                        m.delete();
                      }, 4000)
                    );
                }

                await client.con.query(
                  `UPDATE guilds SET AppealLogs = "${thechan.id}" WHERE GuildID = '${guild.id}'`,
                  async (e) => {
                    if (e) {
                      if (client.config.debugmode) {
                        console.log(e.stack);
                      }
                    }
                    await client.con.query(
                      `SELECT * FROM guilds WHERE GuildID = '${guild.id}'`,
                      async (e, row) => {
                        if (e) {
                          if (client.config.debugmode) {
                            console.log(e.stack);
                          }
                        }
                        let embed = new EmbedBuilder()
                          .setColor(client.config.color)
                          .setTitle("Guild Settings")
                          .setDescription(
                            `>>> **Automatic Bans:** - ${row[0]?.AutoBans}\n**Automatic Unbans:** - ${row[0]?.AutoUnbans}\n**Ban Logs:** <#${row[0]?.Banlogs}>\n**Report Logs:** <#${row[0]?.ReportLogs}>\n**Appeal Logs:** <#${row[0]?.AppealLogs}>`
                          );

                        await interaction
                          .editReply({
                            embeds: [embed],
                            components: [dabuttons, thebuttons],
                            ephemeral: true,
                          })
                          .then(async () => {
                            await col.first().delete();
                          })
                          .catch(() => {});
                      }
                    );
                  }
                );
              });
          }

          break;

        default:
          break;
      }
    }
  },
};
