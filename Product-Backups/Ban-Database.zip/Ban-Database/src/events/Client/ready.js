const figlet = require("figlet");
const chalk = require("chalk");

module.exports = {
  name: "ready",
  once: true,
  async execute(client) {
    client.user.presence.set({
      activities: [
        {
          name: client.config.presence[0].name,
          type: client.config.presence[0].type
        }
      ],
      status: client.config.presence[0].status
    })
    figlet("Ban Database V2", function (err, data) {
      if (err) throw err;
      console.log(chalk.blue.dim(data));
    });
    setTimeout(() => {
      console.log(
        `${chalk.blue.dim(
          "[INVITE]:"
        )} https://discord.com/api/oauth2/authorize?client_id=${
          client.user.id
        }&scope=bot%20applications.commands`
      );
    }, 1000);
    setTimeout(() => {
      console.log(
        `${chalk.blue(`Loaded ${client.commands.size} Application Commands`)}\nCreated by Sarkosis#3052`
      );
    }, 1500);
  },
};
