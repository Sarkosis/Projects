const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("appeal")
    .setDescription("Report a user")
    .addStringOption((o) =>
      o
        .setName("reason")
        .setDescription("Why should you be unbanned?")
        .setRequired(true)
    )
    .addStringOption((o) =>
      o
        .setName("notes")
        .setDescription("Additional notes, if any")
        .setRequired(false)
    ),

  async execute(interaction, client) {
    const { options, member } = interaction;
    let reason = options.getString("reason");
    let notes = options.getString("notes") || "No additional notes...";
    await client.con.query(
      `SELECT * FROM cases WHERE UserID = '${member.id}'`,
      async (e, row) => {
        if (e) {
          if (client.config.debugmode) {
            console.log(e.stack);
          }
        }
        if (!row[0]) {
          return interaction.reply({
            content:
              "It seems that you aren't in our database as a banned user! You cannot submit an appeal.",
            ephemeral: true,
          });
        }
        await client.con.query(
          `SELECT COUNT(AppealID) as total FROM appeals`,
          async (e, res) => {
            if (e) {
              if (client.config.debugmode) {
                console.log(e.stack);
              }
            }
            let appealid = res[0]?.total + 1;
            await client.con.query(
              `INSERT INTO appeals (AppealID, Pending, UserID, UserTag, BanReason, UnbanReason, Notes) VALUES ("${appealid}", "true", "${member.id}", "${member.user.tag}", "${row[0]?.Reason}", "${reason}", "${notes}")`,
              async (e) => {
                if (e) {
                  if (client.config.debugmode) {
                    console.log(e.stack);
                  }
                }
                try {
                  let theg = await client.guilds.cache.get(
                    client.config.support.guildid
                  );
                  let thec = await theg.channels.cache.get(
                    client.config.support.appeallogs
                  );
                  let newid = client.utils.ider(appealid);
                  let embed = new EmbedBuilder()
                    .setColor(client.config.color)
                    .setTitle(`Appeal #${newid}`)
                    .setDescription(
                      `**Appealing User:** - ${member.user.tag} (${member.id})\n**Reason For Ban:** ${row[0]?.Reason}\n**Case:** ${appealid}`
                    )
                    .addFields(
                      {
                        name: "Reason Why They Should be Unbanned",
                        value: `${reason}`,
                        inline: true,
                      },
                      {
                        name: "Additional Notes (if any)",
                        value: `${notes}`,
                        inline: false,
                      }
                    );
                  thec.send({ embeds: [embed] }).catch(() => {});
                  return interaction.reply({
                    content: "Appeal was successfully submitted!",
                    ephemeral: true,
                  });
                } catch (error) {
                  return interaction.reply({
                    content:
                      "Failed to submit appeal!\n**Try again later, or contact the staff team if the issue occurs again.**",
                    ephemeral: true,
                  });
                }
              }
            );
          }
        );
      }
    );
  },
};
