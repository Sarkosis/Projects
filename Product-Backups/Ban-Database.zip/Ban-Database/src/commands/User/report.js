const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("report")
    .setDescription("Report a user")
    .addStringOption((o) =>
      o
        .setName("userid")
        .setDescription("Input the id of the user.")
        .setRequired(true)
    )
    .addStringOption((o) =>
      o
        .setName("reason")
        .setDescription("Reason for the report")
        .setRequired(true)
    )
    .addStringOption((o) =>
      o
        .setName("evidence")
        .setDescription("The evidence of your claims (URLs Only)")
        .setRequired(true)
    )
    .addStringOption((o) =>
      o
        .setName("notes")
        .setDescription("Additional notes, if any")
        .setRequired(false)
    ),

  async execute(interaction, client) {
    const { options, member } = interaction;
    let userid = options.getString("userid");
    let reason = options.getString("reason");
    let evidence = options.getString("evidence");
    let notes = options.getString("notes") || "No additional notes...";
    await client.con.query(
      `SELECT COUNT(ReportID) as total FROM reports`,
      async (e, res) => {
        if (e) {
          if (client.config.debugmode) {
            console.log(e.stack);
          }
        }
        let reportid = res[0]?.total + 1;
        let user = await client.users.fetch(userid).catch(() => {});
        if (!user) {
          return interaction.reply({
            embeds: [
              new EmbedBuilder()
                .setColor(client.config.color)
                .setTitle("User Not Found")
                .setDescription(
                  "The inserted id couldn't be resolved to a user.\n**Please check that you inserted the correct user id.**"
                ),
            ],
            ephemeral: true,
          });
        }
        await client.con.query(
          `INSERT INTO reports (ReportID, Pending, UserID, UserTag, ReporterID, Reason, Evidence, Notes) VALUES ("${reportid}", "true", "${user.id}", "${user.tag}", "${member.id}", "${reason}", "${evidence}", "${notes}")`,
          async (e) => {
            if (e) {
              if (client.config.debugmode) {
                console.log(e.stack);
              }
            }
            try {
              let theg = await client.guilds.cache.get(
                client.config.support.guildid
              );
              let thec = await theg.channels.cache.get(
                client.config.support.reportlogs
              );
              let newid = client.utils.ider(reportid);
              let embed = new EmbedBuilder()
                .setColor(client.config.color)
                .setTitle(`Report #${newid}`)
                .setDescription(
                  `**Reporting User:** - ${member.user.tag} (${member.id})\n**Reported User:** - ${user.tag} (${user.id})\n**Case:** ${reportid}`
                )
                .addFields({
                  name: "Additional Notes (if any)",
                  value: `${notes}`,
                  inline: true,
                });
              try {
                embed.setImage(evidence);
              } catch (rr) {
                embed.setFooter({ text: "Evidence failed to become image" });
              }
              thec.send({ embeds: [embed] }).catch(() => {});
              return interaction.reply({
                content: "Report was successfully submitted!",
                ephemeral: true,
              });
            } catch (error) {
              return interaction.reply({
                content:
                  "Failed to submit report!\n**Try again later, or contact the staff team if the issue occurs again.**",
                ephemeral: true,
              });
            }
          }
        );
      }
    );
  },
};
