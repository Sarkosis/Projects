const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("settings")
    .setDescription("Manage this guild's settings")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client) {
    const { guild } = interaction;
    await client.con.query(
      `SELECT * FROM guilds WHERE GuildID = '${guild.id}'`,
      async (e, row) => {
        if (e) {
          if (client.config.debugmode) {
            console.log(e.stack);
          }
        }
        if (!row[0]) {
          await client.con.query(
            `INSERT INTO guilds (GuildID, AutoBans, AutoUnbans, Banlogs, ReportLogs, AppealLogs) VALUES ("${guild.id}", "true", "true", "none", "none", "none")`,
            async (e) => {
              if (e) {
                if (client.config.debugmode) {
                  console.log(e.stack);
                }
              }
              await client.con.query(
                `SELECT * FROM guilds WHERE GuildID = '${guild.id}'`,
                async (e, row) => {
                  if (e) {
                    if (client.config.debugmode) {
                      console.log(e.stack);
                    }
                  }
                  let embed = new EmbedBuilder()
                    .setColor(client.config.color)
                    .setTitle("Guild Settings")
                    .setDescription(
                      `>>> **Automatic Bans:** - ${row[0]?.AutoBans}\n**Automatic Unbans:** - ${row[0]?.AutoUnbans}\n**Ban Logs:** <#${row[0]?.Banlogs}>\n**Report Logs:** <#${row[0]?.ReportLogs}>\n**Appeal Logs:** <#${row[0]?.AppealLogs}>`
                    );
                  let dabuttons = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                      .setCustomId("a")
                      .setStyle(ButtonStyle.Success)
                      .setDisabled(true)
                      .setLabel("Controls:"),
                    new ButtonBuilder()
                      .setCustomId("auto-bans-toggle")
                      .setStyle(ButtonStyle.Primary)
                      .setLabel("Toggle Auto Bans"),
                    new ButtonBuilder()
                      .setCustomId("auto-unbans-toggle")
                      .setStyle(ButtonStyle.Primary)
                      .setLabel("Toggle Auto Unbans"),
                    new ButtonBuilder()
                      .setCustomId("set-ban-logs")
                      .setStyle(ButtonStyle.Primary)
                      .setLabel("Set Ban Logs")
                  );
                  let thebuttons = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                      .setCustomId("b")
                      .setStyle(ButtonStyle.Success)
                      .setDisabled(true)
                      .setLabel("Controls:"),
                    new ButtonBuilder()
                      .setCustomId("set-report-logs")
                      .setStyle(ButtonStyle.Primary)
                      .setLabel("Set Report Logs"),
                    new ButtonBuilder()
                      .setCustomId("set-appeal-logs")
                      .setStyle(ButtonStyle.Primary)
                      .setLabel("Set Appeal Logs")
                  );
                  await interaction.reply({
                    embeds: [embed],
                    components: [dabuttons, thebuttons],
                    ephemeral: true,
                  });
                }
              );
            }
          );
        } else if (row[0]) {
          let embed = new EmbedBuilder()
            .setColor(client.config.color)
            .setTitle("Guild Settings")
            .setDescription(
              `>>> **Automatic Bans:** - ${row[0]?.AutoBans}\n**Automatic Unbans:** - ${row[0]?.AutoUnbans}\n**Ban Logs:** <#${row[0]?.Banlogs}>\n**Report Logs:** <#${row[0]?.ReportLogs}>\n**Appeal Logs:** <#${row[0]?.AppealLogs}>`
            );
          let dabuttons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId("a")
              .setStyle(ButtonStyle.Success)
              .setDisabled(true)
              .setLabel("Controls:"),
            new ButtonBuilder()
              .setCustomId("auto-bans-toggle")
              .setStyle(ButtonStyle.Primary)
              .setLabel("Toggle Auto Bans"),
            new ButtonBuilder()
              .setCustomId("auto-unbans-toggle")
              .setStyle(ButtonStyle.Primary)
              .setLabel("Toggle Auto Unbans"),
            new ButtonBuilder()
              .setCustomId("set-ban-logs")
              .setStyle(ButtonStyle.Primary)
              .setLabel("Set Ban Logs")
          );
          let thebuttons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId("b")
              .setStyle(ButtonStyle.Success)
              .setDisabled(true)
              .setLabel("Controls:"),
            new ButtonBuilder()
              .setCustomId("set-report-logs")
              .setStyle(ButtonStyle.Primary)
              .setLabel("Set Report Logs"),
            new ButtonBuilder()
              .setCustomId("set-appeal-logs")
              .setStyle(ButtonStyle.Primary)
              .setLabel("Set Appeal Logs")
          );
          await interaction.reply({
            embeds: [embed],
            components: [dabuttons, thebuttons],
            ephemeral: true,
          });
        }
      }
    );
  },
};
