const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("announce")
    .setDescription("Send a global announcement")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client) {
    const { guild } = interaction;
    await client.con.query(
      `SELECT * FROM staff WHERE UserID = '${interaction.user.id}'`,
      async (e, row) => {
        if (e) {
          if (client.config.debugmode) {
            console.log(e.stack);
          }
        }
        if (!row[0]) {
          return interaction.reply({
            content: "Only staff can use this feature!",
            ephemeral: true,
          });
        }
        await interaction.reply({
          content:
            "Please state your announcement within 5 minutes!\n**You can only do this once or you need to startover.**",
          ephemeral: true,
        });
        interaction.channel
          .awaitMessages({ max: 1, time: 300000, errors: ["time"] })
          .then(async (col) => {
            let msg = col.first().content;
            if (!msg) return;
            let embed = new EmbedBuilder()
              .setColor(client.config.color)
              .setTitle(`**${guild.name} Announcment**`)
              .setDescription(msg)
              .setFooter({
                text: `Announcement Sent By: ${interaction.user.tag}`,
                iconURL: interaction.user.displayAvatarURL({ dynamic: true }),
              });
            await client.utils.logtoservers(client, embed);
            return interaction.editReply({
              content: "Global announcement sent!",
              ephemeral: true,
            });
          });
      }
    );
  },
};
