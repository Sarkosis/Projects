const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require("discord.js");
const utils = require("hyperz-utils");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("staff")
    .setDescription("Staff Manager")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sub) =>
      sub
        .setName("add")
        .setDescription("Add a staff member to the database")
        .addStringOption((o) =>
          o
            .setName("userid")
            .setDescription("Input the user id")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("remove")
        .setDescription("Remove a staff member from the database")
        .addStringOption((o) =>
          o
            .setName("userid")
            .setDescription("Input the user id")
            .setRequired(true)
        )
    ),
  async execute(interaction, client) {
    const { guild, options } = interaction;
    if (!client.config.owner.includes(interaction.user.id)) return interaction.reply({ content: "You cannot use this command!!", ephemeral: true });
    let sub = options.getSubcommand();
    let userid = options.getString("userid");
    switch (sub) {
      case "add":
        {
          let user = await guild.members.fetch(userid).catch(() => {});
          await client.con.query(
            `SELECT * FROM staff WHERE UserID = "${user.id}"`,
            async (e, row) => {
              if (e) {
                if (client.config.debugmode) {
                  console.log(e.stack);
                }
              }
              if (row[0]) {
                return interaction.reply({
                  embeds: [
                    new EmbedBuilder()
                      .setColor(client.config.color)
                      .setTitle("User is Staff")
                      .setDescription(
                        "The inserted id matches a staff member inside the database already."
                      ),
                  ],
                  ephemeral: true,
                });
              }
              if (!user) {
                return interaction.reply({
                  embeds: [
                    new EmbedBuilder()
                      .setColor(client.config.color)
                      .setTitle("User Not Found")
                      .setDescription(
                        "The inserted id couldn't be resolved to a user.\n**Please check that you inserted the correct user id and that the is in this guild.**"
                      ),
                  ],
                  ephemeral: true,
                });
              }
              if (user) {
                await client.con.query(
                  `INSERT INTO staff (UserID) VALUES ("${user.id}")`,
                  async (e) => {
                    if (e) {
                      if (client.config.debugmode) {
                        console.log(e.stack);
                      }
                    }
                    let embed = new EmbedBuilder()
                      .setColor(client.config.color)
                      .setTitle("User Added to Staff Team")
                      .setDescription(
                        `**Staff Member:** - ${interaction.user.tag} (${
                          interaction.user.id
                        })\n**User:** - ${user.user.tag} (${
                          user.id
                        })\n**GuildID:** ${
                          guild.id
                        }\n**Date:** ${await utils.fetchTime(
                          client.config.date.tz,
                          client.config.date.format
                        )}`
                      )
                      .setFooter({ text: `Guild ${guild.id}` });
                    await client.utils.logtoservers(client, embed);
                    return interaction.reply({
                      embeds: [
                        new EmbedBuilder()
                          .setColor(client.config.color)
                          .setTitle("Success")
                          .setDescription(
                            "The user was added to the staff database."
                          ),
                      ],
                      ephemeral: true,
                    });
                  }
                );
              }
            }
          );
        }

        break;
      case "remove":
        {
          let user = await guild.members.fetch(userid).catch(() => {});
          await client.con.query(
            `SELECT * FROM staff WHERE UserID = "${user.id}"`,
            async (e, row) => {
              if (e) {
                if (client.config.debugmode) {
                  console.log(e.stack);
                }
              }
              if (!row[0]) {
                return interaction.reply({
                  embeds: [
                    new EmbedBuilder()
                      .setColor(client.config.color)
                      .setTitle("User isn't Staff")
                      .setDescription(
                        "The inserted id doesn't match a staff member inside the database."
                      ),
                  ],
                  ephemeral: true,
                });
              }
              if (!user) {
                return interaction.reply({
                  embeds: [
                    new EmbedBuilder()
                      .setColor(client.config.color)
                      .setTitle("User Not Found")
                      .setDescription(
                        "The inserted id couldn't be resolved to a user.\n**Please check that you inserted the correct user id and that the is in this guild.**"
                      ),
                  ],
                  ephemeral: true,
                });
              }
              if (user) {
                await client.con.query(
                  `DELETE FROM staff WHERE UserID = "${user.id}"`,
                  async (e) => {
                    if (e) {
                      if (client.config.debugmode) {
                        console.log(e.stack);
                      }
                    }
                    let embed = new EmbedBuilder()
                      .setColor(client.config.color)
                      .setTitle("User Removed from Staff Team")
                      .setDescription(
                        `**Staff Member:** - ${interaction.user.tag} (${
                          interaction.user.id
                        })\n**User:** - ${user.user.tag} (${
                          user.id
                        })\n**GuildID:** ${
                          guild.id
                        }\n**Date:** ${await utils.fetchTime(
                          client.config.date.tz,
                          client.config.date.format
                        )}`
                      )
                      .setFooter({ text: `Guild ${guild.id}` });
                    await client.utils.logtoservers(client, embed);
                    return interaction.reply({
                      embeds: [
                        new EmbedBuilder()
                          .setColor(client.config.color)
                          .setTitle("Success")
                          .setDescription(
                            "The user was removed from the staff database."
                          ),
                      ],
                      ephemeral: true,
                    });
                  }
                );
              }
            }
          );
        }

        break;

      default:
        break;
    }
  },
};
