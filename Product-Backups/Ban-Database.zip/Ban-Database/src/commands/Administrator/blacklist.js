const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
} = require("discord.js");
const utils = require("hyperz-utils");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("blacklist")
    .setDescription("Blacklist Manager")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sub) =>
      sub
        .setName("add")
        .setDescription("Add a user to the blacklist")
        .addStringOption((o) =>
          o
            .setName("userid")
            .setDescription("Input the user id")
            .setRequired(true)
        )
        .addStringOption((o) =>
          o
            .setName("reason")
            .setDescription("Input the blacklist reason")
            .setRequired(true)
        )
        .addStringOption((o) =>
          o
            .setName("evidence")
            .setDescription("Input the evidence, if any (URLs Only)")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("remove")
        .setDescription("Remove a user from the blacklist")
        .addStringOption((o) =>
          o
            .setName("userid")
            .setDescription("Input the user id")
            .setRequired(true)
        )
    ),
  async execute(interaction, client) {
    const { options } = interaction;
    let sub = options.getSubcommand();
    let userid = options.getString("userid");
    let reason = options.getString("reason");
    let evidence = options.getString("evidence");
    await client.con.query(
      `SELECT * FROM staff WHERE UserID = '${interaction.user.id}'`,
      async (e, row) => {
        if (e) {
          if (client.config.debugmode) {
            console.log(e.stack);
          }
        }
        if (!row[0]) {
          return interaction.reply({
            content: "Only staff can use this feature!",
            ephemeral: true,
          });
        }
        switch (sub) {
          case "add":
            {
              let user = await client.users.fetch(userid).catch(() => {});
              await client.con.query(
                `SELECT * FROM blacklistedusers WHERE UserID = "${
                  user?.id || userid
                }"`,
                async (e, row) => {
                  if (e) {
                    if (client.config.debugmode) {
                      console.log(e.stack);
                    }
                  }
                  if (row[0]) {
                    return interaction.reply({
                      embeds: [
                        new EmbedBuilder()
                          .setColor(client.config.color)
                          .setTitle("User is Blacklisted")
                          .setDescription(
                            "The inserted id matches a user inside the database already."
                          ),
                      ],
                      ephemeral: true,
                    });
                  }
                  if (!user) {
                    return interaction.reply({
                      embeds: [
                        new EmbedBuilder()
                          .setColor(client.config.color)
                          .setTitle("User Not Found")
                          .setDescription(
                            "The inserted id couldn't be resolved to a user.\n**Please check that you inserted the correct user id.**"
                          ),
                      ],
                      ephemeral: true,
                    });
                  }
                  if (user) {
                    await client.con.query(
                      `SELECT COUNT(CaseID) as total FROM blacklistedusers`,
                      async (e, res) => {
                        if (e) {
                          if (client.config.debugmode) {
                            console.log(e.stack);
                          }
                        }
                        let caseid = res[0].total + 1;
                        let embed = new EmbedBuilder()
                          .setColor(client.config.color)
                          .setTitle("User Blacklisted")
                          .setDescription(
                            `**Staff Member:** - ${interaction.user.tag} (${
                              interaction.user.id
                            })\n**User:** - ${user.tag} (${
                              user.id
                            })\n**Reason:** ${reason}\n**Case:** ${caseid}\n**Date:** ${await utils.fetchTime(
                              client.config.date.tz,
                              client.config.date.format
                            )}`
                          );
                        try {
                          embed.setImage(evidence);
                        } catch (error) {
                          embed.setFooter({
                            text: "Evidence failed to go to image!",
                          });
                        }
                        await client.con.query(
                          `INSERT INTO blacklistedusers (CaseID, UserID, Reason, Evidence) VALUES ("${caseid}", "${user.id}", "${reason}", "${evidence}")`,
                          async (e) => {
                            if (e) {
                              if (client.config.debugmode) {
                                console.log(e.stack);
                              }
                            }
                            await client.utils.logtoservers(client, embed);
                            await client.utils.gban(client, user);
                            return interaction.reply({
                              embeds: [
                                new EmbedBuilder()
                                  .setColor(client.config.color)
                                  .setTitle("Success")
                                  .setDescription(
                                    "The user was added to the blacklist"
                                  ),
                              ],
                              ephemeral: true,
                            });
                          }
                        );
                      }
                    );
                  }
                }
              );
            }

            break;
          case "remove":
            {
              let user = await client.users.fetch(userid).catch(() => {});
              await client.con.query(
                `SELECT * FROM blacklistedusers WHERE UserID = "${
                  user?.id || userid
                }"`,
                async (e, row) => {
                  if (e) {
                    if (client.config.debugmode) {
                      console.log(e.stack);
                    }
                  }
                  if (!row[0]) {
                    return interaction.reply({
                      embeds: [
                        new EmbedBuilder()
                          .setColor(client.config.color)
                          .setTitle("User isn't Blacklisted")
                          .setDescription(
                            "The inserted id doesn't match any users inside the database already."
                          ),
                      ],
                      ephemeral: true,
                    });
                  }
                  if (!user) {
                    return interaction.reply({
                      embeds: [
                        new EmbedBuilder()
                          .setColor(client.config.color)
                          .setTitle("User Not Found")
                          .setDescription(
                            "The inserted id couldn't be resolved to a user.\n**Please check that you inserted the correct user id.**"
                          ),
                      ],
                      ephemeral: true,
                    });
                  }
                  if (user) {
                    await client.con.query(
                      `DELETE FROM blacklistedusers WHERE CaseID = "${row[0]?.CaseID}" AND UserID = "${user.id}"`,
                      async (e) => {
                        if (e) {
                          if (client.config.debugmode) {
                            console.log(e.stack);
                          }
                        }
                        let embed = new EmbedBuilder()
                          .setColor(client.config.color)
                          .setTitle("Blacklist Removed")
                          .setDescription(
                            `**Staff Member:** - ${interaction.user.tag} (${
                              interaction.user.id
                            })\n**User:** - ${user.tag} (${
                              user.id
                            })\n**Case:** ${
                              row[0]?.CaseID
                            }\n**Date:** ${await utils.fetchTime(
                              client.config.date.tz,
                              client.config.date.format
                            )}`
                          );
                        try {
                          embed.setImage(evidence);
                        } catch (error) {
                          embed.setFooter({
                            text: "Evidence failed to go to image!",
                          });
                        }
                        await client.utils.logtoservers(client, embed);
                        await client.utils.gunban(client, user);
                        return interaction.reply({
                          embeds: [
                            new EmbedBuilder()
                              .setColor(client.config.color)
                              .setTitle("Success")
                              .setDescription(
                                "The user was removed from the blacklist"
                              ),
                          ],
                          ephemeral: true,
                        });
                      }
                    );
                  }
                }
              );
            }

            break;

          default:
            break;
        }
      }
    );
  },
};
