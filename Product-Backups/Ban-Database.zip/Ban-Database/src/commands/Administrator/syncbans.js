const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("syncbans")
    .setDescription("Sync the database and guild bans")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client) {
    const { guild } = interaction;
    await client.con.query(
      `SELECT * FROM staff WHERE UserID = '${interaction.user.id}'`,
      async (e, row) => {
        if (e) {
          if (client.config.debugmode) {
            console.log(e.stack);
          }
        }
        if (!row[0]) {
          return interaction.reply({
            content: "Only staff can use this feature!",
            ephemeral: true,
          });
        }
        await client.utils.syncbans(client, guild);
        return interaction.reply({
          content: "Syncing bans... This could take a little while.",
          ephemeral: true,
        });
      }
    );
  },
};
