const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("appeal-manager")
    .setDescription("Appeal manager")
    .addSubcommand((sub) =>
      sub
        .setName("approve")
        .setDescription("Approve an appeal")
        .addNumberOption((o) =>
          o
            .setName("appealid")
            .setDescription("The appeal id")
            .setRequired(true)
        )
        .addStringOption((o) =>
          o
            .setName("userid")
            .setDescription("The appealling user's id")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("deny")
        .setDescription("Deny an appeal")
        .addNumberOption((o) =>
          o
            .setName("appealid")
            .setDescription("The appeal id")
            .setRequired(true)
        )
        .addStringOption((o) =>
          o
            .setName("userid")
            .setDescription("The appealling user's id")
            .setRequired(true)
        )
    ),

  async execute(interaction, client) {
    let { options } = interaction;
    let sub = options.getSubcommand();
    let appealid = options.getNumber("appealid");
    let userid = options.getString("userid");
    await client.con.query(
      `SELECT * FROM staff WHERE UserID = "${interaction.user.id}"`,
      async (e, row) => {
        if (e) {
          if (client.config.debugmode) {
            console.log(e.stack);
          }
        }
        if (!row[0]) {
          return interaction.reply({
            content: "Only staff can use this feature!",
            ephemeral: true,
          });
        }
        switch (sub) {
          case "approve":
            {
              await client.con.query(
                `SELECT * FROM appeals WHERE AppealID = '${appealid}' AND UserID = "${userid}"`,
                async (e, row) => {
                  if (e) {
                    if (client.config.debugmode) {
                      console.log(e.stack);
                    }
                  }
                  if (!row[0]) {
                    return interaction.reply({
                      content: "No appeal was found!",
                      ephemeral: true,
                    });
                  }
                  await client.con.query(
                    `UPDATE appeals SET Pending = "false" WHERE AppealID = '${appealid}' AND UserID = "${userid}"`,
                    async (e) => {
                      if (e) {
                        if (client.config.debugmode) {
                          console.log(e.stack);
                        }
                      }
                      return interaction.reply({
                        content: "Appeal was approved!",
                        ephemeral: true,
                      });
                    }
                  );
                }
              );
            }

            break;
          case "deny":
            {
              await client.con.query(
                `SELECT * FROM appeals WHERE AppealID = '${appealid}' AND UserID = "${userid}"`,
                async (e, row) => {
                  if (e) {
                    if (client.config.debugmode) {
                      console.log(e.stack);
                    }
                  }
                  if (!row[0]) {
                    return interaction.reply({
                      content: "No appeal was found!",
                      ephemeral: true,
                    });
                  }
                  await client.con.query(
                    `UPDATE appeals SET Pending = "false" WHERE AppealID = '${appealid}' AND UserID = "${userid}"`,
                    async (e) => {
                      if (e) {
                        if (client.config.debugmode) {
                          console.log(e.stack);
                        }
                      }
                      return interaction.reply({
                        content: "Appeal was denied!",
                        ephemeral: true,
                      });
                    }
                  );
                }
              );
            }

            break;

          default:
            break;
        }
      }
    );
  },
};
