const { SlashCommandBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("report-manager")
    .setDescription("Report manager")
    .addSubcommand((sub) =>
      sub
        .setName("approve")
        .setDescription("Approve a report")
        .addNumberOption((o) =>
          o
            .setName("reportid")
            .setDescription("The report id")
            .setRequired(true)
        )
        .addStringOption((o) =>
          o
            .setName("userid")
            .setDescription("The reported user's id")
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName("deny")
        .setDescription("Deny a report")
        .addNumberOption((o) =>
          o
            .setName("reportid")
            .setDescription("The report id")
            .setRequired(true)
        )
        .addStringOption((o) =>
          o
            .setName("userid")
            .setDescription("The reported user's id")
            .setRequired(true)
        )
    ),

  async execute(interaction, client) {
    let { options } = interaction;
    let sub = options.getSubcommand();
    let reportid = options.getNumber("reportid");
    let userid = options.getString("userid");
    await client.con.query(
      `SELECT * FROM staff WHERE UserID = "${interaction.user.id}"`,
      async (e, row) => {
        if (e) {
          if (client.config.debugmode) {
            console.log(e.stack);
          }
        }
        if (!row[0]) {
          return interaction.reply({
            content: "Only staff can use this feature!",
            ephemeral: true,
          });
        }
        switch (sub) {
          case "approve":
            {
              await client.con.query(
                `SELECT * FROM reports WHERE ReportID = '${reportid}' AND UserID = "${userid}"`,
                async (e, row) => {
                  if (e) {
                    if (client.config.debugmode) {
                      console.log(e.stack);
                    }
                  }
                  if (!row[0]) {
                    return interaction.reply({
                      content: "No report was found!",
                      ephemeral: true,
                    });
                  }
                  await client.con.query(
                    `UPDATE reports SET Pending = "false" WHERE ReportID = '${reportid}' AND UserID = "${userid}"`,
                    async (e) => {
                      if (e) {
                        if (client.config.debugmode) {
                          console.log(e.stack);
                        }
                      }
                      return interaction.reply({
                        content: "Report was approved!",
                        ephemeral: true,
                      });
                    }
                  );
                }
              );
            }

            break;
          case "deny":
            {
              await client.con.query(
                `SELECT * FROM reports WHERE ReportID = '${reportid}' AND UserID = "${userid}"`,
                async (e, row) => {
                  if (e) {
                    if (client.config.debugmode) {
                      console.log(e.stack);
                    }
                  }
                  if (!row[0]) {
                    return interaction.reply({
                      content: "No report was found!",
                      ephemeral: true,
                    });
                  }
                  await client.con.query(
                    `UPDATE reports SET Pending = "false" WHERE ReportID = '${reportid}' AND UserID = "${userid}"`,
                    async (e) => {
                      if (e) {
                        if (client.config.debugmode) {
                          console.log(e.stack);
                        }
                      }
                      return interaction.reply({
                        content: "Report was denied!",
                        ephemeral: true,
                      });
                    }
                  );
                }
              );
            }

            break;

          default:
            break;
        }
      }
    );
  },
};
