const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Find my ping!"),
  async execute(interaction, client) {
    const msg = await interaction.deferReply({
      fetchReply: true,
      ephemeral: true,
    });
    let embed = new EmbedBuilder()
      .setColor(client.config.color)
      .setDescription(
        `Pong :ping_pong: !\nPing: ${
          msg.createdTimestamp - interaction.createdTimestamp
        } ms.`
      );
    return interaction.editReply({
      embeds: [embed],
      ephemeral: true,
    });
  },
};
