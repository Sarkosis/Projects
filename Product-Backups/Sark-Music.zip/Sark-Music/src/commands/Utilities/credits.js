const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("credits")
    .setDescription("Fetch the credits to the bot"),

  async execute(interaction, client) {
    const embed = new EmbedBuilder()
      .setColor(client.config.color)
      .setTitle("📝 Credits")
      .setDescription("[Sarkosis#3052 📥](https://store.sarksdevelopment.com) - Writing the source code.");
    return interaction.reply({
      embeds: [embed],
      ephemeral: true,
    });
  },
};
