const chalk = require("chalk");
const axios = require("axios");
const config = require("../../config.json");

async function error(client, content) {
  if (client.config.debugmode) {
    console.log(
      chalk.red("DEBUG MODE ERROR: ", content, `\n ${content.stack}`)
    );
  }
}

async function versionChecker() {
  setTimeout(async () => {
    const version = require("../../package.json").version;
    const currver = version;
    const req = await axios({
      method: "get",
      url: "https://raw.githubusercontent.com/Sarkosis/version-pub-api/main/versions.json",
      headers: {
        Accept: "application/json, text/plain, */*",
        "User-Agent": "*",
      },
    });
    const latestver = req.data.music;
    if (latestver != currver) {
      console.log(
        `${chalk.yellow("[Version Checker]\n")}${chalk.red(
          `You are not on the latest version.\nCurrent Version: ${currver}\nLatest Version: ${latestver}`
        )}`
      );
    } else {
      console.log(
        `${chalk.green("[Version Checker]")} You are on the latest version.`
      );
    }
  }, 1000);
}

async function license(licenseKey, uniqueId) {
  let request = await axios({
    method: "get",
    url: `https://store.sarksdevelopment.com/api/v1/license/check/${licenseKey}`,
    headers: {
      Accept: "application/json, text/plain, */*",
      "User-Agent": "*",
      productid: uniqueId,
    },
  });

  if (request.data.authorized) {
    setTimeout(() => {
      console.log(`${chalk.green.dim("[License Check]")} License Key Accepted`);
    }, 1001);
  } else {
    console.log(`${chalk.red.dim("[License Check]")} License Key Failed`);
    process.exit(1);
  }
}
license(config.license, "16731159985480qUN5jQ3FON2H2");
versionChecker();

exports.error = error;
