const { GatewayIntentBits, Partials } = require("discord.js");
const fs = require("fs");
const chalk = require("chalk");
const { Player } = require("discord-player");
const { SarkClient } = require("./sarkClient");
const client = new SarkClient({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildVoiceStates,
  ],
  partials: [
    Partials.GuildMember,
    Partials.Message,
    Partials.Channel,
    Partials.User,
  ],
});

// Handlers

const functionFolders = fs.readdirSync(`./src/functions`);
for (const folder of functionFolders) {
  const functionsFiles = fs
    .readdirSync(`./src/functions/${folder}`)
    .filter((file) => file.endsWith(".js"));
  for (const file of functionsFiles)
    require(`../functions/${folder}/${file}`)(client);
}

// Video Player

client.player = new Player(client, {
  ytdlOptions: {
    quality: "highestaudio",
    highWaterMark: 1 << 25,
  },
});

client.setMaxListeners(0);
client.handleEvents(client);
client.handleCommands();

try {
  client.login(client.config.client.token);
} catch (err) {
  if (client.config.debugmode) {
    console.log(err);
  }
  return process.exit(1);
}
process.on("unhandledRejection", (err) => {
  if (err !== "DiscordAPIError: Unknown Message") {
    console.log(chalk.red(`\nFatal Error Occured: \n\n`, err.stack));
  }
});
