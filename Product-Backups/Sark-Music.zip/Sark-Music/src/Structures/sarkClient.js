const { Client, Collection } = require("discord.js");
class SarkClient extends Client {
  constructor(options = {}) {
    super(options);
    this.config = require("../../config.json");
    this.utils = require("./utils");
    this.commands = new Collection();
    this.commandArray = [];
  }
}

exports.SarkClient = SarkClient;
