const { GatewayIntentBits, Partials } = require("discord.js");
const fs = require("fs");
const mysql = require("mysql");
const chalk = require("chalk");
const axios = require("axios");
const { SarkClient } = require("./sarkClient");
const client = new SarkClient({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessageReactions,
  ],
  partials: [
    Partials.GuildMember,
    Partials.Message,
    Partials.Channel,
    Partials.User,
  ],
});

setTimeout(() => {
  const version = Number(process.version.split(".")[0].replace("v", ""));
  if (version < 16)
    return console.log(chalk.red("\n\nPlease upgrade to Node v16 or higher"));
}, 8000);
setTimeout(async () => {
  const version = require("../../package.json").version;
  const currver = version;
  const req = await axios({
    method: "get",
    url: "https://raw.githubusercontent.com/Sarkosis/version-pub-api/main/versions.json",
    headers: { Accept: "application/json, text/plain, */*", "User-Agent": "*" },
  });
  const latestver = req.data.giveaway;
  if (latestver != currver) {
    console.log(
      `${chalk.yellow("[Version Checker]\n")}${chalk.red(
        `You are not on the latest version.\nCurrent Version: ${currver}\nLatest Version: ${latestver}`
      )}`
    );
  } else {
    console.log(
      `${chalk.green("[Version Checker]")} You are on the latest version.`
    );
  }
}, 4000);

const functionFolders = fs.readdirSync(`./src/functions`);
for (const folder of functionFolders) {
  const functionsFiles = fs
    .readdirSync(`./src/functions/${folder}`)
    .filter((file) => file.endsWith(".js"));
  for (const file of functionsFiles)
    require(`../functions/${folder}/${file}`)(client);
}

client.setMaxListeners(0);
client.handleEvents(client);
client.handleCommands();
if (!client.utils.licenseCheck) {
  console.log(
    `${chalk.red("[License System]\n")}${chalk.yellow(
      "The License system was removed from ./src/Structures/utils.js\nIt is likely that the code has been tampered with.\nAs a precausion the node.js process has stopped."
    )}`
  );
  process.exit(1);
}
// client.utils.licenseCheck(client.config.bot.license, "1672809389247tcLU1ipFXsJ6JF");
try {
  const sqlstuff = {
    connectionLimit: 10,
    queueLimit: 5000,
    host: client.config.database.host,
    user: client.config.database.user,
    password: client.config.database.password,
    database: client.config.database.name,
  };
  const con = mysql.createPool(sqlstuff);
  setTimeout(() => {
    console.log(`${chalk.yellow("[SQL SERVER]")} Successfully Connected`);
  }, 4000);
  con.on("enqueue", function () {
    if (client.config.bot.debugMode) {
      console.log(
        `${chalk.yellow("[SQL SERVER]")} Waiting for available connection slot`
      );
    }
  });
  con.on("release", function (connection) {
    if (client.config.bot.debugMode) {
      console.log(
        `${chalk.yellow("[SQL SERVER]")} Connection %d released`,
        connection.threadId
      );
    }
  });
  client.connection = con;
} catch (err) {
  if (client.config.bot.debugMode) {
    client.utils.error(client, err);
  }
  return process.exit(1);
}
try {
  client.login(client.config.bot.token);
} catch (err) {
  if (client.config.bot.debugMode) {
    console.log(err);
  }
  return process.exit(1);
}
process.on("unhandledRejection", (err) => {
  if (err !== "DiscordAPIError: Unknown Message") {
    console.log(chalk.red(`\nFatal Error Occured: \n\n`, err.stack));
  }
});

setInterval(() => {
  client.utils.giveawaysManager(client);
}, 15000);
